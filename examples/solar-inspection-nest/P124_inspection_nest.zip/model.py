"""P124 R4G inspection nest. Units mm. Requires CadQuery 2.x.
Run: python3 model.py (writes STL and STEP beside this file).
"""
from pathlib import Path
import cadquery as cq
OUT=Path(__file__).resolve().parent
# X across panel width; Y along length; Z upward from print bed.
W,L=79.5,126.5
CW,CL=67.5,114.5
RW,RL=61.0,109.0
SEAT=12.0
GUIDE=1.2
# Open-bottom cell relief: no material beneath the cell envelope.
nest=cq.Workplane('XY').box(W,L,SEAT+GUIDE,centered=(True,True,False))
nest=nest.cut(cq.Workplane('XY').box(CW,CL,GUIDE+1,centered=(True,True,False)).translate((0,0,SEAT)))
nest=nest.cut(cq.Workplane('XY').box(RW,RL,SEAT+GUIDE+2,centered=(True,True,False)).translate((0,0,-1)))
# Opposed finger bays. 2mm bed-level webs maintain one connected part.
for sign in (-1,1):
    nest=nest.cut(cq.Workplane('XY').box(20,24,SEAT+GUIDE,centered=(True,True,False)).translate((sign*36,0,2)))
solid=nest.val()
assert solid.isValid() and len(solid.Solids())==1
cq.exporters.export(nest,str(OUT/'P124_nest.stl'),tolerance=0.03,angularTolerance=0.1)
cq.exporters.export(nest,str(OUT/'P124_nest.step'))
if __name__=='__main__':
    print('One valid solid; volume mm3:',solid.Volume())
