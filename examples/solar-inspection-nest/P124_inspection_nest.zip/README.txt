P124 R4G SOLAR PANEL INSPECTION NEST — millimetres

FILES
P124_nest.stl: ready-to-slice one-piece mesh, original scale.
P124_nest.step: editable neutral solid.
model.py: parametric editable source (Python 3 + CadQuery 2.x).
verification.json: digital checks and limits.
No CAD changes or mesh repair are required to print the supplied STL.
To regenerate optionally install CadQuery 2.x and run python3 model.py.

PRINT
Use PLA, 0.4 mm nozzle, 0.20 mm layers, 4 perimeters, 5 bottom/top
layers and 20% infill. Use your PLA supplier's temperatures and a calibrated
first layer. Place the broad flat bottom on the bed (Z=0); shallow panel
pocket faces UP. Do not invert. Scale 100%, units mm: 79.5 x 126.5 x
13.2 mm, within a 180 mm cube. Supports OFF; no hardware. All upper
sections are supported by material below; the central aperture is open
through the bottom. The two finger bays retain 2 mm bottom webs.
Remove brim if used. Remove loose strings/burrs without changing dimensions.
Inspect for sharp edges, warped seating rails or debris before use.

USE
For one UNWIRED P124 R4G only. Put nest on a clean flat bench.
Hold panel by edges, cells DOWN and rear pads UP. Align the long axes,
then lower vertically into the shallow guide pocket. Do not slide it over
the rim or force a tight fit. The cell-free perimeter rests at Z=12 mm;
the central cell area is over an open aperture, not a supporting floor.
Both rear 4 x 4 mm pads remain accessible from above. Use light hand-held
probe contact; do not clamp or apply heavy spring-probe loads.
Use the opposed mid-side finger bays to grip both panel edges/undersides
and lift straight UP clear of the 1.2 mm guide before moving sideways.
Do not press on cells, lever against the rim, or reach through the central
aperture. If the panel binds, stop rather than force it.

DESIGN BASIS AND LIMITS
Supplied manufacturer P124 drawing revision R4G: 66 +/-0.5 mm wide,
113 +/-0.5 mm long, 2.8 +0.3/-0.5 mm thick, minimum corner 2.3 mm.
Pocket 67.5 x 114.5 mm gives at least 1.0 mm total clearance per axis
for the maximum panel. Guide height 1.2 mm is below minimum thickness.
Opening 61 x 109 mm. With any translation permitted by the pocket,
minimum cell setbacks 4.6 mm across and 3.95 mm along imply 1.35 mm
and 1.20 mm minimum ideal cell-to-seat clearance respectively.
At the smallest panel and extreme translation, cell-free edge overlap
is at least 1.25 mm across and 0.75 mm along (except finger bays).
These checks include size tolerance and free in-pocket translation.
They do not model arbitrary tilted insertion, severe bow or print errors.
The seat bears on the front cell-free perimeter, not necessarily bare PCB.
Rear pads are not covered by fixture material; the fixture stays below
the rear face. Finger bays provide 24 mm length and about 10 mm vertical
access below the seat, with open access from both sides.

Digital mesh and ideal-dimensional checks are in verification.json.
No physical print, load test, fit trial or purchase has been performed or
authorized. Before production inspection, check the printed nest is flat,
clean and freely accepts a panel without cells touching the rails. Do not
use if print error, warpage or a damaged panel defeats that clearance.
PLA is not an ESD certification or heat-resistant industrial material;
keep away from heat and follow your bench electrical/ESD procedure.
