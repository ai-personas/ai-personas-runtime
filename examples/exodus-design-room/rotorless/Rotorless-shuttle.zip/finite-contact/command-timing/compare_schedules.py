"""Recompute schedule sensitivity without overwriting either released design. Python 3, numpy, scipy."""
from pathlib import Path
import argparse,csv,json,hashlib,shutil,subprocess,sys,tempfile
H=Path(__file__).resolve().parent; E=H.parent/'electronics/eli_shuttle'; M=E/'matched'; table=E/'electrical/switching/targets.csv'
FACES=('solid','slots'); LOCK=(False,True); labs=('initial','precharge','charge','dead_before','isolated','dead_after','reset','tail'); edges=(('clamp',1),('charge',1),('charge',0),('clamp',0),('clamp',1),('reset',1),('reset',0),('clamp',0))
def schedule(key):
 with table.open() as f: data=list(csv.DictReader(f))
 assert len(data)==16
 prev=0; state=dict(charge=0,reset=0,clamp=0); cycles=[]
 for c in (1,2):
  rr=sorted([r for r in data if int(r['cycle'])==c],key=lambda r:int(r[key])); assert len(rr)==8
  legs=[]
  for lab,r,(channel,on) in zip(labs,rr,edges):
   t=int(r[key]);assert t>prev and r['channel']==channel and int(r['on'])==on and state[channel]!=on
   legs.append((lab,(t-prev)*1e-6,state['charge'],state['reset'],state['clamp'])); state[channel]=on;prev=t
  assert not any(state.values());cycles.append(legs)
 return cycles
def run(key,out):
 cycles=schedule(key); src=(M/'compare.py').read_text(); assert hashlib.sha256((M/'compare.py').read_bytes()).hexdigest()=='d75007e580b20ae60236c9048b2ad609d17aad936a9276ced35a86731fced4af','Recheck the model interface before adapting a changed driver.'
 # Change only the phase-list literal and the iterator in the exact identified solver.
 lines=src.splitlines(); i,=[i for i,x in enumerate(lines) if x.startswith(' legs=[')]; j,=[i for i,x in enumerate(lines) if ' in legs:' in x];lines[i]=' legs='+repr(cycles);lines[j]=lines[j].replace(' in legs:', ' in legs[cy-1]:')
 out.mkdir();shutil.copyfile(M/'geometry.json',out/'geometry.json'); (out/'run.py').write_text('\n'.join(lines)+'\n');subprocess.run([sys.executable,'run.py'],cwd=out,check=True,stdout=subprocess.DEVNULL);rows=json.loads((out/'summary.json').read_text()); assert len(rows)==64
 for face in FACES:
  for lock in LOCK:
   for c in (1,2):
    r=[x for x in rows if x['face']==face and x['locked']==lock and x['cycle']==c];assert [(x['leg'],x['T_s']) for x in r]==[(x[0],x[1]) for x in cycles[c-1]]
 return rows
def report(name,rows):
 out=[]
 for f in FACES:
  for l in LOCK:
   for c in (1,2):
    r=[x for x in rows if (x['face'],x['locked'],x['cycle'])==(f,l,c)];iso,=[x for x in r if x['leg']=='isolated'];assert abs(sum(x['residual_J'] for x in r))<1e-17
    out.append(dict(schedule=name,face=f,locked=int(l),cycle=c,cycle_s=sum(x['T_s'] for x in r),isolation_s=iso['T_s'],isolation_load_fJ=iso['useful_J']*1e15,isolation_rail_pJ=iso['rail_J']*1e12,isolation_travel_um=iso['max_excursion_m']*1e6,cycle_load_fJ=sum(x['useful_J'] for x in r)*1e15,cycle_rail_nJ=sum(x['rail_J'] for x in r)*1e9,end_store_fJ=r[-1]['end_store_J']*1e15,net_store_change_fJ=(r[-1]['end_store_J']-(0. if c==1 else next(x['end_store_J'] for x in reversed(rows) if (x['face'],x['locked'],x['cycle'])==(f,l,c-1))))*1e15,residual_fJ=sum(x['residual_J'] for x in r)*1e15))
 return out
if __name__=='__main__':
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--out',type=Path,required=True,help='new output directory; includes model traces');d=a.parse_args().out;d.mkdir(parents=True,exist_ok=False); rows=report('released solver',json.loads((M/'summary.json').read_text()));
 with table.open() as fp: cols=csv.DictReader(fp).fieldnames
 required={'command_us','target_contact_us','channel','on','cycle'}
 if not required.issubset(cols):raise ValueError('Missing required timing columns: '+str(required-set(cols)))
 command=schedule('command_us'); target=schedule('target_contact_us'); command_rows=run('command_us',d/'command_us'); rows+=report('command_us',command_rows)
 if command==target:
  print('All command and target contact intervals agree. Target rows reuse the identical trajectory; no measured delay is implied.')
  rows+=report('target_contact_us (same intervals)',command_rows)
 else:
  rows+=report('target_contact_us',run('target_contact_us',d/'target_contact_us'))
 with (d/'comparison.csv').open('w',newline='') as fp:
  w=csv.DictWriter(fp,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print((d/'comparison.csv').read_text())
