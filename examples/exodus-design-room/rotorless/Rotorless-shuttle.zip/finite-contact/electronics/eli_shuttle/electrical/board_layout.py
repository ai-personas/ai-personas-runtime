"""Generate the dry-contact shuttle interface PCB. Dimensions in millimeters."""
from pathlib import Path
from uuid import uuid5,NAMESPACE_URL
import math
uid=lambda s:str(uuid5(NAMESPACE_URL,'urn:shuttle:'+s))
# (ref,x,y,value,pad1-net[,pad2-net]); resistor bodies lie horizontally.
parts=[('P1',52,54,'DRIVE','VDRIVE'),('R1',57,54,'10M','VDRIVE','SHUTTLE'),('P2',70,54,'MOVING','SHUTTLE'),('P3',70,60,'REF','COM'),('P4',70,66,'PICKUP','SENSE'),('R2',57,60,'10M','COM','SENSE'),('R3',57,70,'1k','CLAMP','SENSE'),('P5',52,70,'CLAMP','CLAMP'),('P6',52,60,'RETURN','COM')]
nets=['','VDRIVE','SHUTTLE','COM','SENSE','CLAMP']; fpR='Shuttle:Axial_1016';fpP='Shuttle:WirePad_10'
# local net names are also global labels in the schematic
s=['(kicad_pcb (version 20240108) (generator pcbnew) (general (thickness 1.6)) (paper "A4") (layers (0 "F.Cu" signal) (31 "B.Cu" signal) (36 "B.SilkS" user "b.silkscreen") (37 "F.SilkS" user "f.silkscreen") (38 "B.Mask" user) (39 "F.Mask" user) (44 "Edge.Cuts" user) (49 "F.Fab" user)) (setup (pad_to_mask_clearance 0))']
s += [f'(net {i} "{n}")' for i,n in enumerate(nets)]
for ref,x,y,val,*nn in parts:
 r=len(nn)==2;path='/'+uid('sym-'+ref)
 a=[f'(footprint "{fpR if r else fpP}" (layer "F.Cu") (uuid {uid("fp-"+ref)}) (at {x} {y}) (path "{path}") (attr through_hole)']
 for key,v,yy,layer in [('Reference',ref,-2.0,'F.SilkS'),('Value',val,2.0,'F.Fab')]: a.append(f'(property "{key}" "{v}" (at {5.08 if r else 0} {yy}) (layer "{layer}") (effects (font (size 0.9 0.9) (thickness 0.15))))')
 if r:a.append('(fp_rect (start 1.83 -1.25) (end 8.33 1.25) (stroke (width 0.15) (type default)) (fill none) (layer "F.SilkS"))')
 for i,n in enumerate(nn):a.append(f'(pad "{i+1}" thru_hole {"rect" if r and i==0 else "circle"} (at {i*10.16} 0) (size {"1.6 1.6" if r else "2 2"}) (drill {0.8 if r else 1.0}) (layers "*.Cu" "*.Mask") (net {nets.index(n)} "{n}") (pintype "passive"))')
 s+=a+[')']
 # Save the exact editable local footprint used on the PCB, minus instance data.
 import re
 folder=Path('Shuttle.pretty');folder.mkdir(exist_ok=True);name=(fpR if r else fpP).split(':')[1]
 body='\n'.join(a[1:]);body=re.sub(r' \(net [0-9]+ "[^"]+"\) \(pintype "passive"\)','',body).replace('"Reference" "'+ref+'"','"Reference" "REF**"').replace('"Value" "'+val+'"','"Value" "'+name+'"');(folder/(name+'.kicad_mod')).write_text('(footprint "'+name+'" (version 20240108) (generator pcbnew) (layer "F.Cu") (attr through_hole)\n'+body+'\n)\n');
 if not r:s.append(f'(gr_text "{val}" (at {x} {y+2}) (layer "F.SilkS") (effects (font (size .8 .8) (thickness .13))))')
def route(n,pts,l='B.Cu'):
 for (x,y),(xx,yy) in zip(pts,pts[1:]):s.append(f'(segment (start {x} {y}) (end {xx} {yy}) (width 0.4) (layer "{l}") (net {nets.index(n)}))')
route('VDRIVE',[(52,54),(57,54)]);route('SHUTTLE',[(67.16,54),(70,54)]);route('COM',[(52,60),(57,60),(60,57),(67,57),(70,60)]);route('SENSE',[(67.16,60),(67.16,64),(69.16,66),(70,66)]);route('SENSE',[(67.16,70),(67.16,68),(69.16,66)]);route('CLAMP',[(52,70),(57,70)])
s.append('(gr_rect (start 47 49) (end 75 75) (stroke (width 0.05) (type default)) (fill none) (layer "Edge.Cuts"))');s.append(')');Path('shuttle.kicad_pcb').write_text('\n'.join(s)+'\n')
