"""Make three-channel target contact edges and latency-compensated logic VCD (1 us ticks).
Use only on a dry-contact timing MODEL. Coil command is not proof of contact state.
"""
import csv,argparse
from pathlib import Path
pins=('charge','clamp','reset')
def schedule(reset_us=60_000_000,cycles=2,on=(0,0,0),off=(0,0,0)):
 if reset_us<1 or cycles<1 or any(t<0 for t in (*on,*off)):raise ValueError('invalid duration or latency')
 edges=[]; base=20000
 # All contacts normally open; clamp ahead of charge; disconnect charge before unclamping;
 # clamp again before reset, then open reset well before next charge. Times: target contact transitions.
 for c in range(cycles):
  a=base;b=a+8000;d=b+200;f=d+2_000_000;g=f+200;h=g+reset_us
  for t,n,v in [(a-5000,1,1),(a,0,1),(b,0,0),(d,1,0),(f,1,1),(g,2,1),(h,2,0),(h+2000,1,0)]:edges.append((t-(on if v else off)[n],t,n,v,c+1))
  base=h+20000
 if min(z[0] for z in edges)<0:raise ValueError('latency exceeds pre-roll')
 for i in range(3):
  p=[z[0] for z in edges if z[2]==i];
  if any(a>=b for a,b in zip(p,p[1:])):raise ValueError('command ordering incompatible with latency')
 # Never energize charge and reset together. Actual bounce/delay variability is outside this rule.
 state=[0]*3
 for t,_,n,v,_ in sorted(edges):
  state[n]=v
  if state[0] and state[2]:raise ValueError('charge and reset command overlap')
 return sorted(edges)
def emit(edges,path):
 path=Path(path); syms='ABC';
 with path.with_suffix('.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(('command_us','target_contact_us','channel','on','cycle'));w.writerows((t,tc,pins[n],v,c) for t,tc,n,v,c in edges)
 with path.with_suffix('.vcd').open('w') as f:
  f.write('$timescale 1us $end\n$scope module dry_contacts $end\n');
  for s,n in zip(syms,pins):f.write(f'$var wire 1 {s} {n} $end\n')
  f.write('$upscope $end\n$enddefinitions $end\n#0\n$dumpvars\n0A\n0B\n0C\n$end\n');last=-1
  for t,tc,n,v,c in edges:
   if t!=last:f.write(f'#{t}\n');last=t
   f.write(f'{v}{syms[n]}\n')
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reset-s',type=float,default=60);p.add_argument('--on-us',type=int,nargs=3,default=[0]*3);p.add_argument('--off-us',type=int,nargs=3,default=[0]*3);p.add_argument('--stem',default='targets');a=p.parse_args();emit(schedule(round(a.reset_s*1e6),on=a.on_us,off=a.off_us),a.stem)
