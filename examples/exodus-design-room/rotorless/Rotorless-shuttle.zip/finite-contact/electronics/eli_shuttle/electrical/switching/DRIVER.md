# External relay driver — separate control-energy port

This is the wiring design for the switch fixture, not a fourth component on the passive shuttle PCB. U1 is Texas Instruments ULN2003AN, 16-pin PDIP. Pin numbers below are the **top view of U1**, per TI SLRS027T (rev. March 2025), Fig. 4-1 and Table 4-1, https://www.ti.com/lit/ds/symlink/uln2003a.pdf . The ordering addendum lists the exact AN variant. Count from the pin-1 mark, not from the controller's display of bit order.

|U1 input|Logic function, active high|U1 collector|Coil driven|
|---:|---|---:|---|
|1|charge|16|Kcharge|
|2|reset contact (not sequencer reset)|15|Kreset|
|3|clamp|14|Kclamp|

Use a separate regulated 5 V control supply. Pin 8 (emitters) to its negative and command-source ground. Pin 9 (common flyback cathode) to +5 V. On Coto 9007-05-01, pin 2 (internal diode cathode) goes to +5 V; pin 3 (anode) goes to the corresponding U1 collector. Pins 1 and 4 form the normally-open dry contact. See Coto 9007 series data sheet, p. 2, note 2 for polarity. Tie unused inputs 4–7 low; leave unused outputs 10–13 open. Keep the **control common separate** from the **charge-rail negative/electrode common**: the three dry contacts are the signal boundary. `INTERFACE.md` defines both contact terminals for each relay. 5 V CMOS command sources must drive the internal 2.7 kΩ base resistors and default low; do not connect a coil directly to logic. Positive `reset contact` is not the emergency off state. Disable should de-energize all coils. The independent 12 V rail must be current limited even with a failed or overlapping contact.

A 500 Ω coil fed through a sinking driver sees less than the control supply voltage; budget voltage at the **coil**, not only the rail. TI lists 1.1 V max VCE(sat) at the specified 100 mA/250 µA test point, not a measured drop for this coil. At nominal 5 V and an illustrative 1 V drop, 4 V remains. Establish actual operate/release voltages, delays including diode suppression and bounce against the contact targets; logic timing alone cannot prove isolation. Log signed power at the control-supply port, including controller/timer; account separately for any independently powered command source. Do not add calculated coil heat to measured supply input a second time.
