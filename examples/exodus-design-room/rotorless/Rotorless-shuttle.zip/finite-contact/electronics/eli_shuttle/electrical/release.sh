#!/bin/sh
# Run from the directory containing the native shuttle.* project, NOT board.py alone.
set -eu
mkdir -p reports preview fabrication
kicad-cli sch erc --exit-code-violations -o reports/erc.rpt shuttle.kicad_sch
kicad-cli pcb drc --schematic-parity --exit-code-violations -o reports/drc.rpt shuttle.kicad_pcb
kicad-cli sch export netlist -o reports/shuttle.net shuttle.kicad_sch
kicad-cli sch export pdf -o preview/schematic.pdf shuttle.kicad_sch
kicad-cli pcb export pdf --layers F.Silkscreen,Edge.Cuts,F.Cu -o preview/top.pdf shuttle.kicad_pcb
kicad-cli pcb export gerbers --layers F.Cu,B.Cu,F.Mask,B.Mask,F.Silkscreen,Edge.Cuts -o fabrication/ shuttle.kicad_pcb
kicad-cli pcb export drill --format excellon --excellon-separate-th --drill-origin absolute --excellon-units mm -o fabrication/ shuttle.kicad_pcb
