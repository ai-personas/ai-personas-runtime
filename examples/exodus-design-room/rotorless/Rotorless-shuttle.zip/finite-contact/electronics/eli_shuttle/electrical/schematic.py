"""Emit a wired, editable KiCad schematic and project-local libraries."""
from board_layout import parts,fpP,fpR,uid
from pathlib import Path
fp=lambda s:Path(s)
project='shuttle';sheet=uid('sheet');font='(effects (font (size 1.27 1.27)))';hidden='(effects (font (size 1.27 1.27)) hide)'
def sym(name,ref,gfx,pins):
 props=' '.join(f'(property "{key}" "{v}" (at 0 {y} 0) {show})' for key,v,y,show in [('Reference',ref,3.81,font),('Value',name,-3.81,font),('Footprint',fpR if name=='R' else fpP,0,hidden)])
 return f'(symbol "{name}" (pin_names (offset 0) hide) (pin_numbers hide) (in_bom yes) (on_board yes) {props} (symbol "{name}_0_1" {gfx}) (symbol "{name}_1_1" {pins}))'
def pin(x,y,ang,l,num):return f'(pin passive line (at {x} {y} {ang}) (length {l}) (name "~" {font}) (number "{num}" {font}))'
stroke='(stroke (width 0.254) (type default)) (fill (type none))';rr=sym('R','R',f'(rectangle (start -2.54 1.016) (end 2.54 -1.016) {stroke})',pin(-5.08,0,0,2.54,1)+pin(5.08,0,180,2.54,2));pp=sym('Wire','P',f'(circle (center 0 -0.635) (radius 0.635) {stroke})',pin(0,2.54,270,2.54,1));defs=[rr,pp]
fp('Shuttle.kicad_sym').write_text('(kicad_symbol_lib (version 20231120) (generator kicad_symbol_editor)\n'+'\n'.join(defs)+'\n)\n');fp('sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "Shuttle")(type "KiCad")(uri "${KIPRJMOD}/Shuttle.kicad_sym")(options "")(descr "Local shuttle symbols")))\n');fp('fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "Shuttle")(type "KiCad")(uri "${KIPRJMOD}/Shuttle.pretty")(options "")(descr "Local shuttle footprints")))\n');fp('shuttle.kicad_pro').write_text('{}\n')
s=[f'(kicad_sch (version 20231120) (generator eeschema) (uuid {sheet}) (paper "A4") (title_block (title "Rotorless electrostatic shuttle | passive interface") (rev "A") (comment 1 "12 V model - research design, not measured performance")) (lib_symbols '+''.join(d.replace('(symbol "','(symbol "Shuttle:',1) for d in defs)+')'];pos={'P1':(50.8,53.34),'P2':(127,53.34),'R1':(88.9,50.8),'P6':(50.8,78.74),'P4':(127,78.74),'P3':(68.58,86.36),'R2':(88.9,76.2),'P5':(50.8,104.14),'R3':(88.9,101.6)}
for ref,_,__,v,*ns in parts:
 r=len(ns)==2;x,y=pos[ref];lib='Shuttle:'+('R' if r else 'Wire');key=uid('sym-'+ref);s.append(f'(symbol (lib_id "{lib}") (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (uuid {key})');
 for k,val,dy,ef in [('Reference',ref,-3.3 if r else 2.8,font),('Value',v,3.3 if r else 5.1,font),('Footprint',fpR if r else fpP,0,hidden)]:s.append(f'(property "{k}" "{val}" (at {x} {y+dy} 0) {ef})');
 for i in range(len(ns)):s.append(f'(pin "{i+1}" (uuid {uid(ref+str(i))}))');
 s.append(f'(instances (project "{project}" (path "/{sheet}" (reference "{ref}") (unit 1)))))')
def wire(*pts):
 for a,b in zip(pts,pts[1:]):s.append(f'(wire (pts (xy {a[0]} {a[1]}) (xy {b[0]} {b[1]})) (stroke (width 0) (type default)) (uuid {uid(str((a,b)))}))')
for y,left,right in [(50.8,[50.8,83.82],[93.98,127]),(76.2,[50.8,68.58,83.82],[93.98,115.57,127]),(101.6,[50.8,83.82],[93.98,115.57])]:
 for xs in (left,right):wire(*[(x,y) for x in xs]);
wire((68.58,76.2),(68.58,83.82));wire((115.57,76.2),(115.57,101.6));
for x in (68.58,115.57):s.append(f'(junction (at {x} 76.2) (diameter 0) (color 0 0 0 0) (uuid {uid("j"+str(x))}))')
for n,x,y,ang in [('VDRIVE',50.8,50.8,180),('SHUTTLE',127,50.8,0),('COM',50.8,76.2,180),('SENSE',127,76.2,0),('CLAMP',50.8,101.6,180)]:s.append(f'(global_label "{n}" (shape passive) (at {x} {y} {ang}) (effects (font (size 1.27 1.27)) (justify {"right" if ang==180 else "left"})) (uuid {uid(n)}))')
for i,t in enumerate(['P1 drive: +12 V / open / COM. P5 clamp: COM / open / COM.','P2 to moving plate. P3 to far fixed plate. P4 to near fixed plate.','Meter across P4 and P6. External switches and meter are not on this board.']):s.append(f'(text "{t}" (at 44.45 {123+i*3.81} 0) (effects (font (size 1.27 1.27)) (justify left)) (uuid {uid(t)}))')
s+=['(sheet_instances (path "/" (page "1")))',')'];fp('shuttle.kicad_sch').write_text('\n'.join(s)+'\n')
