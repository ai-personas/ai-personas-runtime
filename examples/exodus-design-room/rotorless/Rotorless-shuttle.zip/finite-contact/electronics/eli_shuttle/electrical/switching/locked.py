"""Emit and run an ngspice locked-shuttle switching control. SI units. Not measurements."""
import re,subprocess,argparse,json
from pathlib import Path

def circuit(roff=1e12,cf=0.,skew=0.0002):
 if not 1e8<=roff<=1e18 or not 0<=cf<=1e-9 or not 0<=skew<=.005: raise ValueError('parameter out of study range')
 # Times are contact-state transitions, NOT coil command times. Source opens first;
 # clamp opens skew later, then reset closes after clamp re-engages.
 t0=.001; t1=t0+.008; t2=t1+skew; t3=t2+2.; t4=t3+.0002
 def ctrl(name,phases):
  step=1e-7; pts=[(0,0.)]; old=0
  for t,val in phases:pts.extend([(t,old),(t+step,val)]);old=val
  return 'V'+name+' '+name+' 0 PWL('+' '.join('%.12g %.12g'%z for z in pts)+')'
 lines=['Locked 40 mm shuttle; contact timing and parasitics are study assumptions', 'Vrail rail 0 12','R1 drive move 10meg','R2 sense 0 10meg','Rmeter sense 0 10meg','R3 sense clamp 1k','Cg move 0 22.66672p','Cl move sense 37.77887p','Cq move 0 5p','Cp sense 0 30p','Renv move 0 1e15', 'Scharge rail drive charge 0 dry','Sreset drive 0 reset 0 dry','Sclamp clamp 0 gate 0 dry',f'.model dry sw(Ron=0.5 Roff={roff} Vt=2.5 Vh=0.1)', ctrl('charge',[(t0,5),(t1,0)]),ctrl('gate',[(.0001,5),(t2,0),(t3,5)]),ctrl('reset',[(t4,5)])]
 if cf: lines += [f'Cfeed gate sense {cf}'] # explicitly external gate-to-sense coupling; not a manufacturer's contact value
 lines += ['Bload wload 0 V=V(sense)*V(sense)/1e7','Brail wrail 0 V=-12*I(Vrail)',f'.tran 20u {t4+.1} 0 .001 uic',f'.meas tran vp MAX v(sense) FROM={t2} TO={t3}',f'.meas tran vn MIN v(sense) FROM={t2} TO={t3}',f'.meas tran load_iso INTEG v(wload) FROM={t2} TO={t3}', f'.meas tran rail_iso INTEG v(wrail) FROM={t2} TO={t3}',f'.meas tran rail_cycle INTEG v(wrail) FROM=0 TO={t4+.1}', '.end']; return '\n'.join(lines)+'\n'
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--off-ohm',type=float,default=1e12);p.add_argument('--feed-fF',type=float,default=0);p.add_argument('--skew-ms',type=float,default=.2);p.add_argument('--stem',default='locked');a=p.parse_args();f=Path(a.stem+'.cir');f.write_text(circuit(a.off_ohm,a.feed_fF*1e-15,a.skew_ms*1e-3)); r=subprocess.run(['ngspice','-b',str(f)],capture_output=True,text=True);txt=r.stdout+r.stderr;Path(a.stem+'.log').write_text(txt);vals={k:float(v) for k,v in re.findall(r'^(vp|vn|load_iso|rail_iso|rail_cycle)\s*=\s*([-+.\deE]+)',txt,re.M)}
 if len(vals)!=5 or r.returncode:raise RuntimeError(txt[-2000:]);
 print(json.dumps(vals))
