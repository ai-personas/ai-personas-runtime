// Example synthesizable target-state sequencer. Unsigned intervals in ticks.
// Default 1 MHz rising-edge clock. start is a synchronous one-shot. Synchronous
// active-high abort returns to ALL OPEN, not discharged. These are target bits,
// NOT measured contact closures and NOT signals capable of driving relay coils.
module sequencer #(parameter integer ARM=1000, CHARGE=8000, GAP=200, ISO=2000000, RESET=60000000)(input wire clk,abort,start, output wire charge,clamp,reset_contact,busy, output reg done);
localparam IDLE=0, ARMING=1, CHARGING=2, OPEN_DRIVE=3, FREE=4, RECLAMP=5, RESTORE=6;
reg [2:0] state; reg [31:0] n;
assign charge=(state==CHARGING); assign reset_contact=(state==RESTORE);
assign clamp=(state==ARMING || state==CHARGING || state==OPEN_DRIVE || state==RECLAMP || state==RESTORE); assign busy=(state!=IDLE);
always @(posedge clk) begin
 if(abort) begin state<=IDLE; n<=0; done<=0; end
 else begin done<=0;
 case(state)
 IDLE: if(start) begin state<=ARMING;n<=ARM;end
 ARMING,CHARGING,OPEN_DRIVE,FREE,RECLAMP,RESTORE: if(n>1)n<=n-1; else case(state)
 ARMING:begin state<=CHARGING;n<=CHARGE;end
 CHARGING:begin state<=OPEN_DRIVE;n<=GAP;end
 OPEN_DRIVE:begin state<=FREE;n<=ISO;end
 FREE:begin state<=RECLAMP;n<=GAP;end
 RECLAMP:begin state<=RESTORE;n<=RESET;end
 RESTORE:begin state<=IDLE;n<=0;done<=1;end
 endcase
 default:begin state<=IDLE;n<=0;end
 endcase end end
endmodule
