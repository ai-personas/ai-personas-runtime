"""Rotorless electrostatic shuttle. SI units throughout; simulation, not data."""
import math,json,csv,argparse
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
BASE=dict(A=.04**2,d=5e-4,xr=1.25e-4,k=.12,m=.0015,b=.006,RL=5e9,Rs=1e7,V0=12.,charge_s=.008,isolate_s=2.,reset_s=8.,cycles=2)
EPS=8.8541878128e-12

def run(p,trace=None):
 e=EPS*p['A']; d=p['d']; xr=p['xr']; k=p['k']; m=p['m']; b=p['b']; R=p['RL']; Rs=p['Rs']; V0=p['V0']; y=np.array([0.,0.,xr,0.,0.,0.,0.,0.]); t0=0.; results=[]
 # q,s are free charge on the shuttle and on the facing side of the loaded stator; other stator at 0 V. No parasitics in this first model.
 def fields(y):
  q,s,x,v=y[:4]; Vq=(q+s)*(d+x)/e; Vl=Vq+s*(d-x)/e; F=-(q*q+2*q*s)/(2*e); U=((q+s)**2*(d+x)+s*s*(d-x))/(2*e); return Vq,Vl,F,U+m*v*v/2+k*(x-xr)**2/2
 fp=open(trace,'w',newline='') if trace else None
 if fp:
  writer=csv.writer(fp); writer.writerow('cycle leg t_s q_C s_C x_m v_m_per_s Vsh_V Vload_V F_N E_store_J E_supply_J E_load_J E_series_J E_drag_J'.split())
 try:
  for cyc in range(1,int(p['cycles'])+1):
   for leg,dur,vs in [('charge',p['charge_s'],V0),('isolated',p['isolate_s'],None),('reset',p['reset_s'],0.)]:
    start=y.copy(); E0=fields(y)[3]
    def rhs(t,y):
     q,s,x,v=y[:4]; Vq,Vl,F,_=fields(y); i=0 if vs is None else (vs-Vq)/Rs
     return [i,-Vl/R,v,(F-k*(x-xr)-b*v)/m,(vs or 0.)*i,Vl**2/R,i*i*Rs,b*v*v]
    def contact(t,y):return .95*d-abs(y[2])
    contact.terminal=True; contact.direction=-1
    sol=solve_ivp(rhs,[0,dur],y,method='Radau',rtol=2e-9,atol=[1e-21,1e-21,1e-15,1e-14,1e-18,1e-18,1e-18,1e-18],events=contact,dense_output=True)
    if not sol.success or len(sol.t_events[0]):raise ValueError('integration failed or gap guard reached: '+str(sol.message))
    y=sol.y[:,-1]; dw=y[4:]-start[4:]; E1=fields(y)[3]; err=dw[0]-sum(dw[1:])-(E1-E0); grid=np.unique(np.r_[sol.t,np.linspace(0,dur,401)]); states=sol.sol(grid).T; fs=[fields(s) for s in states]
    results.append(dict(cycle=cyc,leg=leg,source_J=dw[0],load_J=dw[1],series_loss_J=dw[2],drag_J=dw[3],store_change_J=E1-E0,balance_error_J=err,peak_abs_load_V=max(abs(z[1]) for z in fs),minimum_gap_m=d-max(abs(states[:,2])),final_q_C=y[0],final_s_C=y[1],final_x_m=y[2],final_v_m_per_s=y[3],end_store_J=E1))
    if fp:
     for t,state,(vq,vl,f,es) in zip(grid,states,fs):writer.writerow([cyc,leg,t0+t,*state[:4],vq,vl,f,es,*state[4:]])
    t0+=dur
 finally:
  if fp:fp.close()
 return results
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--params',help='JSON overrides to BASE, SI units'); ap.add_argument('--csv'); a=ap.parse_args(); p=BASE.copy(); p.update(json.loads(Path(a.params).read_text()) if a.params else {}); print(json.dumps(run(p,a.csv),indent=2))
