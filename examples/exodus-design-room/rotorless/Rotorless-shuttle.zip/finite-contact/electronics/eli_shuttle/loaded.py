"""Physical load and a separate instrument branch; both see the same voltage."""
import csv,json,argparse
from pathlib import Path
from gated import BASE,run

def case(probe=10e6,cp=30e-12,locked=False,trace=None,load=10e6,**kw):
    if load<=0 or probe<=0:raise ValueError('branch resistance must be positive')
    r=1/(1/load+1/probe);p={**BASE,'RL':r,'Cp':cp,'locked':locked,**kw}; rows=run(p,trace)
    for z in rows:
        z['resistor_J']=z['E_load_J']*r/load;z['meter_J']=z['E_load_J']*r/probe
    return rows
if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--csv');a.add_argument('--json');a.add_argument('--locked',action='store_true');a.add_argument('--probe-Mohm',type=float,default=10);a.add_argument('--load-Mohm',type=float,default=10);a.add_argument('--pickup-pF',type=float,default=30);a.add_argument('--charge-ms',type=float,default=8);o=a.parse_args();rows=case(o.probe_Mohm*1e6,o.pickup_pF*1e-12,o.locked,o.csv,o.load_Mohm*1e6,charge_s=o.charge_ms*1e-3);txt=json.dumps(rows,indent=2)+'\n';print(txt) if not o.json else Path(o.json).write_text(txt)
