# Can a charged shuttle send electricity into a stationary load?

Yes in the ordinary capacitor model, for a finite stroke. No external force law is needed. This is a research design, not a working Exodus generator, a measurement or an authorization to order, build or energize anything.

The moving conductor hangs between two grounded or nearly grounded stators. Its nearer face has larger capacitance. Charging it from 12 V stores energy in the field. Once the charge path and the pickup clamp open, the unequal attraction can move the plate toward the nearer stator. Its changing capacitance redistributes charge through R2 and through the measuring instrument in parallel. A voltage across R2 means instantaneous power V²/R2; integrating it gives electrical energy, not the origin of that energy. The stators and frame receive the reaction force. This is motion *relative to the frame*, not propulsion of the entire isolated assembly.

## Start with the three terminals

MOVE is P2, the nearer LOAD stator connects to P4 SENSE, and the farther REF stator connects to P3 COM. The rest gaps are 0.375 and 0.625 mm respectively, with 40 × 40 mm overlapping active faces. P1 is the switched charge/reset drive; P5 connects the switched clamp; P6 is COM for the instrument and clamp. `electrical/ports.csv` is the terminal map. Open `electrical/shuttle.kicad_pro` in KiCad; board and schematic use project-local footprints and symbols. The six pads take wires, not a six-position connector. The passive board does not generate timing, power the rail, or measure its own output.

## Read a simulated cycle

`loaded.py` and `gated.py` provide the moving and locked control calculations; read their parameter settings before running them. Read the `leg` column of the CSV, not just peak voltage. Charge with the pickup clamped; isolate the drive and release the clamp for 2 s; reclamp, discharge and let the spring return. Inspect position, velocity and endpoint stored energy **after reset** before comparing entire cycles. In the nominal 10 MΩ useful load || 10 MΩ input, only half of pickup-branch heat is useful load energy. Do not count meter heat a second time.

In the low-damping ideal-switch simulation the released stroke deposits about 33.6 fJ in R2 during isolation. Solid unvented faces in a room-air squeeze-film calculation give only 0.199 fJ and 38.5 µV peak, on the same 10 MΩ load; they need a longer (60 s modeled) reset. The model is not a calibration of an actual suspension. A slotted alternative changes BOTH film resistance and active capacitance. Applying its lower damping to a solid 40 mm square would overpredict output.

Run `python3 electrical/switching/locked.py --stem /tmp/locked` with ngspice on PATH to study a different control: finite off-contact resistance at fixed rest position. At 1 TΩ per open contact, the nominal isolation window admits 4.32 pJ from the rail and deposits 0.226 fJ in R2 with **no motion**. A 20 fF coupling from clamp command to SENSE can make a 1.72 mV peak (`--feed-fF 20`). These are assumed couplings. Do not subtract this case from the ideal-contact moving result: change only freedom of motion in a matched free/locked pair. Raising the load resistance likewise changes both electrical damping and the error sensitivity.

## What would change the conclusion?

A synchronized record would need actual contact states, plate displacement and velocity, both terminal voltages, source and load currents, auxiliary input, and charge and mechanical state through return. Include calibration, uncertainties, stationary and dummy controls at the same bandwidth, and bounds on capacitive pickup and environment. The 12 V rail and relay/command supply are separate input ports. An output after a command goes low is neither proof of isolation nor proof of restored-cycle gain. A simulated force stipulated without an energy source cannot supply a generator rating.

## Current board and model comparison

Start with **`matched/README.md`** for the finite-contact comparison that corresponds to the passive board. In the slotted model with 1 TΩ off contacts, 2.354 fJ reaches the useful load in cycle 2 for 16.840 nJ supplied at the 12 V rail. The return is about 0.000014%, before control power. The same movement can raise or suppress resistor heat because the motion and switch voltages add before squaring. Open-contact leakage can even reverse the sign of the free-minus-locked heat contrast without reversing the displacement.

`electrical/BOM.csv`, `electrical/COMPONENTS.md` and `electrical/switching/DRIVER.md` specify the board and the separate driver. `electrical/switching/driver_wiring.csv` is the external net list; `sequencer.sv` in that directory specifies target states, not measured dry-contact timing. The passive PCB does not contain a relay, programmable logic or a calibrated energy meter. Gerber and drill files describe that passive PCB only. The characteristic switching delays and stray couplings of a real fixture are not established.

Digital comparison only. The setup is a stored-energy transducer. No closed-cycle gain, free-body thrust, or anomalous energy source has been confirmed.
