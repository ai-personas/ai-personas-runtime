"""Three-terminal electrostatic shuttle with a switched pickup. SI units. Simulation only."""
import argparse,csv,json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
BASE=dict(A=.04**2,d=.0005,xr=.000125,k=.12,m=.0015,b=.006,RL=5e9,Rc=1e3,Rs=1e7,Rleak=1e15,Cp=5e-12,Cq=5e-12,V0=12.,charge_s=.008,isolate_s=2.,reset_s=8.,cycles=2,locked=False)
E=8.8541878128e-12
HEADER='cycle leg t_s q_C s_C x_m v_mps Vsh_V Vload_V F_N E_store_J E_source_J E_load_J E_clamp_J E_series_J E_drag_J E_leak_J'.split()
def run(p,trace=None):
 A,d,xr,k,m,b,RL,Rc,Rs,Rleak,Cp,Cq,V0=[p[z] for z in 'A d xr k m b RL Rc Rs Rleak Cp Cq V0'.split()]; e=E*A
 if not all(np.isfinite(list(p.values()))) or min(A,d,k,m,RL,Rc,Rs,Rleak)<=0 or min(Cp,Cq,b)<0 or abs(xr)>=.95*d or min(p[z] for z in ['charge_s','isolate_s','reset_s'])<=0 or not (int(p['cycles'])==p['cycles']>=1):raise ValueError('invalid parameters')
 def fields(y):
  q,s,x,v=y[:4]; cg=e/(d+x); cl=e/(d-x); a=cg+cl+Cq; h=cl+Cp; det=(cg+Cq)*h+cl*Cp; u=(h*q+cl*s)/det; w=(cl*q+a*s)/det
  f=.5*e*(((u-w)/(d-x))**2-(u/(d+x))**2); eng=.5*(q*u+s*w+m*v*v+k*(x-xr)**2);return u,w,f,eng
 fp=open(trace,'w',newline='') if trace else None
 if fp: writer=csv.writer(fp);writer.writerow(HEADER)
 y=np.array([0.,0.,xr,0.,0.,0.,0.,0.,0.,0.]); t0=0.; out=[]
 try:
  for cy in range(1,int(p['cycles'])+1):
   for leg,T,vs,G in [('charge',p['charge_s'],V0,1/Rc),('isolated',p['isolate_s'],None,0.),('reset',p['reset_s'],0.,1/Rc)]:
    start=y.copy(); en=fields(y)[3]
    def rhs(t,y):
     u,w,f,eng=fields(y); x,v=y[2:4]; i=0. if vs is None else (vs-u)/Rs; return [i-u/Rleak,-w*(1/RL+G),0. if p['locked'] else v,0. if p['locked'] else (f-k*(x-xr)-b*v)/m,(vs or 0.)*i,w*w/RL,w*w*G,i*i*Rs,b*v*v,u*u/Rleak]
    def guard(t,y):return .95*d-abs(y[2])
    guard.terminal=True;guard.direction=-1
    sol=solve_ivp(rhs,[0,T],y,method='Radau',atol=[1e-21,1e-21,1e-15,1e-14]+[1e-23]*6,rtol=1e-8,dense_output=True,events=guard)
    if not sol.success or len(sol.t_events[0]):raise ValueError('gap guard or solver failure')
    grid=np.unique(np.r_[sol.t,np.linspace(0,T,401)]); states=sol.sol(grid).T; vals=np.array([fields(z) for z in states]); y=sol.y[:,-1]; de=fields(y)[3]-en; dw=y[4:]-start[4:]; out.append(dict(cycle=cy,leg=leg,**dict(zip(HEADER[-6:],dw)),dE_store_J=de,residual_J=dw[0]-sum(dw[1:])-de,Vload_start=vals[0,1],Vload_peak_abs_V=max(abs(vals[:,1])),F_initial_N=vals[0,2],gap_min_m=d-max(abs(states[:,2])),x_end_m=y[2],v_end_mps=y[3],dx_peak_from_rest_m=max(abs(states[:,2]-xr)),end_store_J=fields(y)[3]))
    if fp:
     for t,z,vv in zip(grid,states,vals):writer.writerow([cy,leg,t0+t,*z[:4],*vv,*z[4:]])
    t0+=T
 finally:
  if fp:fp.close()
 return out
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--params',help='JSON file of parameter overrides');ap.add_argument('--csv');args=ap.parse_args();p=BASE.copy();p.update(json.loads(Path(args.params).read_text()) if args.params else {});print(json.dumps(run(p,args.csv),indent=2))
