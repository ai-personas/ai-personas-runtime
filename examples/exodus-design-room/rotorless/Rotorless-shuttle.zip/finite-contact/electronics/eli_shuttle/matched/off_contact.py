"""At 10 Gohm per open contact, rerun the same equations and geometry; no field data.
The specified isolated-pin test resistance is not an assembled-circuit model. No capacitive
coupling, dielectric memory, bounce or driver work is inserted by this sensitivity study.
"""
import json,tempfile
from pathlib import Path
import compare as c

def sensitivity():
 out=Path(__file__).resolve().parent;rows=[];oldH,oldR=c.H,c.Ropen
 try:
  with tempfile.TemporaryDirectory() as d:
   c.H=Path(d);c.Ropen=1e10
   for face in ('solid','slots'):
    for locked in (False,True):
     rr=c.solve(face,locked);rr=[a for a in rr if a['cycle']==2];iso=next(a for a in rr if a['leg']=='isolated');res=max(abs(a['residual_J']) for a in rr);assert res<1e-16
     rows.append(dict(face=face,locked=locked,Roff_ohm=c.Ropen,iso_load_fJ=iso['useful_J']*1e15,iso_rail_nJ=iso['rail_J']*1e9,iso_min_uV=iso['min_V']*1e6,iso_max_uV=iso['max_V']*1e6,iso_excursion_um=iso['max_excursion_m']*1e6,cycle_load_fJ=sum(a['useful_J'] for a in rr)*1e15,cycle_rail_nJ=sum(a['rail_J'] for a in rr)*1e9,cycle_delta_store_J=sum(a['delta_store_J'] for a in rr),max_leg_residual_J=res))
 finally:c.H,c.Ropen=oldH,oldR
 text=json.dumps(rows,indent=2);(out/'off_contact.json').write_text(text+'\n');print(text)
if __name__=='__main__':sensitivity()
