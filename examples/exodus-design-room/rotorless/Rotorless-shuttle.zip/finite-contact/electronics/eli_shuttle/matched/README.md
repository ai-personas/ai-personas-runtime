# Does the moving plate deliver more electricity than a locked plate?

Sometimes it delivers less. These are predictions for an ordinary charged capacitor, not measurements or a reconstruction of the Exodus article. Charge initially held by MOVE and the electric field can do internal work after the charge contact opens. The LOAD terminal responds both to motion and to changing voltage on MOVE through the same capacitance. The measured voltage is signed; heat is its square integrated over time. Heat of the sum is not the sum of two independent heats. Subtracting locked heat does not in general recover mechanical work. The two stationary electrodes and the suspension receive the mechanical reactions: this is not free-body thrust.

## Read or reproduce

Run `python3 compare.py` here (Python 3, NumPy, SciPy); the script writes four CSVs and `summary.json`. Geometry coefficients in `geometry.json` distinguish active land area (m²) from the hydraulic flow coefficient (m⁴), from the solid-square and vented-stator air benchmark. Positive x points toward LOAD; at uncharged rest x=+0.125 mm relative to the gap midpoint. Each field capacitance uses its own instantaneous gap; free/locked runs use the same rest geometry, parasitics, switches, timing, meter and resistors. The air drag approximation assumes parallel plates and freely vented channels; a real slot has entrance and flow losses. There is no hypothetical extra force term.

Each CSV row reports cycle, circuit state, global and local time, free charge on each node, position and velocity, node potentials relative to COM, field force, total stored energy, and cumulative electrical and mechanical energies since start. Stored energy includes both node charges (including shunt capacitances), spring and kinetic energy. `summary.json` energy increments are per leg, **not cumulative**. Current in each modeled contact—including a nominally open contact—is accounted for. Coil/controller energy and capacitive coupling from control to signal are not in the matched model. Duplicate timestamps at a switch boundary denote the two adjacent legs; select a single leg or coalesce duplicates before resampling. Do not simply sum the cumulative columns.

## Second cycle, 2 s after both charge and clamp contacts open

|Fixed electrodes / suspension|Max excursion from rest (µm)|LOAD min … max (µV)|R2 useful heat (fJ)|12 V rail work (pJ)|
|---|---:|---:|---:|---:|
|Solid / free|15.8715|−9.750 … +3.893|0.005768|6.771|
|Solid / locked|0|−34.665 … −0.007|0.226219|4.322|
|Slotted / free|42.8821|−35.182 … +314.251|2.326636|16.116|
|Slotted / locked|0|−34.230 … −0.007|0.218590|4.961|

**Nominal isolation is not zero input.** These simulated open contacts have 1 TΩ resistance, closed contacts 0.5 Ω. The model includes a 200 µs interval between contact edges; it omits contact bounce and command-to-LOAD feedthrough. The separate locked-plate ngspice sensitivity deck is the place to vary feedthrough. Do not combine results from different switch models to infer a measured net energy.

## Charge, load, reset, repeat

The slotted free second cycle delivers **2.35361 fJ** in R2 across all legs, for **16.84031 nJ** from the 12 V rail. Its modeled useful electrical return is **1.40 × 10⁻⁷** of rail input, before controller losses. The equal-valued meter resistance dissipates additional heat, not useful R2 output. The model debits charging, contact drops, series resistance, reset, clamp, monitor, environment and mechanical dissipation. Inspect each leg's `delta_store_J` and `residual_J = rail − dissipations − change in storage`. The 60 s reset allows the second cycle to begin near the uncharged mechanical rest state, not a mathematical assertion of identical endpoints. Largest absolute leg residual across these cases: 1.55 × 10⁻²⁰ J. That is numerical closure, not experimental uncertainty. The solid locked prediction (0.226219 fJ useful heat, 4.3220 pJ rail work on first isolation) agrees with the independent circuit simulation (0.226225 fJ, 4.32067 pJ).

A discriminating experimental return would be **synchronized, calibrated signed** rail I,V at every input including switches, load voltage and independently known load resistance, mechanical displacement and node/endpoint states on the same free and locked article through charge, motion, discharge and restoration. Include switching artifacts, leakage and readout transfer with defensible uncertainty bounds. Without that evidence a predicted signal or a closed solver ledger is not evidence of surplus electricity. Digital research only; no orders, fabrication or powered tests authorized.

## Leakage changes the sign of the observed heat contrast

Run `python3 off_contact.py` in this directory for the 10 GΩ/contact sensitivity case (`off_contact.json`). This is the same circuit, geometry and timing as compare.py, not a measured leakage or an equivalent circuit derived from the insulation test. In cycle 2 the slotted moving plate advances 17.17 µm but its nominally isolated load heat is **144.83 fJ**, less than the **165.25 fJ** with motion locked. The rail supplied **12.38 nJ** during that moving isolation window; it was not electrically isolated. At the 1 TΩ setting the corresponding load energies are **2.327 vs 0.219 fJ**. Since heat depends on the square of voltage, a motion voltage can cancel part of a leakage voltage. Interpret signed traces with displacement and source current. The larger pulse in the leakier circuit is not better energy generation. Neither comparison includes controller consumption in its rail work.
