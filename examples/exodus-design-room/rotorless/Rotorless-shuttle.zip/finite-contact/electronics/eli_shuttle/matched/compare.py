"""Finite-contact air-film comparison. No unknown force or power source. Run: python3 compare.py"""
from pathlib import Path
import csv,json
import numpy as np
from scipy.integrate import solve_ivp
H=Path(__file__).resolve().parent;geom=json.loads((H/'geometry.json').read_text());eps=8.8541878128e-12
D=5e-4;xr=1.25e-4;k=.12;m=.0015;Cp=30e-12;Cq=5e-12;Ropen=1e12;Ron=.5;R1=10e6;R2=10e6;Rm=10e6;Renv=1e15;R3=1e3;V=12.
# States q and s are net free charge on the MOVE and LOAD nodes, not the charges of single plates.
energy='rail_J useful_J meter_J series_J charge_contact_J reset_contact_J clamp_branch_J env_J drag_J'.split()
def solve(face,locked):
 A,G=geom[face];e=eps*A;mu=geom['mu_Pas'];t0=0.; rows=[]; state=np.array([0.,0.,xr,0.]);cum=np.zeros(len(energy))
 def field(y):
  q,s,x,v=y[:4];cr=e/(D+x);cl=e/(D-x);det=(cr+Cq)*(cl+Cp)+cl*Cp
  u=((cl+Cp)*q+cl*s)/det;w=(cl*q+(cr+Cq+cl)*s)/det
  F=.5*e*(((u-w)/(D-x))**2-(u/(D+x))**2);U=.5*(u*q+w*s+m*v*v+k*(x-xr)**2);return u,w,F,U
 legs=[('initial',.0001,0,0,0),('precharge',.0009,0,0,1),('charge',.008,1,0,1),('dead_before',.0002,0,0,1),('isolated',2.,0,0,0),('dead_after',.0002,0,0,1),('reset',60.,0,1,1)]
 with (H/(face+('_locked' if locked else '_free')+'.csv')).open('w',newline='') as file:
  wri=csv.writer(file);wri.writerow(['cycle','leg','t_s','t_leg_s','q_C','s_C','x_m','v_mps','Vsh_V','Vload_V','F_N','E_store_J']+energy)
  for cy in (1,2):
   for leg,T,ch,re,clamp in legs:
    rc=Ron if ch else Ropen;rr=Ron if re else Ropen;rg=R3+(Ron if clamp else Ropen);a=rr/(rr+rc);rpar=a*rc
    def rhs(t,y):
     u,w,F,U=field(y);x,v=y[2:4];i=(a*V-u)/(R1+rpar);irc=V/(rr+rc)+a*i;irr=V/(rr+rc)-(1-a)*i;b=.006+12*mu*G*((D-x)**-3+(D+x)**-3)
     return [i-u/Renv,-w*(1/R2+1/Rm+1/rg),0. if locked else v,0. if locked else (F-k*(x-xr)-b*v)/m,V*irc,w*w/R2,w*w/Rm,i*i*R1,irc*irc*rc,irr*irr*rr,w*w/rg,u*u/Renv,b*v*v]
    def guard(t,y):return .95*D-abs(y[2])
    guard.terminal=True;guard.direction=-1
    startU=field(state)[3];sol=solve_ivp(rhs,(0,T),np.r_[state,np.zeros(len(energy))],method='Radau',rtol=1e-8,atol=[1e-22,1e-22,1e-15,1e-14]+[1e-24]*len(energy),dense_output=True,events=guard)
    if not sol.success or len(sol.t_events[0]):raise RuntimeError('gap guard or integration failure')
    times=np.unique(np.r_[sol.t,np.linspace(0,T,801 if leg=='isolated' else 101)]);states=sol.sol(times).T;fs=[field(s) for s in states];state=sol.y[:4,-1];en=sol.y[4:,-1];endU=field(state)[3];res=en[0]-sum(en[1:])-(endU-startU)
    for t,s,f in zip(times,states,fs):wri.writerow([cy,leg,t0+t,t,*s[:4],*f,*(cum+s[4:])]);
    rows.append(dict(face=face,locked=locked,cycle=cy,leg=leg,T_s=T,**dict(zip(energy,en)),delta_store_J=endU-startU,end_store_J=endU,residual_J=res,abs_peak_V=max(abs(f[1]) for f in fs),min_V=min(f[1] for f in fs),max_V=max(f[1] for f in fs),end_dx_m=state[2]-xr,max_excursion_m=max(abs(states[:,2]-xr))))
    t0+=T;cum+=en
 return rows
if __name__=='__main__':
 rows=sum((solve(f,l) for f in ('solid','slots') for l in (False,True)),[]);(H/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 for r in rows:
  if r['leg']=='isolated': print(r['face'],r['locked'],r['cycle'],'isolation fJ/useful, pJ/rail, uV/min:max, um/travel',r['useful_J']*1e15,r['rail_J']*1e12,r['min_V']*1e6,r['max_V']*1e6,r['max_excursion_m']*1e6)
 for f in ('solid','slots'):
  for l in (False,True):
   rr=[r for r in rows if r['face']==f and r['locked']==l and r['cycle']==2]; print(f,l,'cycle2 nJ rail, pJ useful (incl switching), pJ endpoint, um dx',sum(r['rail_J'] for r in rr)*1e9,sum(r['useful_J'] for r in rr)*1e12,rr[-1]['end_store_J']*1e12,rr[-1]['end_dx_m']*1e6)
 print('largest leg closure in fJ',max(abs(r['residual_J']) for r in rows)*1e15)
 lock=next(r for r in rows if r['locked'] and r['face']=='solid' and r['cycle']==1 and r['leg']=='isolated');assert abs(lock['useful_J']/2.26225e-16-1)<.02 and abs(lock['rail_J']/4.32067e-12-1)<.01,'locked cross-check against ngspice failed';assert max(abs(r['residual_J']) for r in rows)<1e-17
