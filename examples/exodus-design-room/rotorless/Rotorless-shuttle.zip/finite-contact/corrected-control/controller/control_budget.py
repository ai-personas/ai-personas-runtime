"""Estimate the control-supply joules for relay ON intervals in a timed target file. Not a measurement. Assumes ideal delays by default, constant sink drop, rectangular currents, identical coils; ignores transients, timer and base drive. Do not add results to a measurement of this same supply."""
import argparse,csv,json,math
from collections import defaultdict

def budget(path,V,R,drop):
 if not (all(math.isfinite(v) for v in (V,R,drop)) and V>drop>=0 and R>0): raise ValueError('require V > drop >= 0 and R > 0')
 groups=defaultdict(list)
 with open(path,newline='') as f:
  for row in csv.DictReader(f): groups[int(row['cycle'])].append((int(row['command_us']),row['channel'],int(row['on'])))
 if not groups: raise ValueError('no transitions')
 out=[]; current=(V-drop)/R
 for cyc,rows in sorted(groups.items()):
  on={}; dwell=defaultdict(float)
  for t,ch,s in sorted(rows):
   if ch not in ('charge','clamp','reset') or s not in (0,1) or (ch in on)==bool(s): raise ValueError(('invalid command edge',cyc,t,ch,s))
   if s:on[ch]=t
   else:dwell[ch]+=(t-on.pop(ch))*1e-6
  if on or set(dwell)!={'charge','clamp','reset'}:raise ValueError('incomplete cycle')
  T=sum(dwell.values()); out.append(dict(cycle=cyc,on_seconds=dict(dwell),coil_current_A=current,supply_J=V*current*T,coil_heat_J=current**2*R*T,sink_heat_J=drop*current*T))
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('csv');p.add_argument('--volts',type=float,default=5.);p.add_argument('--coil-ohm',type=float,default=500.);p.add_argument('--sink-drop-V',type=float,default=1.);a=p.parse_args();print(json.dumps(budget(a.csv,a.volts,a.coil_ohm,a.sink_drop_V),indent=2))
