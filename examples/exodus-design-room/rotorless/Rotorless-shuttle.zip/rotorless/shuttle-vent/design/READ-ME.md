# Slotted fixed-electrode shuttle — digital design variant

Start with `AIRFILM.md` for the reason to use slots and the assumptions that could negate their benefit. Use `BOM.csv` and **this directory’s** `export/stator-YZ.dxf` for both fixed electrodes; do not substitute the solid-face profile. The moving plate is unchanged. `SOLID-BASELINE.md` is background on the parent design, not the electrical or damping specification for this variant.

**Model interface:** Positive displacement is toward LOAD. The two gaps at mechanical rest are 0.375 mm (LOAD) and 0.625 mm (REF). Use 1371.80 mm² electrical overlap on each side; use the gap-dependent viscous coefficient in `AIRFILM.md`, not a constant damping value taken from the parent. At rest the ideal capacitances are 32.390 and 19.434 pF, excluding fringing and parasitics. The design does not predict an energy source beyond the charge supplied. Actual damping, capacitance, useful electrical output and full-cycle return have not been measured.

**Rebuild from this directory:** Run `/usr/bin/python3 make.py` with the CAD dependencies used by the source, then `python3 airfilm.py` with NumPy and SciPy. CAD/CAM exports are in `export/`; the air-film mesh comparison is `airfilm-results.json`. Digital review only, not authorization to fabricate or energize.

---

# Through-vented fixed electrodes — alternate geometry, not a measured generator
Run `python make.py` here with CadQuery 2 and ezdxf. STEP and millimetre DXF files are written under `export/`. SOLID-BASELINE.md describes the common mount, suspension, setup and tolerances. Its electrical and travel estimates apply only to the solid faces. Replace **both** original stators with the slotted profile; retain the moving plate and all other BOM items. Do not back the slots with adhesive, a mounting plate or a sealed cover.

Each 1 mm thick stator has four 36 × 1.6 mm through slots, semicircular ends R0.8, midway up the 40 mm active square at Y = −12, −4, +4 and +12 mm. The 2 mm end lands keep the plate continuous; inner webs are 6.4 mm wide. Use the four internal finished-boundary profiles as well as the existing terminal hole and exterior on stator-YZ.dxf. Kerf/tool compensation and fixturing depend on process. Flatness after slot cutting is unverified. The assembly script checks one connected stator solid and a clear rear outlet corridor per slot. This establishes geometric access, not the actual flow resistance. Ideal capacitance excludes fringe fields at the new slot edges. Research/digital design only.
