'''Normal squeeze-film damping: open square edges and nominally ambient slot mouths.
Python 3, numpy, scipy. Geometry in metres; solve -laplacian(u)=1. For approach
speed v, pressure p=12*mu*v*u/gap**3. Positive c is a resistance to motion.
'''
import numpy as np, math, json
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from pathlib import Path
mu=1.81e-5; side=.04; gs=[.000375,.000625]
def solve(n, slotted):
    d=side/n; t=(np.arange(n)+.5)*d-side/2; y,z=np.meshgrid(t,t,indexing='ij'); active=np.ones((n,n),bool)
    if slotted:
        for yc in (-.012,-.004,.004,.012): active &= (y-yc)**2+np.maximum(abs(z)-.0172,0)**2>(.0008)**2
    i,j=np.nonzero(active); ix=np.full((n,n),-1); k=np.arange(len(i)); ix[i,j]=k
    rows=[];cols=[];vals=[]; diag=np.zeros(len(i))
    for di,dj in [(-1,0),(1,0),(0,-1),(0,1)]:
        a=i+di;b=j+dj; on=(a>=0)&(a<n)&(b>=0)&(b<n); ng=np.full(len(i),-1);ng[on]=ix[a[on],b[on]]; shared=ng>=0
        diag+=np.where(shared,1,2) # boundary half a cell from centre
        rows.extend(k[shared]);cols.extend(ng[shared]);vals.extend(-np.ones(sum(shared)))
    rows.extend(k);cols.extend(k);vals.extend(diag);u=spsolve(coo_matrix((vals,(rows,cols)),shape=(len(i),len(i))).tocsr(),np.full(len(i),d*d)); G=float(u.sum()*d*d)
    return {'cells_per_side':n,'slotted':slotted,'land_m2':len(i)*d*d,'integral_m4':G,'c_rest_Ns_m':12*mu*G*sum(g**-3 for g in gs)}
rows=[solve(n,s) for s in (False,True) for n in (100,200,400)]
# Square Poiseuille series (integrated rectangular-duct velocity with unit forcing).
exact=side**4/12*(1-192/math.pi**5*sum(math.tanh(j*math.pi/2)/j**5 for j in range(1,100,2)))
assert abs(rows[2]['integral_m4']/exact-1)<.001
assert abs(rows[4]['integral_m4']/rows[5]['integral_m4']-1)<.06
# Secondary scale only: assign entire displaced volume equally to four ducts, take
# straight rectangular portion 34.4 mm long across Y=1.6 mm, airflow depth 1 mm.
# Laminar developed-flow expression; real ends, approach and bypass not described.
w=.0016; b=.0344; depth=.001; R=12*mu*depth/(b*w**3*(1-.63*w/b)); cscale=2*R/4*side**4
result={'viscosity_Pa_s':mu,'rest_gaps_m':gs,'square_integral_series_m4':exact,'mesh':rows,'one_slot_developed_R_Pa_s_m3':R,'two_faces_equal_duct_flow_scale_Ns_m':cscale}; print(json.dumps(result,indent=2));Path('airfilm-results.json').write_text(json.dumps(result,indent=2)+'\n')
