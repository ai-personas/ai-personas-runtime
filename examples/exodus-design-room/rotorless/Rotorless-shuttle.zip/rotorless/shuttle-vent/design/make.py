'''Parametric rotorless differential capacitor. Millimetres, global X to LOAD, Z up.
Run in this directory with Python, CadQuery 2 and ezdxf. Profiles are tool-centre-uncompensated finished boundaries.'''
from pathlib import Path
import math, json, cadquery as cq, ezdxf
out=Path('export');out.mkdir(exist_ok=True)
t=.300; D=.500; xr=.125; L=122.58; wh=.025; H=46.25; eye=24.; top=eye+L
# Cut faces in the YZ plane, coordinates (y,z). Header is integral with shuttle.
move=[(-20,-20),(20,-20),(20,H-20),(-20,H-20)]
# Two bottom tongues locate each stator. Terminal tab outside active overlap.
stat=[(-20,-20),(-17,-20),(-17,-29),(-12,-29),(-12,-20),(12,-20),(12,-29),(17,-29),(17,-20),(20,-20),(20,8),(27,8),(27,14),(20,14),(20,20),(-20,20)]
bridge=[(-35,-26),(-29,-26),(-29,top),(29,top),(29,-26),(35,-26),(35,top+6),(-35,top+6)]
def profile(name,points,holes,thick):
    doc=ezdxf.new('R2010');doc.units=4;m=doc.modelspace();m.add_lwpolyline(points,close=True)
    p=cq.Workplane('YZ').polyline(points).close().extrude(thick/2,both=True)
    for y,z,d in holes:
        m.add_circle((y,z),d/2);p=p.cut(cq.Workplane('YZ').center(y,z).circle(d/2).extrude(thick,both=True))
    doc.saveas(out/(name+'-YZ.dxf'));return p
mov=profile('shuttle',move,[(-18,eye,.6),(18,eye,.6)],t)
# Inner faces at +/-0.650, centers +/-1.150. REF stator is rotated about vertical.
fixed=profile('stator',stat,[(24,11,1.5)],1)
# Through-slots: straight sides with semicircular ends. YZ cut profile in mm.
ys=(-12,-4,4,12); width=1.6; length=36.; r=width/2; a=length/2-r
cutfile=out/'stator-YZ.dxf'; cutdoc=ezdxf.readfile(cutfile)
for y in ys:
    fixed=fixed.cut(cq.Workplane('YZ').center(y,0).slot2D(length,width,90).extrude(2,both=True))
    cutdoc.modelspace().add_lwpolyline([(y+r,-a,0),(y+r,a,1),(y-r,a,0),(y-r,-a,1)],format='xyb',close=True)
cutdoc.saveas(cutfile)
assert len(fixed.solids().vals())==1
area=1600-len(ys)*(2*a*width+math.pi*r*r)
frame=profile('yoke',bridge,[],6)
def line_x(y): return xr+math.copysign(t/2+wh/2,y)
topdoc=ezdxf.new('R2010');topdoc.units=4
for y in (-18,18):topdoc.modelspace().add_circle((line_x(y),y),.30)
topdoc.saveas(out/'yoke-XY-drill.dxf')
for y in (-18,18):frame=frame.cut(cq.Workplane('XY').workplane(offset=top-1).center(line_x(y),y).circle(.30).extrude(8))
# Insulating base with 4 pocket slots and two yoke sockets: open from z=-24.
base=cq.Workplane('XY').box(45,78,8).translate((0,0,-28));face=D+t/2
pockets=[]
for s in (-1,1):
    for y in (-14.5,14.5):pockets.append((s*(face+.5),y,1.08,5.15,5.0))
for y in (-32,32):pockets.append((0,y,6.12,6.12,2.0))
for x,y,dx,dy,h in pockets:base=base.cut(cq.Workplane('XY').box(dx,dy,h+.1).translate((x,y,-24-h/2+.05)))
doc=ezdxf.new('R2010');doc.units=4;m=doc.modelspace()
for x,y,w,b,layer in [(0,0,45,78,'OUTLINE')]+[(x,y,w,b,'DEPTH_'+str(h).replace('.','p')+'mm') for x,y,w,b,h in pockets]:
    if layer not in doc.layers:doc.layers.add(layer)
    m.add_lwpolyline([(x-w/2,y-b/2),(x+w/2,y-b/2),(x+w/2,y+b/2),(x-w/2,y+b/2)],close=True,dxfattribs={'layer':layer})
# Plunge corner reliefs before pocket finishing; rectangle is finished tangent wall line.
for x,y,w,b,h in pockets:
    layer='RELIEF_D0p8_DEPTH_'+str(h).replace('.','p')+'mm'
    if layer not in doc.layers:doc.layers.add(layer)
    for xx in (x-w/2,x+w/2):
        for yy in (y-b/2,y+b/2):
            m.add_circle((xx,yy),.4,dxfattribs={'layer':layer})
            base=base.cut(cq.Workplane('XY').workplane(offset=-24-h).center(xx,yy).circle(.4).extrude(h+.1))
doc.saveas(out/'base-XY-top.dxf')
assy=cq.Assembly(name='rotorless_shuttle'); parts={}
def add(n,p,xyz=(0,0,0)):
    p=p.translate(xyz);parts[n]=p.val();assy.add(p,name=n);cq.exporters.export(p,str(out/(n+'.step')))
add('base',base);add('yoke',frame);add('load',fixed,(face+.5,0,0));add('ref',fixed.rotate((0,0,0),(0,0,1),180),(-face-.5,0,0));add('moving',mov,(xr,0,0))
# Lines show effective centres only; termination wraps/adhesive not modelled.
for i,y in enumerate((-18,18)):add('line'+str(i),cq.Workplane('XY').circle(wh/2).extrude(L),(line_x(y),y,eye))
assy.save(str(out/'assembly.step'))
v=parts['moving'].Volume(); mass=v*.00270;wm=2*math.pi*(wh/2)**2*L*.00896
k=mass*.001*9.80665/(L*.001)
report=dict(moving_solid_mm3=v,plate_g=mass,line_total_g=wm,k_plate_N_m=k,load_rest_mm=parts['moving'].distance(parts['load']),ref_rest_mm=parts['moving'].distance(parts['ref']),ideal_cap_load_pF=8.8541878128*(area/1000)/(D-xr),ideal_cap_ref_pF=8.8541878128*(area/1000)/(D+xr))
report['active_land_mm2']=area
# Check the full slot swept from the inner face to 10 mm behind the outer face.
# Contract cross-section slightly to avoid coincident-face artifacts on the slot wall.
for sign in (-1,1):
    for y in ys:
        probe=cq.Workplane('YZ').center(y,0).slot2D(length-.002,width-.002,90).extrude(sign*11).translate((sign*face,0,0)).val()
        for n,part in parts.items(): assert probe.intersect(part).Volume()<1e-6,(sign,y,n)
from itertools import combinations
for a,b in combinations(parts,2):
    overlap=parts[a].intersect(parts[b]).Volume(); assert overlap<1e-5,(a,b,overlap)
for key,val in [('load_rest_mm',D-xr),('ref_rest_mm',D+xr)]:assert abs(report[key]-val)<1e-5
assert abs(k-.12)<.001
(out/'geometry.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
