#!/usr/bin/env python3
"""Steady 1200 rpm target with resistive input emulation, no enforced speed.
Synthetic constants; imposed torque is an external energy port. No hardware drivers.
"""
from math import pi,sqrt,exp,log
import argparse,csv,json
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=Path('startup'));args=p.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
k=.08; rw=.25; drop=.7; eta=.9; drag=.005; J=.002; om0=1200*pi/30; pgen=(20-9)/eta
v0=k*om0-drop; i0=2*pgen/(v0+sqrt(v0*v0-4*rw*pgen)); rin=pgen/i0**2
# A converter that looks like Rin at its input draws less power at low speed.
# Its output and the feed inject POWER into the same resistive load, not two stiff voltage rails.
def point(om):
 i=max(k*om-drop,0)/(rw+rin); pg=eta*i*i*rin; pout=9+pg
 return i,pg,pout,sqrt(pout*1.25)
tau=k*i0+drag; wcond=drop/k; slope=k*k/(rw+rin); tc=J*wcond/(tau-drag); tm=J/slope
# With zero article torque it stays at rest. With stipulated torque, solve the two linear ODEs exactly.
def speed(t):return (tau-drag)*t/J if t<tc else om0-(om0-wcond)*exp(-(t-tc)/tm)
for name,T in [('no_drive',0.),('stipulated',tau)]:
 end=tc+10*tm; n=6000; old=None; E=[0.]*4
 with (args.out/(name+'.csv')).open('w') as f:
  w=csv.writer(f);w.writerow('t_s,rpm,shaft_W,input_W,load_W,load_V,i_gen_A,loss_W,kinetic_J'.split(','))
  for j in range(n+1):
   t=j*end/n; om=speed(t) if T else 0.; i,pg,po,vl=point(om); ps=T*om; loss=1+drag*om+drop*i+rw*i*i+(1-eta)*rin*i*i
   z=(ps,10,po,loss);w.writerow([t,om*30/pi,ps,10,po,vl,i,loss,.5*J*om**2]);
   if old is not None:E=[e+.5*(a+b)*end/n for e,a,b in zip(E,old,z)]
   old=z
 er=E[0]+E[1]-E[2]-E[3]-.5*J*om**2
 assert abs(er)<.0002 and abs(po-(20 if T else 9))<.002
 print(name, 'after_s',end,'rpm',om*30/pi,'load_W',po,'shaft_J,feed_J,load_J,loss_J',E,'delta_K_J',.5*J*om**2,'balance_residual_J',er)
print('Required shaft torque Nm',tau,'emulated generator-side ohms',rin,'speed settling time constant s',tm,'time to 99% speed s',tc+tm*log((om0-wcond)/(.01*om0)))
