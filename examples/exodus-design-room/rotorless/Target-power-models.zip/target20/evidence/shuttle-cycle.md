# Does the designed shuttle supply 20 W?

**No. Its simulated useful load power averages about 3.80 × 10⁻¹⁷ W (38 attowatts) over the second cycle.** The shuttle is a design for examining charge, motion and electrical conversion. It is not a 20 W generator or a model fitted to an Exodus force measurement.

## Calculation from the corrected design

In `exodus/rotorless/force-to-load-study.zip`, use `CORRECTED-CONTROLLER.md`, `finite-contact/command-timing/comparison.csv` (slotted electrodes, free shuttle, cycle 2, command timing), and the controller timing trace. The cycle lasts about 62.03 s including reset; the two-second commanded-open interval alone is not a complete cycle. The useful resistor is R2, 10 MΩ between SENSE and COM. The equally valued meter is **not** a second useful load.

| Quantity | Energy over the cycle | Energy / elapsed time |
|---|---:|---:|
| R2 heat from simulated terminal voltage | 2.355080 fJ | 3.80 × 10⁻¹⁷ W out |
| Signed work supplied by the 12 V shuttle rail | 16.8403 nJ | 2.71 × 10⁻¹⁰ W in |
| Additional relay-branch supply estimate | 4.800936 J | 0.0774 W in |
| Requested load for the same duration | about 1,241 J | 20 W out |

For example, `2.355080e-15 J / 62.03 s = 3.80e-17 W`. The target is about **5.27 × 10¹⁷ times** that modeled mean. This is a comparison of powers, not a scalable array design. Even before counting the relays, the useful-load energy divided by shuttle-rail work is only **1.40 × 10⁻⁷**. The relay figure assumes 5 V supply, 500 Ω coils and 1 V sink drop and omits timer/base drive and transients; it is not a measurement of total power. Commanded open does not mean zero source current: the finite-resistance model admits 16.1162 pJ through the open supply contact in the two-second window.

## What result would change the conclusion?

A charged structure can exert force without a continuing charging current, just as a compressed spring can. Electrical generation requires motion against the electrical load's reaction. Accounting for the reset is decisive: for the complete device, `other energy in + decrease in stored energy = useful electrical output − electrical input + other energy out`. A 20 W load on a 10 W feed for one minute needs at least 600 J from another input or stored energy, assuming no measurement error. With restored charge, motion and other storage, that shortfall must be supplied anew every minute. A surplus relative to one electrical port alone does not establish a new source.

The shuttle predicts a pulse from ordinary stored-field conversion. The separate force note concerns the travel an Exodus article **would need** if a reported force persisted under load; there is no evidence that our modeled shuttle has that force. To assess a candidate generator requires synchronized measurements of loaded force and motion after verified isolation, electrical power at every port, other energy exchanges, and endpoint storage through reset, with calibration, controls and uncertainties. Neither these calculations nor a finite burst establish sustained generation. Research and digital design only.
