#!/usr/bin/env python3
"""Target-scale averaged electrical ports. SI throughout. No empirical force law."""
import argparse,csv,json,math
from pathlib import Path

def run(a):
    vals=[a.pin,a.vout,a.load,a.cap,a.esr,a.vlo,a.vhi,a.idle,a.ein,a.eout,a.step_v,a.stroke,a.hz,a.emech]
    if not all(map(math.isfinite,vals)) or not (min(a.pin,a.vout,a.load,a.cap,a.vlo,a.step_v,a.stroke,a.hz)>0 and a.vhi>a.vlo and a.esr>=0 and a.idle>=0 and 0<min(a.ein,a.eout,a.emech)<=max(a.ein,a.eout,a.emech)<=1): raise ValueError('invalid physical parameters')
    pout=a.vout**2/a.load
    n=math.ceil((a.vhi-a.vlo)/a.step_v)
    # In each bin, current is evaluated at the midpoint internal capacitor voltage.
    # The implicit I law includes ESR: P_delivered_by_storage = I*(Vc-I*R).
    def phase(name,v0,v1,pin,load,t):
        net=load/a.eout + a.idle-pin*a.ein
        if (v0-v1)*net<=0: raise ValueError(name+': setpoints unreachable with selected powers')
        if net>0 and a.vlo**2<=4*a.esr*net: raise ValueError(name+': ESR collapse at or above lower voltage')
        trace=[]
        for j in range(n):
            u=v0+(v1-v0)*j/n; v=v0+(v1-v0)*(j+1)/n; mid=(u+v)/2
            i=2*net/(mid+math.sqrt(mid*mid-4*a.esr*net)); bus=mid-i*a.esr
            dt=a.cap*(u-v)/i; dq=a.cap*(v-u); ds=dq*mid
            ein=pin*dt; eout=load*dt
            loss=((1-a.ein)*pin + load*(1/a.eout-1)+a.idle+i*i*a.esr)*dt
            trace.append(dict(phase=name,t0_s=t,dt_s=dt,v0_V=u,v1_V=v,vc_mid_V=mid,vbus_mid_V=bus,cap_out_A=i,meter_in_W=pin,load_W=load,Ein_J=ein,Eload_J=eout,loss_J=loss,dUcap_J=ds,residual_J=ein-eout-loss-ds));t+=dt
        return trace,t
    tr,t=phase('burst',a.vhi,a.vlo,0 if a.isolate else a.pin,pout,0)
    rb,end=phase('refill',a.vlo,a.vhi,a.pin,0,t); rows=tr+rb
    folder=Path(a.out);folder.mkdir(parents=True,exist_ok=True)
    with (folder/'cycle.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    total=lambda k: math.fsum(r[k] for r in rows)
    e=total('Eload_J');g=total('Ein_J');summary=dict(model='averaged ports, synthetic',burst_s=t,refill_s=end-t,period_s=end,load_peak_W=pout,load_mean_W=e/end,input_mean_W=g/end,load_J=e,input_J=g,loss_J=total('loss_J'),dUcap_J=total('dUcap_J'),cycle_residual_J=total('residual_J'),restored_ratio=e/g,max_abs_cap_A=max(abs(r['cap_out_A']) for r in rows),vbus_range_V=[min(r['vbus_mid_V'] for r in rows),max(r['vbus_mid_V'] for r in rows)])
    (folder/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (folder/'port_intervals.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['start_s', 'end_s', 'in_lo_W', 'in_hi_W', 'out_lo_W', 'out_hi_W']);w.writerow([0,t,0 if a.isolate else a.pin,0 if a.isolate else a.pin,pout,pout]);w.writerow([t,end,a.pin,a.pin,0,0])
    # Continuous architecture, distinct from the buffer: eta_feed is represented by ein.
    # s=share of electrical input allocated directly to useful load; remaining input reserved for controls.
    # Shaft power is already net of mechanical return/reset costs; the mechanical converter has emech efficiency.
    budget=[]
    for share in (0,.5,1):
        direct=a.pin*share*a.ein; mech=max(0,pout-direct)/a.emech
        budget.append(dict(input_fraction_to_load=share,input_reserved_W=(1-share)*a.pin,electrical_direct_W=direct,net_shaft_W_required=mech,net_work_J_per_cycle=mech/a.hz,mean_force_difference_N=mech/(a.hz*a.stroke),equal_opposite_stroke_force_N=mech/(2*a.hz*a.stroke)))
    with (folder/'continuous.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=budget[0]);w.writeheader();w.writerows(budget)
    print(json.dumps(summary));print(json.dumps(budget))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k,x in dict(pin=10.,vout=5.,load=1.25,cap=1.,esr=.05,vlo=9.,vhi=12.,idle=.2,ein=.9,eout=.9,step_v=.005,stroke=.01,hz=1.,emech=.8).items(): p.add_argument('--'+k,type=float,default=x)
    p.add_argument('--isolate',action='store_true',help='zero input power during burst; restore storage using input afterward');p.add_argument('--out',default='results');run(p.parse_args())
