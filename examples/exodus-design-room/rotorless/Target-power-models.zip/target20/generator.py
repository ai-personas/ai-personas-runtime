#!/usr/bin/env python3
"""Conditional DC generator load line; generate CSV including impossible speed cases. Not a force law."""
import argparse,math,csv,sys
p=argparse.ArgumentParser(description=__doc__)
for k,v in dict(pin=10.,load_w=20.,share=1.,eff_feed=.9,eff_gen=.9,ke=.08,rw=.25,drop=.7,drag=.005).items():p.add_argument('--'+k,type=float,default=v)
p.add_argument('--rpm',nargs='+',type=float,default=[300,600,1200,2400]);a=p.parse_args()
if not all(math.isfinite(x) for x in [a.pin,a.load_w,a.share,a.eff_feed,a.eff_gen,a.ke,a.rw,a.drop,a.drag,*a.rpm]) or not(0<=a.share<=1 and 0<a.eff_feed<=1 and 0<a.eff_gen<=1 and min(a.ke,a.rw,a.load_w,*a.rpm)>0 and min(a.pin,a.drop,a.drag)>=0):p.error('invalid physical parameters')
h=a.pin*a.share*a.eff_feed; g=(a.load_w-h)/a.eff_gen
if g<=0:p.error('load already covered by feed')
w=csv.writer(sys.stdout);w.writerow('rpm,status,emf_V,max_dc_W,dc_terminal_V,winding_A,net_shaft_torque_Nm,net_shaft_W,direct_to_load_W,load_W,loss_all_W'.split(','))
for rpm in a.rpm:
    om=rpm*math.tau/60; emf=a.ke*om; v=emf-a.drop; mx=max(v,0)**2/(4*a.rw); disc=v*v-4*a.rw*g
    if v<=0 or disc<0:w.writerow([rpm,'insufficient_emf_or_power',emf,mx,'','','','',h,'','']);continue
    i=2*g/(v+math.sqrt(disc)); vt=v-i*a.rw; tq=a.ke*i+a.drag; shaft=om*tq
    loss=a.pin-h+(1-a.eff_gen)*vt*i+i*i*a.rw+i*a.drop+a.drag*om
    assert abs(i*vt-g)<1e-8 and abs(shaft+a.pin-a.load_w-loss)<1e-8
    w.writerow([rpm,'conditional',emf,mx,vt,i,tq,shaft,h,a.load_w,loss])
