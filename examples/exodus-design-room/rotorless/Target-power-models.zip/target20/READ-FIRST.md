# Ten watts in, twenty watts to the load?

**Result:** 5 V across 1.25 Ω is 4 A and 20 W. Ten watts at the electrical input is not enough to sustain that output by ordinary electrical conversion. A source isolated after charging can supply a burst. A generator can sustain 20 W if someone supplies the missing work. Neither case shows that Exodus supplies that work. All numbers here are calculated; there are no experimental traces in this folder.

## Three cases with the same useful load

| Case | Power at the electrical input | Other energy source | Power at the useful load |
|---|---:|---|---|
| Buffered, feed left on | 10 W throughout | 1 F buffer falls from 12 to 9 V | 20 W for 2.332 s; 0 W for 3.594 s to refill. Mean 7.871 W. |
| Buffered, feed disconnected | 0 W during burst; 10 W during refill | Same 31.5 J drop in stored field energy | 20 W for 1.390 s, then 0 W during refill. Mean 5.579 W over both phases. |
| Continuous, two power inputs | 10 W throughout; 9 W reaches load | **14.259 W of shaft power** at 1,200 rpm | 20 W at the operating point. 4.259 W lost. With zero shaft drive from rest: 9 W. |

**Read the two drawings of the bookkeeping differently.** In the burst model the load converter regulates 5 V or is disabled; endpoint voltages refer to the capacitor *inside* its series resistance, not loaded bus voltage. In the continuous model two converters inject power into one resistive load. Its voltage is √(Pload × 1.25 Ω), not a prescribed constant. It reaches 5 V at the design point; this is not a hardware regulator design for arbitrary loads. See `ports.svg` for this continuous operating point.

The fed burst exports 46.648 J for 59.262 J in over the restored cycle: 12.615 J goes to modeled conversion, idle and resistive losses. A meter gated only on the burst would indicate 20/10 = 2. A meter on the isolated burst would have zero input in its denominator, so that ratio is **undefined**, not infinite efficiency. Each starting charge belongs in the account. Actual capacitors, controls and converters have additional state, bandwidth, limits and losses.

## Run the models (offline, in this directory)

```
python3 power20.py --out fed
python3 power20.py --isolate --out isolated
python3 generator.py > generator.csv
python3 start_from_rest.py --out startup
python3 check_buffer.py
```

Python 3 standard library; the last test also needs `ngspice` on PATH. `buffer.cir` is the independent transient circuit check. `power20.py --help` lists the buffer, efficiency, stroke and frequency inputs. Each `cycle.csv` row is a complete interval with energy in joules, not an instantaneous power sample. `result.json` totals a full discharge and refill ending at the original capacitor voltage. `port_intervals.csv` is generated for each run from its exact two phase intervals for comparison with the metrology study. Both means and their lower/upper columns are synthetic exact phase values, not calibrated bounds.

`continuous.csv` is a **different calculation**, with no buffer, using a flat 80% mechanical-to-load efficiency. `generator.csv` instead uses an explicit voltage constant, winding resistance, rectifier drop, mechanical drag and converter efficiency. Do not add both sets of losses. `startup/*.csv` are start-from-rest histories, not restored cycles. The load is not at its final voltage during startup. `loss_W` includes feed conversion, bearing drag, rectifier, winding and generator converter loss. Final kinetic energy is retained, not exported. The startup ODE includes only modeled Coulomb drag and resistive electrical loading. A real rotor's cogging, stiction, inductance and converter start threshold are not established.

## Where the extra power would enter

At 1,200 rpm the illustrative PM generator has EMF kω = 10.053 V. After a 0.7 V rectifier drop and 0.25 Ω winding drop at 1.356 A, its terminal voltage is 9.014 V. The generator converter takes 12.222 W there and supplies 11 W to the load. The feed converter supplies the other 9 W. At steady state the shaft provides (kI + drag)ω = 14.259 W (k = 0.08 in SI; drag = 0.005 N·m). The energy ratio with **both** inputs is 20/(10 + 14.259) = 0.824. At 300 rpm even the maximum available generator terminal power is only 3.288 W. A converter cannot cure an inadequate prime mover.

In `start_from_rest.py` the generator converter emulates a 6.648 Ω input resistance, so shaft loading rises with speed rather than demanding full constant power at zero rpm. A constant 0.11347 N·m source accelerates the rotor to 99% of design speed in 9.93 s. With no such torque it stays still. The imposed torque is an explicit *input*, not predicted by the electrical network. This example spends all 10 electrical watts on the direct branch: if charge, switching, control or field maintenance consumes some of them, the shaft requirement rises. A reaction torque on an external support does not by itself supply work; count every port with force times velocity or torque times angular velocity at its point of application.

## What would the proposed propulsion theory have to predict?

See `FORCE-TO-WORK.md`. A held force does zero work on a stationary mount. A force that follows position reversibly can do work outbound but takes it back on return. Even a reproducible nonzero mechanical cycle integral does not identify the source of that work. For a complete cycle use **E_load − E_all_inputs + ΔU_internal = −E_loss** for ordinary conversion, with inputs positive inward, ΔU = final minus initial and E_loss outward/discarded. Include any heat absorbed and mechanical drive as inputs; do not subtract an unmeasured loss to claim a gain. Bound unobserved reservoirs, and do not count the same shaft work twice as both an internal transfer and an external input.

The combined mechanical CAD/CAM, PCB, schematic, Gerbers and BOM issued previously in `exodus/rotorless/force-to-load-study.zip` describe a low-power research shuttle, **not this 20 W generator**. Its modeled load is the small readout resistor; a 5 V load drawing 4 A is not interchangeable with it. No power-stage part numbers, winding design, safe ratings or manufacturing release are inferred from the target power diagram. Do not order, fabricate or energize any design on the basis of this study.

## Compare the target with a reported force

US patent application **US 2023/0121805 A1**, Fig. 22 (9 June 2019, “Encapsulated Epoxy Test 8”), labels two +25 kV intervals 220 µN and 255 µN. This is a supported specimen: neither tangential drive under load nor verified isolation follows from that plot. See [Ravi’s run-specific source note](evidence/reported-force.md) for the source and limitations. Do not combine different specimens into one run.

Suppose, favorably, that 255 µN acted in the productive direction for an entire 10 mm stroke: that would be **2.55 µJ**. At one productive stroke per second this is 2.55 µW before return work or electrical losses. For the illustrative rotating machine, the rim at 50 mm radius and 1,200 rpm travels 6.283 m/s. Even an ideally following tangential force of that magnitude would contribute only **1.60 mW mechanically** there. Against the required 14.259 W shaft input, the force requirement is about **8,900 times** the labeled force. This division is a scale comparison, not a proposal to gang 8,900 articles: mass, drive, isolation, drag, coupling, orientation and reset do not scale for free. No such rotating thrust was measured in Fig. 22.

The [corrected shuttle comparison](evidence/shuttle-cycle.md) answers a different question. Its tiny simulated resistor heat comes from ordinary electrostatic transduction and is not an estimate of a proprietary article’s thrust.

**Bottom line for the 20 W load:** the buffer has an identifiable, finite reservoir; the steady generator has an identifiable but *additional* power port. Neither supplies 20 W continuously from 10 W alone. An energy-source hypothesis must predict the measured loaded force–travel integral and its sign through reset without inserting the missing power as a free parameter.
