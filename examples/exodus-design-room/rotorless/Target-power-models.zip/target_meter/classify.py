"""Finite run energy audit. CSV and endpoint JSON per README; exact rational arithmetic."""
import csv,json,sys
from fractions import Fraction as F
from pathlib import Path

def bounds(pair,signed=False):
    if not isinstance(pair,(list,tuple)) or len(pair)!=2: raise ValueError('expected two bounds')
    a,b=[F(str(x)) for x in pair]
    if b<a or (not signed and a<0): raise ValueError('invalid bounds')
    return a,b

def target(i,o):
    if i[1]<=10 and o[0]>=20: return 'met'
    if i[0]>10 or o[1]<20: return 'missed'
    return 'indeterminate'

def audit(rows,meta):
    en=[F(0)]*4; t=None; n=0; counts={k:0 for k in ['met','missed','indeterminate']}
    for r in rows:
        a,b=F(r['start_s']),F(r['end_s']); dt=b-a
        if dt<=0 or (t is not None and a!=t): raise ValueError('nonpositive interval, gap or overlap')
        if not n: start=a
        t=b; n+=1
        i=bounds([r['in_lo_W'],r['in_hi_W']]); o=bounds([r['out_lo_W'],r['out_hi_W']]); counts[target(i,o)]+=1
        en=[x+dt*y for x,y in zip(en,i+o)]
    if not n: raise ValueError('empty run')
    duration=t-start; p=[e/duration for e in en]; demand=[en[2]-en[1],en[3]-en[0]]
    # Eload - Eelec - Eother - (Ustart-Uend); losses not deducted. Positive is a lower bound on missing supply, subject to all bounds.
    s=meta['net_storage_release_J']; h=meta['other_input_J']; residual=None
    if s is not None: s=bounds(s,True)
    if h is not None: h=bounds(h)
    if h is None or s is None: interpretation='indeterminate: unbounded contribution'
    else:
        residual=[demand[0]-s[1]-h[1],demand[1]-s[0]-h[0]]
        interpretation=('positive residual under stated bounds' if residual[0]>0 else 'no positive residual required' if residual[1]<=0 else 'residual sign unresolved')
    def enc(pair): return None if pair is None else list(map(str,pair))
    return dict(duration_s=str(duration),bins=n,bin_counts=counts,all_bin_averages='missed' if counts['missed'] else 'indeterminate' if counts['indeterminate'] else 'met',run_average_target=target(p[:2],p[2:]),input_J=enc(en[:2]),load_J=enc(en[2:]),load_minus_electrical_J=enc(demand),residual_J=enc(residual),energy_finding=interpretation)

if __name__=='__main__':
    if len(sys.argv)!=3: sys.exit('usage: python3 classify.py bins.csv bounds.json')
    try:
        with open(sys.argv[1],newline='') as f: result=audit(csv.DictReader(f),json.loads(Path(sys.argv[2]).read_text(),parse_float=str))
        print(json.dumps(result,indent=2))
    except (ValueError,KeyError,TypeError,ZeroDivisionError,OSError) as e: sys.exit('invalid record: '+str(e))
