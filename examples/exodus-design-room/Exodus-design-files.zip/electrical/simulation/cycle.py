#!/usr/bin/env python3
"""Ideal disconnect, finite C leakage, voltmeter across C. Exact piecewise RC. SI only."""
import math,csv,sys,argparse
p=argparse.ArgumentParser(description=__doc__)
for n,default in dict(vs=5.,C=.001,R1=1000.,R2=1000.,Rleak=1.e6,Rmeter=10.e6,charge=5.,hold=30.,discharge=8.,dt=.02).items():p.add_argument('--'+n,type=float,default=default)
a=p.parse_args(); assert 0<a.vs<=5 and min(a.C,a.R1,a.R2,a.Rleak,a.Rmeter,a.dt)>0 and min(a.charge,a.hold,a.discharge)>=0
wr=csv.writer(sys.stdout);wr.writerow('phase,t_s,Vcap_V,Iin_A,Iload_A,Ein_J,Eload_J,Eloss_J,Ucap_J,residual_J'.split(','));t=v=ein=eout=loss=0.
for phase,dur in [('charge',a.charge),('hold',a.hold),('discharge',a.discharge)]:
    gs=(1/a.R1 if phase=='charge' else 0.); gl=(1/a.R2 if phase=='discharge' else 0.); gp=1/a.Rleak+1/a.Rmeter; g=gs+gl+gp; A=a.vs*gs/g; tau=a.C/g; B=v-A; n=max(1,math.ceil(dur/a.dt)); ei0,eo0,L0=ein,eout,loss
    for i in range(n+1):
        z=i*dur/n; e1=-math.expm1(-z/tau); e2=-math.expm1(-2*z/tau); v=A+B*(1-e1); I1=A*z+B*tau*e1; I2=A*A*z+2*A*B*tau*e1+B*B*tau*e2/2
        ein=ei0+a.vs*gs*(a.vs*z-I1); eout=eo0+gl*I2; loss=L0+gp*I2+gs*(a.vs*a.vs*z-2*a.vs*I1+I2); u=.5*a.C*v*v; r=ein-eout-loss-u; assert abs(r)<max(1e-10,1e-9*ein),(phase,r)
        wr.writerow([phase]+[f'{x:.12g}' for x in (t+z,v,gs*(a.vs-v),gl*v,ein,eout,loss,u,r)])
    print(f'{phase}: t={t+dur:g}s Vc={v:.6f} Ein={ein:.9g} J Eload={eout:.9g} J Ucap={u:.9g} J other_loss={loss:.9g} J',file=sys.stderr);t+=dur
