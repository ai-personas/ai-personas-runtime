"""Generate native KiCad schematic + local libraries and link board footprints.
Run in this directory, preserving board.py with this file.
"""
import re,uuid,runpy
from pathlib import Path as P
from collections import OrderedDict
from os import chdir
chdir(P(__file__).resolve().parent)
runpy.run_path('board.py')
def u(s):return str(uuid.uuid5(uuid.NAMESPACE_URL,'urn:electrical-reference:A:'+s))
root=u('sheet'); ids={r:u('instance:'+r) for r in ['R1','R2','C1','TP1','TP2','TP3','TP4','H1','H2','H3','H4']}
b=P('reference.kicad_pcb').read_text(); fps={}
def matchfp(m):
 f=m[0]; name=re.search('footprint "Reference:([^"]+)"',f)[1]; ref=re.search('fp_text reference "([^"]+)"',f)[1]
 if name not in fps:
  lib=f.replace('Reference:'+name,name).replace('"'+ref+'"','"REF**"',1);lib=re.sub(r'\(fp_text value "[^"]+"','(fp_text value "'+name+'"',lib);lib=re.sub(r' \(at [^()]+\) \(attr',' (attr',lib,count=1);lib=re.sub(r' \(net \d+ "[^"]+"\)','',lib);lib=lib.replace('(layer "F.Cu")','(version 20221018) (generator pcbnew) (layer "F.Cu")',1);P('Reference.pretty/'+name+'.kicad_mod').write_text(lib+'\n');fps[name]=True
 return f.replace('(attr through_hole)',f'(path "/{ids[ref]}") (attr through_hole)')
# Local schematic labels export as sheet-relative names; retain these in PCB nets.
b=re.sub(r'\(net (\d+) "(IN\+|CAP\+|LOAD\+|COM)"\)',r'(net \1 "/\2")',b)
b=re.sub(r'\(footprint [\s\S]*?\(layers "\*\.Cu" "\*\.Mask"\)(?: \(net [^()]+\))?\)\)(?=\n)',matchfp,b);P('reference.kicad_pcb').write_text(b)
P('fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "Reference")(type "KiCad")(uri "${KIPRJMOD}/Reference.pretty")(options "")(descr "Reference board footprints")))\n');P('sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "Reference")(type "KiCad")(uri "${KIPRJMOD}/Reference.kicad_sym")(options "")(descr "Reference symbols")))\n')
eff='(effects (font (size 1.27 1.27)))'; stroke='(stroke (width 0.254) (type default))';fill='(fill (type none))'
def poly(*a):return '(polyline (pts '+' '.join(f'(xy {x} {y})' for x,y in a)+f') {stroke} {fill})'
def pin(n,x,y,angle,length):return f'(pin passive line (at {x} {y} {angle}) (length {length}) (name "~" {eff}) (number "{n}" {eff}))'
syms={}
def sym(k,r,g,pins):
 syms[k]=f'(symbol "Reference:{k}" (pin_names (offset 0) hide) (pin_numbers hide) (in_bom yes) (on_board yes) (property "Reference" "{r}" (at 0 0 0) {eff}) (property "Value" "{k}" (at 0 0 0) {eff}) (symbol "{k}_0_1" '+g+f') (symbol "{k}_1_1" '+pins+'))'
sym('Res','R',poly((-2.54,-1.016),(2.54,-1.016),(2.54,1.016),(-2.54,1.016),(-2.54,-1.016)),pin(1,-5.08,0,0,2.54)+pin(2,5.08,0,180,2.54))
sym('Cap','C',poly((-2.54,.508),(2.54,.508))+poly((-2.54,-.508),(2.54,-.508))+poly((-3.81,1.78),(-2.54,1.78))+poly((-3.175,1.145),(-3.175,2.415)),pin(1,0,5.08,270,4.572)+pin(2,0,-5.08,90,4.572))
sym('Loop','TP',f'(circle (center 0 3.302) (radius .762) {stroke} {fill})',pin(1,0,0,90,2.54));sym('Hole','H',f'(circle (center 0 0) (radius 1.27) {stroke} {fill})','')
P('Reference.kicad_sym').write_text('(kicad_symbol_lib (version 20231120) (generator kicad_symbol_editor)\n'+'\n'.join(s.replace('Reference:'+k,k,1) for k,s in syms.items())+')\n')
s=[f'(kicad_sch (version 20231120) (generator eeschema) (uuid {root}) (paper "A4") (title_block (title "Finite-energy reference") (rev "A") (comment 1 "5 V maximum. Not a propulsion or generation source.")) (lib_symbols '+'\n'.join(syms.values())+')']
def inst(k,r,v,fp,x,y,rx,ry,vx,vy):
 i=ids[r];s.append(f'(symbol (lib_id "Reference:{k}") (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {i}) (property "Reference" "{r}" (at {rx} {ry} 0) {eff}) (property "Value" "{v}" (at {vx} {vy} 0) {eff}) (property "Footprint" "Reference:{fp}" (at {x} {y} 0) (effects (font (size 1 1)) hide)) (instances (project "reference" (path "/{root}" (reference "{r}") (unit 1)))))')
def wire(x,y,X,Y):s.append(f'(wire (pts (xy {x} {y})(xy {X} {Y})) (stroke (width 0)(type default)) (uuid {u(str((x,y,X,Y)))}))')
def label(n,x,y):s.append(f'(label "{n}" (at {x} {y} 0) (effects (font (size 1.27 1.27)) (justify left bottom)) (uuid {u("label"+n)}))')
def text(n,x,y):s.append(f'(text "{n}" (at {x} {y} 0) (effects (font (size 1.5 1.5)) (justify left)) (uuid {u(n)}))')
inst('Res','R1','1k','Axial_10.16',76.2,76.2,76.2,70.0,76.2,72.7);inst('Res','R2','1k','Axial_10.16',152.4,76.2,152.4,70,152.4,72.7);inst('Cap','C1','1000u 16V','Radial_D10_P5',101.6,91.44,115,90,115,93)
for ref,v,x,y in [('TP1','IN+',50.8,76.2),('TP2','CAP+',101.6,76.2),('TP3','LOAD+',127,76.2),('TP4','COM',177.8,76.2)]:inst('Loop',ref,v,'Loop_5mm',x,y,x,66.04,x,68.58)
for w in [(50.8,76.2,71.12,76.2),(81.28,76.2,101.6,76.2),(101.6,76.2,101.6,86.36),(101.6,96.52,101.6,104.14),(101.6,104.14,177.8,104.14),(177.8,104.14,177.8,76.2),(157.48,76.2,177.8,76.2),(127,76.2,147.32,76.2)]:wire(*w)
for x in [101.6,177.8]:s.append(f'(junction (at {x} 76.2) (diameter 0) (color 0 0 0 0) (uuid {u("j"+str(x))}))')
for n,x,y in [('IN+',50.8,76.2),('CAP+',81.28,76.2),('LOAD+',127,76.2),('COM',101.6,104.14)]:label(n,x,y)
for i in range(4):x=60.96+i*20.32;inst('Hole','H'+str(i+1),'M3','Mount',x,127,x,120,x,123)
text('Charge: regulated 0 to +5 V at TP1 relative to TP4. Current limit 5 mA. TP3 open.',38.1,42);text('Hold: remove BOTH source leads. Discharge: bridge TP2 to TP3. Return is common on board.',38.1,48);text('Mechanical mounting holes (isolated)',38.1,114);s.append('(sheet_instances (path "/" (page "1"))))');P('reference.kicad_sch').write_text('\n'.join(s)+'\n');P('reference.kicad_pro').write_text('{}\n')
