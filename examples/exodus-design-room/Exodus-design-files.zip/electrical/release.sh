#!/bin/sh
# Run from the directory containing the native reference.* project, NOT board.py alone.
set -eu
mkdir -p reports preview fabrication
kicad-cli sch erc --exit-code-violations -o reports/erc.rpt reference.kicad_sch
kicad-cli pcb drc --schematic-parity --exit-code-violations -o reports/drc.rpt reference.kicad_pcb
kicad-cli sch export netlist -o reports/reference.net reference.kicad_sch
kicad-cli sch export pdf -o preview/schematic.pdf reference.kicad_sch
kicad-cli pcb export pdf --layers F.Silkscreen,Edge.Cuts,F.Cu -o preview/top.pdf reference.kicad_pcb
kicad-cli pcb export gerbers --layers F.Cu,B.Cu,F.Mask,B.Mask,F.Silkscreen,Edge.Cuts -o fabrication/ reference.kicad_pcb
kicad-cli pcb export drill --format excellon --excellon-separate-th --drill-origin absolute --excellon-units mm -o fabrication/ reference.kicad_pcb
