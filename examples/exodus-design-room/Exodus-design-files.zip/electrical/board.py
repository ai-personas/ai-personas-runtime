"""Parametric reference board. Run: python3 board.py"""
from pathlib import Path
p=['(kicad_pcb (version 20221018) (generator pcbnew) (general (thickness 1.6)) (paper "A4") (layers (0 "F.Cu" signal) (31 "B.Cu" signal) (36 "B.SilkS" user "b.silkscreen") (37 "F.SilkS" user "f.silkscreen") (38 "B.Mask" user) (39 "F.Mask" user) (44 "Edge.Cuts" user) (48 "B.Fab" user) (49 "F.Fab" user)) (setup (pad_to_mask_clearance 0))']
nets=['','IN+','CAP+','LOAD+','COM']
for i,n in enumerate(nets):p.append(f'(net {i} "{n}")')
def line(a,b,layer,w=.2,local=False):return f'({"fp" if local else "gr"}_line (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (layer "{layer}") (width {w}))'
def seg(a,b,n):p.append(f'(segment (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (width 0.65) (layer "B.Cu") (net {nets.index(n)}))')
def route(n,*pts):
 for a,b in zip(pts,pts[1:]):seg(a,b,n)
def fp(ref,val,kind,x,y,pads,lines=(),circle=None,refpos=(0,-2.5)):
 z=[f'(footprint "Reference:{kind}" (layer "F.Cu") (at {x} {y}) (attr through_hole)',f'(fp_text reference "{ref}" (at {refpos[0]} {refpos[1]}) (layer "F.SilkS") (effects (font (size 1 1) (thickness .16))))',f'(fp_text value "{val}" (at 0 0) (layer "F.Fab") hide (effects (font (size 1 1) (thickness .15))))']
 for a,b in lines:z.append(line(a,b,'F.SilkS',local=True))
 if circle:z.append(f'(fp_circle (center {circle[0]} {circle[1]}) (end {circle[0]+circle[2]} {circle[1]}) (width .2) (layer "F.SilkS"))')
 for num,dx,dy,dia,dr,n in pads:
  typ='thru_hole' if n else 'np_thru_hole';shape='rect' if n and num=='1' else 'circle'; net=f'(net {nets.index(n)} "{n}")' if n else '';z.append(f'(pad "{num}" {typ} {shape} (at {dx} {dy}) (size {dia} {dia}) (drill {dr}) (layers "*.Cu" "*.Mask") {net})')
 p.append('\n'.join(z)+')')
for i,(x,y) in enumerate([(4,4),(66,4),(4,41),(66,41)]):fp(f'H{i+1}','M3','Mount',x,y,[('',0,0,3.2,3.2,None)],refpos=(0,3.2 if y==4 else -3.2))
for ref,n,x,y in [('TP1','IN+',12,15),('TP2','CAP+',34,15),('TP3','LOAD+',46,15),('TP4','COM',58,31)]:
 fp(ref,n,'Loop_5mm',x,y,[('1',0,0,2.1,1,n),('1',0,5,2.1,1,n)],refpos=(0,-2));seg((x,y),(x,y+5),n)
for ref,x,n,m in [('R1',17.5,'IN+','CAP+'),('R2',52,'LOAD+','COM')]:
 box=[(1.75,-1.4),(8.41,-1.4),(8.41,1.4),(1.75,1.4)];fp(ref,'1k','Axial_10.16',x,15,[('1',0,0,2,1,n),('2',10.16,0,2,1,m)],list(zip(box,box[1:]+box[:1])),refpos=(5,-2.5))
fp('C1','1000u 16V','Radial_D10_P5',34,28,[('1',0,0,2.2,1,'CAP+'),('2',5,0,2.2,1,'COM')],circle=(2.5,0,5.15),refpos=(2.5,6.6))
route('IN+',(12,15),(17.5,15));route('CAP+',(27.66,15),(34,15));route('CAP+',(34,20),(34,28));route('LOAD+',(46,15),(52,15));route('COM',(62.16,15),(62.16,26.84),(58,31));route('COM',(39,28),(42,31),(58,31))
outline=[(0,0),(70,0),(70,45),(0,45)];p.extend(line(a,b,'Edge.Cuts',.05) for a,b in zip(outline,outline[1:]+outline[:1]))
for x,y,t,s in [(35,4,'FINITE ENERGY REFERENCE   REV A',1.25),(12,23,'IN+',1),(29,19,'CAP+',1),(50,23,'LOAD+',1),(58,39,'COM',1),(29.6,27,'+',1.4),(44,28,'-',1.4),(24,40,'5V MAX   /   NO HV',1.1)]:p.append(f'(gr_text "{t}" (at {x} {y}) (layer "F.SilkS") (effects (font (size {s} {s}) (thickness .18))))')
Path(__file__).with_name('reference.kicad_pcb').write_text('\n'.join(p)+')\n')
