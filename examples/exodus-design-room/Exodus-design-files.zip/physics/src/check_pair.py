#!/usr/bin/env python3
"""Structural checks on the finite-energy model. Run with Python 3; no pip dependencies."""
from isolated_pair import solve,EPS
import math
cases=0; worst=0
for A in (.0025,.00125):
 for g in (.0019,.003):
  for m1,m2 in ((.1,.1),(.015,.31)):
   for b in (.0001,.001,.005):
    for volts in (1.,5.):
     U=.5*EPS*A/g*volts**2; F=EPS*A*(volts/g)**2/2; p=0
     rows=list(solve(A,g,volts,m1,m2,b,.25,31)); cases+=1
     assert math.isclose(rows[-1]['gap_m'],.75*g,rel_tol=1e-12)
     for s in rows:
      assert s['force1_N']==-s['force2_N'] and math.isclose(s['force1_N'],F,rel_tol=1e-14)
      assert abs(m1*s['v1_m_s']+m2*s['v2_m_s']) < 1e-17
      K=.5*(m1*s['v1_m_s']**2+m2*s['v2_m_s']**2); C=EPS*A/s['gap_m']; q=EPS*A/g*volts
      assert math.isclose(K,s['Kpair_J'],rel_tol=1e-14)
      E=s['Eload_J']; assert p<=E<=U*(1+1e-12); p=E
      worst=max(worst,abs(q*q/(2*C)+K+E-U)/U)
assert worst<1e-9
print(f'{cases} cases; worst fractional field+kinetic+load discrepancy = {worst:.3g}')
for A in (.0025,.00125):
 C=EPS*A/.0019; U=.5*C*25
 print(f'A={A:g} m2: C={C*1e12:.3f} pF, U={U*1e12:.3f} pJ, |F_on_one_plate|={U/.0019*1e9:.3f} nN')
