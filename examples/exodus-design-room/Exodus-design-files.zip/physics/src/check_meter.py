#!/usr/bin/env python3
"""Independent exact-interval test of the metrology ledger. Supply path to ledger.py.
No measured data or uncertainty claims. The intervals straddle no switch event.
"""
import argparse, csv, json, math, pathlib, subprocess, sys, tempfile

def check(ledger):
    V=5.0; C=0.001; R=1000.; tau=R*C; vc=V*(-math.expm1(-8/tau)); vf=vc*math.exp(-8/tau)
    with tempfile.TemporaryDirectory() as tmp:
        d=pathlib.Path(tmp); f=d/'intervals.csv'; settings=d/'endpoints.json'
        with f.open('w', newline='') as o:
            w=csv.writer(o); w.writerow('t0_s t1_s pin_W u_pin_W pout_W u_pout_W u_dt_s'.split())
            for j in range(180):
                t=j/10; t1=(j+1)/10; dt=t1-t; ei=eo=0.
                if t<8: ei=C*V**2*math.exp(-t/tau)*(-math.expm1(-dt/tau))
                if t>=10: eo=0.5*C*vc**2*math.exp(-2*(t-10)/tau)*(-math.expm1(-2*dt/tau))
                w.writerow([t,t1,ei/dt,0,eo/dt,0,0]);
        settings.write_text(json.dumps(dict(C_min_F=C,C_max_F=C,V_start=0,u_V_start=0,V_end=vf,u_V_end=0,other_release_max_J=0,unmetered_input_max_J=0)))
        z=json.loads(subprocess.check_output([sys.executable, str(ledger),str(f),str(settings)], text=True)); ein=C*V*vc; eout=.5*C*(vc**2-vf**2)
        for key, target in [('input_J',ein),('load_J',eout),('unexplained_lower_J',eout-ein)]:
            if not math.isclose(z[key],target,rel_tol=1e-11): raise AssertionError((key,z[key],target))
        if z['records']!=180: raise AssertionError(z['records'])
        print('Analytic cross-check passed: 180 synthetic intervals, input %.10g J, load %.10g J, residual %.10g J.'%(ein,eout,z['unexplained_lower_J']))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('ledger', type=pathlib.Path); check(p.parse_args().ledger)
