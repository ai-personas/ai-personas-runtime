#!/usr/bin/env python3
"""Piecewise analytic reference for Eli's ideal finite-energy store; not measured data.
Phase endpoints occur twice intentionally: switching at fixed Vc changes currents.
Integrate within each phase, never across a switch. E columns are cumulative J.
"""
import math,csv,sys,argparse

def run(C=.001,R1=1000.,R2=1000.,Vs=5.,t_charge=8.,t_hold=2.,t_discharge=8.,n=800):
    if min(C,R1,R2,Vs,t_charge,t_discharge)<=0 or t_hold<0 or n<1 or Vs>5: raise ValueError('requires positive components, 0<Vs<=5 V, nonnegative hold')
    Vh=Vs*(-math.expm1(-t_charge/(R1*C)))
    Ech=C*Vs*Vh; Uhold=.5*C*Vh**2
    for mode,T,offset in [('charge',t_charge,0.),('hold',t_hold,t_charge),('discharge',t_discharge,t_charge+t_hold)]:
        for i in range(n+1):
            t=i*T/n
            if mode=='charge':
                a=t/(R1*C); vc=Vs*(-math.expm1(-a)); isum=Vs*math.exp(-a)/R1; il=0.; ein=C*Vs*vc; er=.5*C*Vs**2*(-math.expm1(-2*a)); el=0.
            else:
                a=0. if mode=='hold' else t/(R2*C); vc=Vh*math.exp(-a); isum=0.; il=0. if mode=='hold' else vc/R2; ein=Ech; er=.5*C*Vs**2*(-math.expm1(-2*t_charge/(R1*C))); el=Uhold*(-math.expm1(-2*a))
            u=.5*C*vc*vc
            yield dict(mode=mode,t_s=offset+t,Vcap_V=vc,Vsource_V=Vs if mode=='charge' else 0.,Isource_in_A=isum,Vload_V=0. if mode!='discharge' else vc,Iload_A=il,Esource_J=ein,ER1_J=er,ER2_load_J=el,Ucap_J=u,residual_J=ein-er-el-u)

def check():
    for c in (.0008,.001,.0012):
        for vs in (1.,5.):
            rows=list(run(C=c,Vs=vs)); end=rows[-1]; assert max(abs(r['residual_J']) for r in rows)<1e-14
            for f,v,i in [('Esource_J','Vsource_V','Isource_in_A'),('ER2_load_J','Vload_V','Iload_A')]:
                nint=sum(.5*(r[v]*r[i]+s[v]*s[i])*(s['t_s']-r['t_s']) for r,s in zip(rows,rows[1:]) if r['mode']==s['mode']); assert math.isclose(nint,end[f],rel_tol=1e-4)
    print('6 cases: conservation and sampled VI integrals checked. Default:'); print({k:v for k,v in list(run())[-1].items() if k.endswith('_J')}); print('Vhold_V',5*(-math.expm1(-8)))
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--check',action='store_true'); ap.add_argument('--n',type=int,default=800,help='intervals per phase');ap.add_argument('--C',type=float,default=.001,help='capacitance in F'); a=ap.parse_args()
    if a.check: check()
    else:
        rows=iter(run(C=a.C,n=a.n)); r=next(rows); w=csv.DictWriter(sys.stdout,fieldnames=list(r));w.writeheader(); w.writerow(r); w.writerows(rows)
