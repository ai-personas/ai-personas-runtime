#!/usr/bin/env python3
"""Disconnected parallel-plate pair with a hypothetical ideal linear electrical load across the relative-motion coordinate. SI throughout. No gas, fringing, leakage, radiation, support load, contact or external field. NOT an Exodus simulator."""
import argparse,csv,math,sys
EPS=8.8541878128e-12

def solve(area=.0025,gap=.00190,volts=5.,m1=.10,m2=.10,damping=.001,closure=.5,n=100):
    if not all(math.isfinite(y) and y>0 for y in (area,gap,volts,m1,m2,damping)) or not 0<closure<1 or n<1: raise ValueError('Use finite positive SI inputs, 0<closure<1 and n>=1')
    mu=m1*m2/(m1+m2); C=EPS*area/gap; q=C*volts; u0=q*q/(2*C); F=u0/gap; tau=mu/damping; vt=F/damping
    def state(t):
        z=t/tau; a=-math.expm1(-z); v=vt*a
        # accurate z - (1-exp(-z)) for small z
        a2=z-a if z>.001 else z*z*(.5+z*(-1/6+z*(1/24-z/120)))
        x=vt*tau*a2; return x,v
    target=gap*closure; lo,hi=0.,tau
    while state(hi)[0]<target: hi*=2
    for _ in range(80):
        mid=(lo+hi)/2
        if state(mid)[0]<target: lo=mid
        else: hi=mid
    for i in range(n+1):
        t=hi*i/n; x,v=state(t); Efield=u0-F*x; K=.5*mu*v*v
        # integral of b v(t)^2; series avoids cancellation at start
        z=t/tau; J=z+2*math.expm1(-z)-.5*math.expm1(-2*z) if z>.01 else z**3*(1/3+z*(-1/4+z*(7/60+z*(-1/24+z*31/2520))))
        Eload=damping*vt*vt*tau*J
        yield dict(t_s=t,gap_m=gap-x,v1_m_s=v*m2/(m1+m2),v2_m_s=-v*m1/(m1+m2),force1_N=F,force2_N=-F,Ufield_J=Efield,Kpair_J=K,Eload_J=Eload,closure_error_J=Efield+K+Eload-u0)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name,default in dict(area=.0025,gap=.00190,volts=5.,m1=.1,m2=.1,damping=.001,closure=.5).items(): p.add_argument('--'+name,type=float,default=default)
    p.add_argument('-n',type=int,default=100); rows=solve(**vars(p.parse_args())); first=next(rows); w=csv.DictWriter(sys.stdout,fieldnames=first,lineterminator='\n'); w.writeheader();w.writerow(first);w.writerows(rows)
