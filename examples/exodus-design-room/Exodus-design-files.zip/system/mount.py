"""Run the supplied XY check against the actual board and stand drawing in this kit."""
from pathlib import Path
import subprocess, sys, tempfile, zipfile, shutil
here=Path(__file__).resolve().parent; kit=here.parent
board=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else kit/'electrical/reference.kicad_pcb'
with tempfile.TemporaryDirectory() as d:
    temp=Path(d); (temp/'electrical').mkdir(); shutil.copyfile(board,temp/'electrical/reference.kicad_pcb')
    with zipfile.ZipFile(temp/'exodus-mechanical.zip','w') as z:
        src=kit/'exodus_mechanical/cut/pcb_stand_base.dxf'; z.write(src,src.relative_to(kit))
    subprocess.run([sys.executable,str(here/'check_mount.py')],cwd=temp,check=True)
