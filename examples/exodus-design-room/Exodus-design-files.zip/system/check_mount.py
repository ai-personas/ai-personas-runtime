"""Compare XY registration of reference PCB and issued base DXF. Run from project root with KiCad's Python."""
import pcbnew as k, zipfile, pathlib, hashlib, math
p=pathlib.Path('electrical/reference.kicad_pcb'); b=k.LoadBoard(str(p)); box=b.GetBoardEdgesBoundingBox(); mm=k.ToMM
print('PCB SHA256',hashlib.sha256(p.read_bytes()).hexdigest(),flush=True); print('board box',mm(box.GetWidth()),mm(box.GetHeight()),'thickness', mm(b.GetDesignSettings().GetBoardThickness()))
pts=[]
for e in b.GetDrawings():
 if e.GetLayer()!=k.Edge_Cuts: continue
 print('cut primitive, width mm, start/end',e.GetShapeStr(),mm(e.GetWidth()),e.GetStart(),e.GetEnd())
 assert e.GetShape() in [k.SHAPE_T_SEGMENT,k.SHAPE_T_RECT], 'unhandled cut primitive'
 pts.extend([(mm(q.x),mm(q.y)) for q in (e.GetStart(),e.GetEnd())])
xs,ys=zip(*pts); w=max(xs)-min(xs); h=max(ys)-min(ys);cx=(max(xs)+min(xs))/2;cy=(max(ys)+min(ys))/2
print('cut centerline bounds width/height mm',w,h);ds=[];rest=[]
for f in b.GetFootprints():
 for pad in f.Pads():
  pos=pad.GetPosition(); x,y=mm(pos.x)-cx,mm(pos.y)-cy; d=pad.GetDrillSize(); size=pad.GetSize(); row=(round(x,4),round(y,4),mm(d.x),mm(d.y),str(f.GetReference()))
  if pad.GetAttribute()==k.PAD_ATTRIB_NPTH: ds.append(row)
  else: rest.append((x,y,mm(size.x),mm(size.y),str(f.GetReference()),pad.GetNumber()))
print('nonplated holes (centered mm, drill XY, ref)',sorted(ds))
with zipfile.ZipFile('exodus-mechanical.zip') as z: raw=z.read(next(s for s in z.namelist() if s.endswith('/pcb_stand_base.dxf')))
ls=raw.decode().splitlines(); pairs=list(zip([x.strip() for x in ls[::2]], [x.strip() for x in ls[1::2]])); circles=[]
for i,e in enumerate(pairs):
 if e==('0','CIRCLE'):
  j=i+1
  while j<len(pairs) and pairs[j][0]!='0':j+=1
  d=dict(pairs[i+1:j]); circles.append((float(d['10']),float(d['20']),2*float(d['40'])))
print('stand DXF circles',sorted(circles)); assert len(circles)==len(ds)==4
mx=sum(x for x,y,d in circles)/4; my=sum(y for x,y,d in circles)/4
assert abs(w-70)<.02 and abs(h-45)<.02 and abs(mm(b.GetDesignSettings().GetBoardThickness())-1.6)<.02
for x,y,dx,dy,r in ds:
 dist=min(math.hypot(x-(a-mx),y+(v-my)) for a,v,_ in circles); print(r,'registration error mm',round(dist,4)); assert dist<.02 and abs(dx-3.2)<.01 and abs(dy-3.2)<.01
 assert rest; print('nearest conservative pad-edge distance mm and ref/pad',min((round(math.hypot(x-a,y-v)-math.hypot(w,h)/2,3),ref,n) for a,v,w,h,ref,n in rest))
assert all(abs(d-3.4)<.01 for a,v,d in circles); print('Nominal XY mounting geometry matches; pad distance is not a component body, solder, fastener, or tolerance check.')
