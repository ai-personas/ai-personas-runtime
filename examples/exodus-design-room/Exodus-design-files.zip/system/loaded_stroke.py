"""Ideal reciprocating linear generator. SI units; not a postulated thrust law."""
import argparse, math
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--force',type=float,default=1e-6,help='constant forward force during both strokes [N]')
p.add_argument('--stroke',type=float,default=.01,help='one-way travel [m]')
p.add_argument('--speed',type=float,default=.01,help='imposed speed magnitude on both strokes [m/s]')
p.add_argument('--coupling',type=float,default=.1,help='linear alternator ideal coefficient Ke=Kt [V s/m = N/A]')
p.add_argument('--coil',type=float,default=100.,help='coil resistance [ohm]');p.add_argument('--load',type=float,default=100.,help='load resistance [ohm]')
a=p.parse_args(); assert all(math.isfinite(x) and x>0 for x in vars(a).values())
print('stroke   emf_V       I_A      W_device_J      W_stage_J        Q_coil_J        E_load_J'); sums=[0.]*4
for s,name in [(1,'out'),(-1,'back')]:
    v=s*a.speed; dx=s*a.stroke; dt=a.stroke/a.speed; emf=a.coupling*v; i=emf/(a.coil+a.load)
    # equal-and-opposite reaction to generated current; stage enforces constant v
    Fgen=-a.coupling*i; Fstage=-a.force-Fgen
    row=[a.force*dx,Fstage*dx,i*i*a.coil*dt,i*i*a.load*dt]; sums=[x+y for x,y in zip(sums,row)]
    print(name,emf,i,*row); assert math.isclose(sum(row[:2]),sum(row[2:]),rel_tol=1e-10,abs_tol=1e-20)
print('cycle J: device %.9g, stage %.9g, winding loss %.9g, load %.9g'%tuple(sums)); assert sums[0]==0 and math.isclose(sums[1],sums[2]+sums[3],rel_tol=1e-10)
