# Exodus propulsion and electrical generation: an investigation kit

**Conclusion:** A force reading with the supply disconnected is not a measurement of electricity generation. Force can persist at zero speed (no work); stored charge can deliver energy with the source removed. No source examined here specifies or validates a whole-device thrust law under load and through reset. This is a buildable set of controls, simulations and measurement procedures, not a verified propellantless drive or COP > 1 generator.

## Choose a question

| Question | Start here | What it establishes |
|---|---|---|
| What was proposed? | `physics/CLAIMS.md`, then `physics/THEORY.md` | Source-qualified account, ordinary momentum/energy accounting, and a falsifiable residual-force hypothesis. |
| What internal force or stored energy should appear without new physics? | `physics/README.md` | Editable isolated-pair and RC models, not device performance data. |
| Can power flow after unplugging? | `electrical/README.md`, `metrology/BOARD-INTERFACE.md` | 5 V capacitor control, PCB on a separate stand, signed input/load energy. |
| How do geometry and orientation enter a force test? | `exodus_mechanical/README.md`, `metrology/FORCE.md` | Two matched low-voltage test coupons and a blinded test protocol; an external calibrated balance is required. |
| How would motion produce terminal power? | `generator/BUILD.md`, `generator/wiring.svg`, `system/LOADED-STROKE.md` | Printable moving-magnet pickup control and load. A hand or stage supplies mechanical work. Use the loaded-stroke model to account for both travel directions, winding loss, reset and external work. |
| Could a hypothesized force do work against a generator load? | `coupled_rotor/START-HERE.md`, `coupled_rotor/models/assembly.step` | A separate guarded rotor with two disconnected coupons, retained magnets and a stationary coil. First establish the breakaway and pickup thresholds; count launch, charge, reset and all other supplied work. |
| How do I reduce experimental data? | `metrology/README.md`, `metrology/ELECTRICAL.md`, `metrology/FORCE.md` | Executable reductions and synthetic examples; independent calibration and systematic bounds are required. |

The modules are **not** a series circuit. Never put the board on the force balance or feed the pickup from the board. No high-voltage experiment is specified. `system/mount-result.txt` compares the issued stand DXF to the actual board; run `python3 system/mount.py` from this folder to repeat (see dependencies in the mechanical documentation). Nominal XY alignment does not prove a physical fit. Use each module's README from its stated directory for dependencies and regeneration. `BASE-INPUTS.txt` identifies the module inputs.

## Open or fabricate the reference hardware

1. Start with `electrical/README.md` and `electrical/PARTS.md` before buying parts. Open `electrical/reference.kicad_pro` in KiCad; keep its local libraries beside it. The PCB fabrication outputs are in `electrical/fabrication/`; `electrical/BOM.csv` is the parts list. `exodus_mechanical/README.md` covers the stand and the separate matched capacitor coupons. Check actual part dimensions, fit and component clearances before powering anything.
2. Use `metrology/BOARD-INTERFACE.md` to wire the **5 V maximum** reference-board test: TP1 input, TP2 storage, TP3 load, TP4 common. Disconnect *both* source leads during hold and load. Test the logger for hidden return paths before treating the system as isolated. Follow `metrology/ELECTRICAL.md` for the signed energy ledger.
3. Compare like cases. Eli's 5 s charge, 30 s hold, 8 s load **simulation** gives 24.915 mJ input and 11.507 mJ at the load (46.2%). The missing 13.408 mJ to break even applies only to that cycle, excluding any *additional* mechanism costs. The ideal RC interoperability check (8/2/8 s, no leakage) instead gives 24.992 mJ in and 12.492 mJ out. Neither is a bench reading. See `electrical/GAIN-TARGET.md`.
4. The winding control has its own isolated load and no PCB connection. A stage or hand provides its motion. Record both directions and the cost of preparing and restoring any source. A load receiving power is not evidence that the complete machine generated net energy.

## Coupled test: decide whether a run would tell you anything

Use `coupled_rotor/START-HERE.md` for the rotary build, **not** the linear magnet-wand instructions. The former and coupon drawings under `coupled_rotor/companions/` are local build dependencies, not additional devices to wire together. The reference PCB stays on its separate stand. No high-voltage, high-speed or vacuum operation is specified.

For two same-handed tangential forces of 1 µN each at 0.100 m, the stipulated torque is 0.20 µN·m. If from rest the maximum available torque is below measured breakaway torque, do not expect a self-start test to resolve that force. A null then is a sensitivity limit. At one full turn, ignoring drag and granting 25% shaft-to-load efficiency, the two forces could account for **at most 0.314 µJ at the load**. These are assumptions, not Exodus measurements. Run `python3 coupled_rotor/rotor_budget.py --help` to substitute measured inputs and uncertainties. An externally driven rotor can light up the pickup without a charged article doing any work.

For actual evidence, record angular motion, loaded voltage versus time, source energy and the cost of restoring the entire device to rest in its initial state. Compare load heat with *all* inputs and possible storage depletion, using uncertainty bounds, before quoting a ratio. Reversal and sham comparisons help identify a force; they do not establish an energy source.
