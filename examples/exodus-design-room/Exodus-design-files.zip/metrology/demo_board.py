#!/usr/bin/env python3
"""Exercise electrical pipeline on labelled ideal board data only."""
import csv,json,math,tempfile
from pathlib import Path
from samples import convert,FIELDS
from ledger import audit,HEADER

D=Path(__file__).resolve().parent/'example'
def run():
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp); combined=[]; offset=0.; result={}; endpoints=[]
        for phase in ('charge','hold','load'):
            with (D/('synthetic_board_'+phase+'.csv')).open() as f: data=list(csv.DictReader(f))
            s=root/'ports'; out=root/phase
            with s.open('w',newline='') as f:
                w=csv.DictWriter(f,FIELDS,extrasaction='ignore'); w.writeheader(); w.writerows(data)
            convert(s,D/'synthetic_bounds.json',out)
            vs,ve=(float(data[i]['vc_V']) for i in (0,-1)); endpoints.append((vs,ve)); cfg={'C_min_F':.001,'C_max_F':.001,'V_start':vs,'u_V_start':1e-10,'V_end':ve,'u_V_end':1e-10,'other_release_max_J':0,'unmetered_input_max_J':0}; cpath=root/'cfg'; cpath.write_text(json.dumps(cfg)); result[phase]=audit(out,cpath)
            with out.open() as f:
                for r in csv.DictReader(f):
                    r['t0_s']=float(r['t0_s'])+offset; r['t1_s']=float(r['t1_s'])+offset; combined.append(r)
            offset=combined[-1]['t1_s']
        cfg.update(V_start=endpoints[0][0],V_end=endpoints[-1][1]); cpath.write_text(json.dumps(cfg)); allp=root/'combined'
        with allp.open('w',newline='') as f:
            w=csv.DictWriter(f,HEADER); w.writeheader(); w.writerows(combined)
        result['all']=audit(allp,cpath); return result
if __name__=='__main__':
    r=run(); print(json.dumps(r,indent=2)); a=r['all']; vc=5*(1-math.exp(-6)); ei=.001*5*vc; el=.0005*vc**2*(1-math.exp(-12)); assert a['input_lower_J']<=ei<=a['input_upper_J'] and abs(a['load_J']-el)<5e-7 and a['load_lower_J']<=el and r['load']['signed_load_to_input_ratio'] is None and all(x['unexplained_lower_J']<=0 for x in r.values()); assert a['records']==1400
