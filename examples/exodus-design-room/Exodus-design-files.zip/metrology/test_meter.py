import unittest,tempfile,csv,json,math
from pathlib import Path
from ledger import audit,HEADER,KEYS
from samples import convert,FIELDS,BOUNDS
class Meter(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup); self.root=Path(self.tmp.name)
    def table(self,name,fields,rows):
        out=self.root/name
        with out.open('w',newline='') as f: w=csv.writer(f); w.writerow(fields); w.writerows(rows)
        return out
    def cfg(self,name,keys,values):
        p=self.root/name; p.write_text(json.dumps(dict(zip(keys,values)))); return p
    def test_decay(self):
        # Exact integrated power: discharge 1 F, 2 V to 1 V; isolated. No input or infinite ratio.
        c=self.cfg('c',KEYS,[1,1,2,0,1,0,0,0]); p=self.table('i',HEADER,[[0,1,0,0,1.5,0,0]])
        a=audit(p,c); self.assertEqual(a['capacitor_release_upper_J'],1.5); self.assertEqual(a['unexplained_lower_J'],0); self.assertIsNone(a['signed_load_to_input_ratio'])
    def test_reverse(self):
        c=self.cfg('c',KEYS,[0,0,0,0,0,0,0,0]); p=self.table('i',HEADER,[[0,1,-2,.1,-3,.1,.2]])
        a=audit(p,c); self.assertAlmostEqual(a['input_upper_J'],-1.9*.8); self.assertAlmostEqual(a['load_lower_J'],-3.1*1.2)
    def test_converter(self):
        # Correlated voltage/current: mean of products != product of means.
        s=self.table('s',FIELDS,[[0,2,0,1,-1],[.5,0,2,1,-1]])
        c=self.cfg('bounds',BOUNDS,[.1,.1,0,0,2,0,0,0,.5]); out=self.root/'out'; convert(s,c,out)
        with out.open() as f: r=next(csv.DictReader(f))
        self.assertEqual(float(r['pin_W']),0); self.assertAlmostEqual(float(r['u_pin_W']),2.21); self.assertEqual(float(r['pout_W']),-1)
    def test_missing(self):
        s=self.table('s',FIELDS,[[0,0,0,0,0],[2,0,0,0,0]]); c=self.cfg('bounds',BOUNDS,[0]*8+[1]); out=self.root/'out'
        with self.assertRaises(ValueError): convert(s,c,out)
        self.assertFalse(out.exists())
    def test_adjusted_surplus(self):
        c=self.cfg('c',KEYS,[.1,.2,2,.1,1,.2,.1,.2]); p=self.table('i',HEADER,[[0,2,1,.1,4,.1,.01]])
        self.assertAlmostEqual(audit(p,c)['unexplained_lower_J'],1.99*3.9-2.01*1.1-.1*(2.1**2-.8**2)-.3)
if __name__=='__main__': unittest.main()
