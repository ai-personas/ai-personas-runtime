#!/usr/bin/env python3
"""Convert synchronous port samples to bounded interval-average powers. See README."""
import csv,json,argparse,math
from ledger import number, HEADER
from pathlib import Path
FIELDS='t_s vin_V iin_A vload_V iload_A'.split()
BOUNDS='u_vin_V u_iin_A u_vload_V u_iload_A pin_curve_W pout_curve_W time_rel time_abs_s max_gap_s'.split()

def convert(src,bounds,dst):
    cfg=json.loads(Path(bounds).read_text());
    if set(cfg)!=set(BOUNDS): raise ValueError('expected bounds keys '+str(BOUNDS))
    uv,ui,uw,uj,bi,bo,rel,ab,gap=map(number,(cfg[k] for k in BOUNDS))
    if min(uv,ui,uw,uj,bi,bo,rel,ab)<0 or gap<=0: raise ValueError('invalid bounds')
    result=[]; prev=None
    with open(src,newline='') as f:
        r=csv.DictReader(f)
        if r.fieldnames!=FIELDS: raise ValueError('expected columns '+str(FIELDS))
        for row in r:
            if None in row: raise ValueError('extra columns')
            t,v,i,w,j=map(number,(row[k] for k in FIELDS)); cur=(t,v*i,abs(v)*ui+abs(i)*uv+uv*ui,w*j,abs(w)*uj+abs(j)*uw+uw*uj)
            if prev is not None:
                dt=t-prev[0]; ud=rel*dt+2*ab
                if dt<=ud or dt>gap: raise ValueError(f'invalid sampling interval ending at {t}')
                result.append([prev[0],t,(prev[1]+cur[1])/2,(prev[2]+cur[2])/2+bi,(prev[3]+cur[3])/2,(prev[4]+cur[4])/2+bo,ud])
            prev=cur
    if not result or any(not math.isfinite(x) for row in result for x in row): raise ValueError('insufficient/overflowing samples')
    with open(dst,'x',newline='') as f:
        wr=csv.writer(f); wr.writerow(HEADER); wr.writerows(result)
    return len(result)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('samples'); p.add_argument('bounds'); p.add_argument('new_intervals'); a=p.parse_args()
    try: print('intervals written:',convert(a.samples,a.bounds,a.new_intervals))
    except (ValueError,TypeError,OSError,OverflowError) as e: p.exit(2,f'conversion refused: {e}\n')
