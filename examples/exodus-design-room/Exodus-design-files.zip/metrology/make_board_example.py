#!/usr/bin/env python3
"""Generate analytic, noiseless example readings, NOT lab observations. Python 3."""
import csv,math
from pathlib import Path
D=Path(__file__).resolve().parent/'example'; D.mkdir(exist_ok=True)
# Separate endpoint samples on either side of an ideal switch transition.
# t_s is elapsed time within each phase, not time since start of the full run.
def make():
    c=.001; r=1000.; vs=5.; tchg=6.; thold=2.; tload=6.; dt=.01
    vmax=vs*(-math.expm1(-tchg/(r*c)))
    for phase,duration in [('charge',tchg),('hold',thold),('load',tload)]:
        with (D/('synthetic_board_'+phase+'.csv')).open('w',newline='') as f:
            w=csv.writer(f); w.writerow(['t_s','vin_V','vc_V','vload_V','iin_A','iload_A'])
            for k in range(round(duration/dt)+1):
                t=k*dt; vc=vs*(-math.expm1(-t/(r*c))) if phase=='charge' else (vmax if phase=='hold' else vmax*math.exp(-t/(r*c)))
                # Floating IN+ after removal follows VC through R1 for an ideal infinite-impedance measurement. This is NOT a connected source.
                vin=vs if phase=='charge' else vc; vl=vc if phase=='load' else 0.
                w.writerow([format(x,'.13g') for x in (t,vin,vc,vl,(vin-vc)/r if phase=='charge' else 0.,vl/r)])
    vend=vmax*math.exp(-tload/(r*c)); ein=c*vs*vmax; el=.5*c*(vmax**2-vend**2)
    print('analytic synthetic only: Esource_J, Eload_J, Eremaining_J, Er1_charge_J:',ein,el,.5*c*vend**2,ein-.5*c*vmax**2)
if __name__=='__main__': make()
