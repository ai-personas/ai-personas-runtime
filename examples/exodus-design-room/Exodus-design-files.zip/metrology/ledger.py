#!/usr/bin/env python3
"""Bounded energy audit. Python 3, standard library only. Units: seconds, W, F, V, J."""
import argparse, csv, json, math
from pathlib import Path

HEADER='t0_s t1_s pin_W u_pin_W pout_W u_pout_W u_dt_s'.split()
KEYS='C_min_F C_max_F V_start u_V_start V_end u_V_end other_release_max_J unmetered_input_max_J'.split()

def number(x):
    x=float(x)
    if not math.isfinite(x): raise ValueError('nonfinite number')
    return x

def audit(path, settings):
    cfg=json.loads(Path(settings).read_text())
    if set(cfg)!=set(KEYS): raise ValueError('endpoint/settings keys must be '+str(KEYS))
    c0,c1,vs,us,ve,ue,other,unmetered=map(number,(cfg[k] for k in KEYS))
    if min(c0,us,ue,other,unmetered)<0 or c1<c0: raise ValueError('invalid bound')
    rows=0; last=None; ei=eo=ei_hi=ei_lo=eo_lo=0.
    with open(path,newline='') as stream:
        reader=csv.DictReader(stream)
        if reader.fieldnames!=HEADER: raise ValueError('expected CSV fields '+str(HEADER))
        for row in reader:
            if None in row: raise ValueError('extra CSV fields')
            a,b,pi,ui,po,uo,ud=map(number,(row[k] for k in HEADER)); dt=b-a
            if min(ui,uo,ud)<0 or dt<=ud or (last is not None and a!=last): raise ValueError(f'gap/overlap or invalid bound at record {rows+1}')
            # Power intervals may include reverse flow. Use all corners for energy bounds.
            ei+=dt*pi; eo+=dt*po
            ei_lo+=min(p*t for p in (pi-ui,pi+ui) for t in (dt-ud,dt+ud))
            ei_hi+=max(p*t for p in (pi-ui,pi+ui) for t in (dt-ud,dt+ud))
            eo_lo+=min(p*t for p in (po-uo,po+uo) for t in (dt-ud,dt+ud))
            last=b; rows+=1
    if not rows: raise ValueError('empty trace')
    # A fixed linear C; only take credit for net export not explainable by initial inventory.
    d2=(abs(vs)+us)**2-max(0.,abs(ve)-ue)**2
    release=0.5*c1*max(0.,d2)
    worst=eo_lo-ei_hi-release-other-unmetered
    return dict(records=rows,input_J=ei,load_J=eo,input_lower_J=ei_lo,input_upper_J=ei_hi,load_lower_J=eo_lo,capacitor_release_upper_J=release,unexplained_lower_J=worst,signed_load_to_input_ratio=(eo/ei if ei_lo>0 and eo>=0 else None),interpretation=('investigate missing energy paths and bounds; not proof of generation' if worst>0 else 'no positive unexplained export established'))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('intervals'); p.add_argument('settings'); a=p.parse_args()
    try: print(json.dumps(audit(a.intervals,a.settings),indent=2,allow_nan=False))
    except (ValueError,KeyError,TypeError,OSError,OverflowError) as e: p.exit(2,f'audit refused: {e}\n')
