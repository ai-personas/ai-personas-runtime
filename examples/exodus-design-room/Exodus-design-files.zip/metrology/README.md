# Measure force and energy as different quantities

Use `ELECTRICAL.md` for the finite-energy PCB and `FORCE.md` for a separate instrumented trial. Neither dataset here is measured. Start with Python 3 (standard library), from this directory:

```
python3 -m unittest -v test_meter
python3 demo_board.py
```

The demo reads the three `example/synthetic_board_*.csv` files (regenerate with `python3 make_board_example.py`). Each phase includes its own start and end point. It selects the five synchronous port channels, converts each phase, checks it against the measured-endpoint ledger and joins the intervals without interpolating a switch event. Under this ideal RC model, net source input ≈24.938 mJ, load ≈12.438 mJ; ratio ≈0.499 for charge + hold + load. Discharge alone has positive load energy and no source input: ratio `null`. Charging loss in R1 accounts for most of the difference. No input or output from the isolated plate coupon is included.

## Your own electrical trial

`python3 samples.py ports.csv bounds.json intervals.csv` then `python3 ledger.py intervals.csv endpoints.json`. Supply a new interval filename (converter refuses overwrite). Exact headers/order, comma-separated, SI units:

- ports: `t_s,vin_V,iin_A,vload_V,iload_A`; positive input into the declared system; positive output out into load. Sample **products** are integrated, including reverse energy.
- intervals: `t0_s,t1_s,pin_W,u_pin_W,pout_W,u_pout_W,u_dt_s`; contiguous, no overlap, interval-average powers, nonnegative absolute uncertainty radii. Do not bridge data gaps. For multiple phases convert individually, then join contiguous measured times (see demo). Account for transition energy even if the meter saturates: if it cannot be bounded, no conclusive audit.
- bounds: see `example/synthetic_bounds.json` for keys, not instrument specifications. `u_` on V and I bounds each synchronous reading (including correlated offsets); time radii use `time_rel*dt+2*time_abs_s`; `max_gap_s` rejects long sample gaps. `pin_curve_W`/`pout_curve_W` bound the error of estimating **mean power** by endpoint trapezoid. For a smooth phase with a justified curvature limit M, this error ≤ M·dt²/12. For this synthetic ideal RC only, M ≤ 0.025 W/s² for charge input and ≤ 0.1 W/s² for load; dt=0.01 s. Apply different experimentally justified bounds for actual data. For a current derived from two readings and R, propagate both voltage bounds and R limits (including temperature) into a worst-case current radius. Bound channel skew too.
- endpoints: example `{"C_min_F":0.0009,"C_max_F":0.0011,"V_start":4.98,"u_V_start":0.01,"V_end":0.01,"u_V_end":0.01,"other_release_max_J":0,"unmetered_input_max_J":0}`. Last two zeros are only defensible where the corresponding other stored reservoirs and external inputs have been excluded. Replace values, not key names. Constant linear capacitor assumption; do not double-count its release.

`unexplained_lower_J` = conservative lower delivered energy − upper signed input − upper net positive release of capacitor energy − other allowed release and input. A positive number warrants investigation of bounds and missing ports, **not** a discovery claim. Nonpositive means no positive unexplained export established. Ratio is nominal (not an interval), suppressed when input lower bound ≤0. This is not a heat-pump COP. No software can verify that a physical system boundary or supplied uncertainty budget is complete.
