#!/usr/bin/env python3
"""Screen pre-coded, matched, independent force blocks; not a discovery test."""
import argparse,csv,math,statistics as S,json
from collections import defaultdict
# One eight-run block per independent reset; an individual run = one fixed-window mean.
FIELDS='block order orientation bias force_N'.split()
def screen(path, systematic_N):
    if not math.isfinite(systematic_N) or systematic_N<0: raise ValueError('need a finite nonnegative bound on the full contrast')
    blocks=defaultdict(dict)
    with open(path,newline='') as f:
        r=csv.DictReader(f)
        if r.fieldnames!=FIELDS: raise ValueError('expected '+','.join(FIELDS))
        for row in r:
            b=row['block']; o=int(row['order']); d=int(row['orientation']); z=int(row['bias']); val=float(row['force_N'])
            if not b or None in row or o not in range(1,9) or d not in [-1,1] or z not in [0,1] or not math.isfinite(val) or o in blocks[b]: raise ValueError('invalid or duplicate run')
            blocks[b][o]=(d,z,val)
    vals=[]
    for b,rows in blocks.items():
        if set(rows)!=set(range(1,9)): raise ValueError(f'incomplete block {b}')
        # Each condition measured twice at symmetric positions in the block -> common linear drift cancels if equally spaced.
        first=[rows[i][:2] for i in range(1,5)]
        if len(set(first))!=4 or any(rows[i][:2]!=rows[9-i][:2] for i in range(1,5)): raise ValueError(f'block {b} is not a balanced mirrored sequence')
        means={rows[i][:2]:(rows[i][2]+rows[9-i][2])/2 for i in range(1,5)}
        vals.append(((means[1,1]-means[1,0])-(means[-1,1]-means[-1,0]))/2)
    if len(vals)<2: raise ValueError('need >=2 independent blocks for scatter')
    return dict(n=len(vals),per_block_N=vals,mean_N=S.mean(vals),standard_error_between_blocks_N=S.stdev(vals)/math.sqrt(len(vals)),systematic_bound_N=systematic_N)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('runs'); p.add_argument('systematic_N',type=float); a=p.parse_args()
    try: print(json.dumps(screen(a.runs,a.systematic_N),indent=2,allow_nan=False))
    except (TypeError,ValueError,OSError) as e: p.exit(2,str(e)+'\n')
