# Using the measurement kit with the 5 V reference board

Checked against electrical/reference.kicad_pcb SHA-256 `b9ca618f11282501a300a2e979afd29645e07d6eaead4c916b8913b1c25f817a`, its netlist, BOM, README and reference.cir. This is a charge-storage control; keep it off the force balance and disconnected from the coupon.

| Step | Connections and measurements | Signed ledger ports |
|---|---|---|
| Charge, 5 s | No bridge. Isolated current-limited 5 V source + to TP1, − to TP4; TP2 is capacitor positive. | Measure input voltage TP1–TP4 and current into TP1. Difference TP1–TP2 divided by measured R1 is a current estimate only if other paths are excluded. |
| Hold, 30 s | Remove **both** source leads; no bridge. Log TP2–TP4 with known floating probe impedance. | Source current is zero only after isolation is verified; a residual voltage at TP1 is not source power. |
| Load, 8 s | Supply still absent. Bridge TP2 to TP3, **never TP2 to TP4**. Log TP3–TP4. | Output is positive into R2: Vload²/R2. Do not also count R2 heat. Record remaining capacitor voltage, any later reset and all other inputs. |

All TP pairs are single nodes. R1 and R2 nominally 1 kΩ each, C1 nominally 1000 µF. Use measured values on hardware. Keep common-return probes from defeating isolation; switching edges need distinct phase endpoints. In the electrical model only, a differential source switch represents two-lead removal. A capacitor charged to 5 V stores 12.5 mJ, not an unlimited energy supply.

Do not compare the two ZIPs’ default demo totals as if they were the same run. With the electrical model’s 1 MΩ leakage and 10 MΩ meter, the expected end-of-phase voltages are about 4.9610, 4.8000 and 0.00160 V. Source and load energies are about 24.915 and 11.507 mJ; the difference is a deficit of 13.408 mJ, not a surplus. The metrology ZIP’s ideal example has different settings. Neither is a measured run. A loaded generator test requires accounting for motion, reset, excitation, storage and other ports over a repeatable cycle; the isolated hold alone has no defined output/input ratio.
