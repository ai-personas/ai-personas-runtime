"""2 fixed articles, same-handed body-fixed tangential thrust. Algebraic optimistic bound; NOT simulated or measured thrust. SI units. Python stdlib."""
import argparse,math
p=argparse.ArgumentParser(description=__doc__)
for name,default,desc in [('force',1e-6,'tangential N per coupon'),('radius',.100,'m to each coupon centre'),('turns',1,'forward revolutions'),('drag',0,'mean parasitic opposing torque N m EXCLUDING pickup'),('eta',.25,'useful load J / shaft J delivered to pickup, >0 and <=1'),('input',1e-6,'all metered external energy J supplied in complete rest-to-rest cycle'),('margin',0,'upper error allowance J')]:p.add_argument('--'+name,type=float,default=default,help=desc)
a=p.parse_args(); assert all(math.isfinite(v) and v>=0 for v in vars(a).values());assert a.radius*a.turns>0 and 0<a.eta<=1
phi=math.tau*a.turns; t=2*a.force*a.radius; w=t*phi; loss=a.drag*phi
print('Stipulated drive torque N m:',t,'; drive work J:',w)
print('Upper bound load J from granted torque alone:',a.eta*max(0,w-loss))
print('Required force per article N for this torque alone to cover the electrical target + margin:',(a.drag+(a.input+a.margin)/(a.eta*phi))/(2*a.radius))
print('Assumes no other motion input available for conversion. Bound is not a start condition. Must also overcome breakaway and opposing torque at every stall point. If a stage drives the rotor, include its measured work/energy and do not attribute its output to the articles.')
