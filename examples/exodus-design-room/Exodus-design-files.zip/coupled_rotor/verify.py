"""Nominal manufactured interface checks on delivered STEP/DXF/STLs (mm). No physical acceptance implied."""
from pathlib import Path
import cadquery as cq,ezdxf,math
R=Path(__file__).resolve().parent
def part(n):return cq.importers.importStep(str(R/'models'/(n+'.step'))).val()
def ls(n,layer):
 doc=ezdxf.readfile(R/'cam'/(n+'.dxf'));assert doc.units==4;return [(round(c.dxf.center.x,5),round(c.dxf.center.y,5),round(c.dxf.radius,5)) for c in doc.modelspace().query('CIRCLE') if c.dxf.layer==layer]
def intersects(a,b):return a.intersect(b).Volume()>1e-5
def tr(s,x,y,z):return s.translate((x,y,z))
files=sorted((R/'models').glob('*.step'));assert len(files)==8
for f in files:assert part(f.stem).isValid(),f
assert sorted(ls('disc_8','BLIND'))==[(-60,0,3.15),(60,0,3.15)]
D=ls('disc_8','THRU');assert all((s*(60+x),0,1.7) in D for x in (-9,9) for s in (-1,1));assert all((s*(100+x),s*12,2.15) in D for x in (-20,20) for s in (-1,1))
assert sorted(ls('clamp_24','THRU'))==[(-20,0,2.15),(20,0,2.15)]
# Use actual coupon from the supplied sibling kit. A test pin through both parts checks the direction/depth of the side operations not in the top view.
c0=cq.importers.importStep(str(R/'companions/capacitor/model/coupon_narrow.step')).val();c=tr(c0.rotate((0,0,0),(0,0,1),-90).rotate((0,0,0),(1,0,0),90),100,4,97);b=tr(part('clamp_24'),100,12,53);assert not intersects(c,b);bbox=c.BoundingBox();assert abs(bbox.zmin-57)<.01 and abs(bbox.zmax-137)<.01 and abs(bbox.xmax-152)<.01
for x in (68,132):
 pin=cq.Solid.makeCylinder(1.5,24,cq.Vector(x,-4,65),cq.Vector(0,1,0));assert not intersects(pin,c) and not intersects(pin,b)
 # positive control: displacing test pin into carrier and bracket collides with BOTH
 assert intersects(tr(pin,3,0,0),c) and intersects(tr(pin,3,0,0),b)
# STL at z=0..14, radius 11, not a point pickup. The free flange is bonded at z=12..14.
for n in ('former','flange'):
 pts=[[float(x) for x in l.split()[1:]] for l in (R/'companions/pickup'/(n+'.stl')).read_text().splitlines() if l.strip().startswith('vertex ')];assert pts and abs(max(math.hypot(x,y) for x,y,z in pts)-11)<.01;assert max(z for x,y,z in pts)==(14 if n=='former' else 2)
assert ls('pickup_deck_25','BLIND')==[(0,0,11.2)];deck=part('pickup_deck_25');coil=cq.Solid.makeCylinder(11,14,cq.Vector(60,0,23));assert not intersects(tr(deck,60,0,0),coil)
keeper=tr(part('keeper_5'),60,0,40);mag=cq.Solid.makeCylinder(3,6,cq.Vector(60,0,45.1));disc=tr(part('disc_8'),0,0,45);assert not intersects(disc,mag) and not intersects(keeper,mag);gap=keeper.BoundingBox().zmin-coil.BoundingBox().zmax;assert abs(gap-3)<.01
assert math.hypot(80,12)-4>60+11 # M4 under-head swept circle outside winding
print('7 part STEPs and assembly readable; upright coupon, 2 M3 gauge pins, magnet fit, DXF hole registration, STL envelope and nominal %.2f mm keeper/coil gap checked.'%gap)
