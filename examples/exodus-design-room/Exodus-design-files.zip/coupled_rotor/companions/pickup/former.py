"""Generate matched former and glue-on outer flange in ASCII STL, millimeters. Python 3 stdlib."""
from pathlib import Path
import math
base=Path(__file__).resolve().parent
# XY radii in mm: 8 mm bore, 12 mm winding root, 22 mm flanges; 10 mm winding length.
N=96
parts={'former':[(4,0),(11,0),(11,2),(6,2),(6,14),(4,14)],'flange':[(6.15,0),(11,0),(11,2),(6.15,2)]}
for part,rz in parts.items():
    def vertex(k,j):
        r,z=rz[k%len(rz)]; phi=2*math.pi*(j%N)/N
        return (round(r*math.cos(phi),7),round(r*math.sin(phi),7),z)
    tris=[]
    for k in range(len(rz)):
        for j in range(N):
            a,b,c,d=vertex(k,j),vertex(k,j+1),vertex(k+1,j+1),vertex(k+1,j)
            tris.extend([(a,b,c),(a,c,d)])
    def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
    def dot(a,b):return sum(x*y for x,y in zip(a,b))
    oriented=set();volume=0.;lines=['solid '+part]
    for a,b,c in tris:
        n=cross([y-x for x,y in zip(a,b)],[y-x for x,y in zip(a,c)]); L=math.sqrt(dot(n,n));assert L>0
        volume+=dot(a,cross(b,c))/6
        for e in ((a,b),(b,c),(c,a)): assert e not in oriented;oriented.add(e)
        lines.append('facet normal '+' '.join('%.9g'%(x/L) for x in n)+'\n outer loop');lines.extend('  vertex '+' '.join(map(str,v)) for v in (a,b,c));lines.append(' endloop\nendfacet')
    assert all((b,a) in oriented for a,b in oriented)
    predicted=math.pi*((121-16)*2+(36-16)*12 if part=='former' else (121-6.15**2)*2);assert abs(volume/predicted-1)<.001
    lines.append('endsolid '+part);(base/(part+'.stl')).write_text('\n'.join(lines)+'\n');print(part,len(tris),'closed triangles;',round(volume,2),'mm^3')
