"""Post-export checks. Does not invoke build.py."""
import cadquery as cq, ezdxf, math
from pathlib import Path
from itertools import combinations
root=Path(__file__).resolve().parent
for name,sx,sy,hh,area in [('carrier',80,80,4,6400),('shim',10,10,1,100),('bottom_common',50,77,0,2716),('top_symmetric',50,77,0,2716),('top_narrow',25,77,0,1466),('pcb_stand_base',90,65,4,5850)]:
 d=ezdxf.readfile(root/'cut'/(name+'.dxf'));assert d.units==4 and not d.audit().has_errors;ms=d.modelspace();p,=ms.query('LWPOLYLINE');assert p.closed and p.dxf.layer=='PROFILE';pts=list(p.get_points('xy'));x,y=zip(*pts);assert max(x)-min(x)==sx and max(y)-min(y)==sy;assert math.isclose(abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(pts,pts[1:]+pts[:1])))/2,area)
 holes=list(ms.query('CIRCLE'));assert len(holes)==hh and all(abs(c.dxf.radius-1.7)<1e-8 and c.dxf.layer=='HOLE' for c in holes);patterns={'carrier':(32,32),'shim':(0,0),'pcb_stand_base':(31,18.5)}
 if hh:
  a,b=patterns[name];assert {(q.dxf.center.x,q.dxf.center.y) for q in holes}=={(x,y) for x in (-a,a) for y in (-b,b)}
 print(name, 'mm profile',sx,sy,'holes',hh)
for name,sx,sy,sz,n in [('coupon_symmetric',80,104,8,8),('coupon_narrow',80,104,8,8),('pcb_stand',90,65,10.6,6)]:
 shape=cq.importers.importStep(str(root/'model'/(name+'.step'))).val();s=shape.Solids();bb=shape.BoundingBox();assert len(s)==n and all(k.isValid() for k in s);assert all(abs(a-b)<1e-5 for a,b in zip((bb.xlen,bb.ylen,bb.zlen),(sx,sy,sz)));assert all(a.intersect(b).Volume()<1e-6 for a,b in combinations(s,2));print(name,n,'solids; bbox',sx,sy,sz,'mm; no volumetric overlaps')
 if name.startswith('coupon'):
  f=sorted([t.BoundingBox() for t in s if t.BoundingBox().zlen<.06],key=lambda b:b.zmin);assert len(f)==2 and abs(f[1].zmin-f[0].zmax-1.9)<1e-6 and f[0].ymin==-52 and f[1].ymax==52
