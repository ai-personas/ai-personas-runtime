"""Rebuild 1:1 mm CAM profiles and solid-model exchange files. Run python3 build.py."""
from pathlib import Path
import cadquery as cq
import ezdxf
root=Path(__file__).resolve().parent
for s in ['model','cut']:(root/s).mkdir(exist_ok=True)
P,T,S,F,D,H,W,L,TAIL=80.,3.,2.,.05,3.4,32.,50.,50.,8.
# (part name, closed outline CCW seen from +Z, circular through holes, thickness)
def rect(a,b):return [(-a/2,-b/2),(a/2,-b/2),(a/2,b/2),(-a/2,b/2)]
holes=[(x,y,D/2) for x in (-H,H) for y in (-H,H)]
def foil(w,north):
    # Opposed flat tongues provide connection pads outside the insulating support.
    p=[(-w/2,-L/2),(w/2,-L/2),(w/2,L/2),(TAIL/2,L/2),(TAIL/2,P/2+12),(-TAIL/2,P/2+12),(-TAIL/2,L/2),(-w/2,L/2)]
    return p if north else [(-x,-y) for x,y in p]
parts={'carrier':(rect(P,P),holes,T),'shim':(rect(10,10),[(0,0,D/2)],S),'bottom_common':(foil(W,False),[],F),'top_symmetric':(foil(W,True),[],F),'top_narrow':(foil(W/2,True),[],F)}
solids={}
for name,(p,circs,h) in parts.items():
    solid=cq.Workplane('XY').polyline(p).close().extrude(h)
    doc=ezdxf.new('R2010');doc.units=4
    for layer,color in [('PROFILE',1),('HOLE',3)]:doc.layers.new(layer,dxfattribs={'color':color})
    m=doc.modelspace();m.add_lwpolyline(p,close=True,dxfattribs={'layer':'PROFILE'})
    for x,y,r in circs:
        solid=solid.cut(cq.Workplane('XY').center(x,y).circle(r).extrude(h));m.add_circle((x,y),r,dxfattribs={'layer':'HOLE'})
    assert solid.val().isValid();solids[name]=solid.val()
    doc.saveas(root/'cut'/(name+'.dxf'))
for variant in ['symmetric','narrow']:
    a=cq.Assembly(name='coupon_'+variant)
    def add(name,part,x,y,z,rgb):a.add(solids[part],name=name,loc=cq.Location(cq.Vector(x,y,z)),color=cq.Color(*rgb))
    add('lower','carrier',0,0,0,(.8,.88,.99));add('upper','carrier',0,0,T+S,(.8,.88,.99))
    add('lower_foil','bottom_common',0,0,T,(.77,.39,.18));add('upper_foil','top_'+variant,0,0,T+S-F,(.77,.39,.18))
    for i,(x,y,r) in enumerate(holes):add('spacer_'+str(i+1),'shim',x,y,T,(.5,.6,.7))
    a.save(str(root/'model'/('coupon_'+variant+'.step')))
print('Built',list(parts),'and two STEP assemblies')
# Separate passive board cradle; board envelope is a fit gauge, not PCB design data.
coords=[(x,y) for x in (-31.,31.) for y in (-18.5,18.5)]
d=ezdxf.new('R2010');d.units=4
for l in ['PROFILE','HOLE']: d.layers.new(l)
m=d.modelspace();m.add_lwpolyline(rect(90,65),close=True,dxfattribs={'layer':'PROFILE'})
base=cq.Workplane('XY').box(90,65,3,centered=(True,True,False));gauge=cq.Workplane('XY').box(70,45,1.6,centered=(True,True,False))
for x,y in coords:
    m.add_circle((x,y),1.7,dxfattribs={'layer':'HOLE'});base=base.cut(cq.Workplane('XY').center(x,y).circle(1.7).extrude(3));gauge=gauge.cut(cq.Workplane('XY').center(x,y).circle(1.6).extrude(1.6))
d.saveas(root/'cut'/'pcb_stand_base.dxf');a=cq.Assembly(name='board_stand');a.add(base,name='base');a.add(gauge,name='PCB_blank_fit_gauge',loc=cq.Location(cq.Vector(0,0,9)))
for i,(x,y) in enumerate(coords):a.add(cq.Workplane('XY').circle(2.5).circle(1.65).extrude(6),name='spacer_'+str(i+1),loc=cq.Location(cq.Vector(x,y,3)))
a.save(str(root/'model'/'pcb_stand.step'))
