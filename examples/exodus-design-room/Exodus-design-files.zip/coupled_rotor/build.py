"""Rotary coupled hypothesis fixture. Edit here; output dimensions mm, base top z=0. Run with Python, cadquery, ezdxf."""
from pathlib import Path
import cadquery as cq, ezdxf
root=Path(__file__).resolve().parent
for f in ('models','cam'): (root/f).mkdir(exist_ok=True)
A=cq.Assembly(name='rotary_test');std={};draw={}
def add(name,solid,x=0,y=0,z=0,color=(.76,.76,.8),spin=0):
    A.add(solid,name=name,loc=cq.Location(cq.Vector(x,y,z),cq.Vector(0,0,1),spin),color=cq.Color(*color))
def block(w,d,h):return cq.Workplane('XY').box(w,d,h,centered=(True,True,False))
def cyl(r,h):return cq.Workplane('XY').circle(r).extrude(h)
def hole(part,x,y,r,h,start=0):return part.cut(cyl(r,h).translate((x,y,start)))
def rect(w,d):return ((-w/2,-d/2),(w/2,-d/2),(w/2,d/2),(-w/2,d/2))
def record(name,solid,outline,holes):
    assert solid.val().isValid(),name
    cq.exporters.export(solid,str(root/'models'/(name+'.step')));std[name]=solid
    doc=ezdxf.new('R2010');doc.units=4
    for l in ['OUTER','THRU','BLIND','CSINK']: doc.layers.new(l)
    m=doc.modelspace()
    if isinstance(outline,(float,int)):m.add_circle((0,0),outline,dxfattribs={'layer':'OUTER'})
    else:m.add_lwpolyline(outline,close=True,dxfattribs={'layer':'OUTER'})
    for x,y,r,layer in holes:m.add_circle((x,y),r,dxfattribs={'layer':layer})
    doc.saveas(root/'cam'/(name+'.dxf'))
def thru(s,ls,h):
    for x,y,r in ls:s=hole(s,x,y,r,h)
    return s
def circles(ls):return [(*v,'THRU') for v in ls]
# Base, boss and journal. Bolt boss to base before bonding the pin. All fixed pins/bolts clear rotating part below thrust washer.
boss_b=[(-11,0,1.7),(11,0,1.7)]; pedestal_h=[(0,-19,1.7),(0,19,1.7)]
bh=boss_b+[(60+x,y,r) for x,y,r in pedestal_h];base=hole(thru(block(350,350,12),bh,12),0,0,4.1,8,4);record('base_12',base,rect(350,350),circles(bh)+[(0,0,4.1,'BLIND')]);add('base',base,z=-12)
# screw heads for boss sunk into counterbores from its top
boss=thru(cyl(17,20),boss_b+[(0,0,4.1)],20)
for x,y,_ in boss_b:boss=hole(boss,x,y,3.2,4,16)
record('fixed_boss_20',boss,17,circles(boss_b+[(0,0,4.1)])+[(x,y,3.2,'BLIND') for x,y,_ in boss_b]);add('boss',boss)
add('fixed_pin_8x72',cyl(4,72),z=-8);washer=hole(cyl(8,1),0,0,4.2,1);add('thrust_washer',washer,z=20)
hubholes=[(0,-14,1.7),(0,14,1.7)];hub=thru(cyl(20,24),[(0,0,4.1)]+hubholes,24)
# recessed nuts underside, use M3 nylon nuts <=6.3 across corners, <=3 thick; retain with adhesive
for x,y,_ in hubholes:hub=hole(hub,x,y,3.25,3.5)
record('plain_hub_24',hub,20,circles([(0,0,4.1)]+hubholes)+[(x,y,3.25,'BLIND') for x,y,_ in hubholes]);add('hub',hub,z=21)
# Upright coupon carrier centre plane at y=0; bracket inner face at y=+4 (other side mirrored by rotating whole part).
foot=[(-20,0,2.15),(20,0,2.15)];magbolts=[(-9,0,1.7),(9,0,1.7)]
dr=[(0,0,4.3)]+hubholes
for s in (-1,1):dr.extend([(s*(100+x),s*12,r) for x,y,r in foot]+[(s*(60+x),0,r) for x,y,r in magbolts]);
disc=thru(cyl(155,8),dr,8)
for x in [-60,60]:disc=hole(disc,x,0,3.15,6.15)
record('disc_8',disc,155,circles(dr)+[(x,0,3.15,'BLIND') for x in [-60,60]]);add('disc',disc,z=45,color=(.7,.8,.65))
# Magnetic retaining plate: counterbore facing DOWN. No hardware below lower surface.
cap=thru(block(28,12,5),magbolts,5)
for x,y,_ in magbolts:cap=hole(cap,x,y,3.3,3.3)
record('keeper_5',cap,rect(28,12),circles(magbolts)+[(x,y,3.3,'BLIND') for x,y,_ in magbolts])
br=thru(block(84,16,24),foot,24)
for x in [-32,32]:br=br.cut(cq.Workplane('XZ').center(x,12).circle(1.7).extrude(10,both=True))
record('clamp_24',br,rect(84,16),circles(foot));# Cross holes use STEP and side face drilling dimensions, NOT top DXF.
for s in [-1,1]:
    ang=0 if s==1 else 180
    add('clamp'+str(s),br,100*s,12*s,53,(.3,.6,.8),ang);add('keeper'+str(s),cap,60*s,0,40);add('magnet'+str(s),cyl(3,6),60*s,0,45.1,(.6,.3,.3))
    # Import actual coupon (world rotation maps x to -Z, y to +X, z to -Y). Mount lower bolt row 12 mm above rotor. Center height 44.
    c=cq.importers.importStep(str(root/'companions/capacitor/model/coupon_narrow.step')).rotate((0,0,0),(0,0,1),-90).rotate((0,0,0),(1,0,0),90).translate((0,4,44))
    add('article'+str(s),c,100*s,0,53,(.85,.72,.56),ang)
# Pickup top z37: deck 25 high, flange seats at 23, total winding assembly height 14.
ped=hole(thru(block(32,50,25),pedestal_h,25),0,0,11.2,2,23)
record('pickup_deck_25',ped,rect(32,50),circles(pedestal_h)+[(0,0,11.2,'BLIND')]);add('pickup_deck',ped,60,0)
bob=cyl(11,2).union(cyl(6,12).translate((0,0,2))).union(cyl(11,2).translate((0,0,12)));bob=hole(bob,0,0,4,14);add('wound_former_envelope_no_wire',bob,60,0,23,(.8,.45,.2))
# Retaining collar fixed on pin above disc; z=54 gives 1 mm axial free play at nominal dimensions
add('retaining_collar_gauge',hole(cyl(8,8),0,0,4,8),z=54)
A.save(str(root/'models'/'assembly.step'));print('Exported',len(std),'machined parts and assembly')
