#!/usr/bin/env python3
"""Necessary (not sufficient) work/torque bounds for a post-disconnect rotary hypothesis. SI."""
import math,argparse
p=argparse.ArgumentParser(description=__doc__)
for name,value in dict(n=2,r=.1,force=1e-6,turns=1,charge_J=1e-6,other_in_J=0.,margin_J=0.,eta=.25,drag_Nm=0.,target=1.).items(): p.add_argument('--'+name,type=float,default=value)
a=p.parse_args()
assert all(math.isfinite(v) for v in vars(a).values()) and a.n>=1 and float(a.n).is_integer() and min(a.r,a.turns,a.eta,a.target)>0 and a.eta<=1 and min(a.force,a.charge_J,a.other_in_J,a.margin_J,a.drag_Nm)>=0
angle=2*math.pi*a.turns
tau=a.n*a.r*a.force
win=a.charge_J+a.other_in_J
# This forward illustration grants uniform body-tangential force, zero external shaft work during the stroke and equal endpoint kinetic energy. eta maps pickup work to external load joules only; exclude pickup losses from drag.
print('Granted torque (N m):',tau,'; work supplied by hypothetical force (J):',tau*angle)
print('Max load J after stipulated drag and pickup efficiency:',max(0.,tau-a.drag_Nm)*angle*a.eta)
print('Required mean tangential force per article (N) to reach target, including stated margin:',(a.drag_Nm+(a.target*win+a.margin_J)/(a.eta*angle))/(a.n*a.r))
print('Lab-fixed constant force: 0 J over integer full turns. These are model bounds; turns, force, efficiency, metered input and drag are not observations.')
