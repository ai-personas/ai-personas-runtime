# Can the reported post-disconnect force generate electricity?

**A disconnected stroke can do work. That is not the same as an energy source that can be reset.** For the public record, start with [what moved and what was switched](exodus/WHAT-MOVED.md). For CAD/CAM, the PCB and the measurement and simulation kits, see [engineering files](exodus/START-HERE.md). These are investigational designs, not a reconstruction validated against the proprietary article. Research and digital design only; no ordering, fabrication or powered testing is authorized.

## Two articles with the same *simulated* force trace

See the [editable two-body reference actuator and cycle](eli_charge_position/README.md). Charge at A, isolate, move against a load to B, recover charge there, return uncharged. Both synthetic traces reach B after 10 mm carrying 100 pC. Both accept 0.50 nJ during reversible charge and make 0.35 nJ available on the stroke. What distinguishes them is the **voltage while recovering the charge**, not the mechanical travel:

|Model|Voltage at B before discharge|Ideal discharge recovery|Stroke + recovery minus charging work|
|---|---:|---:|---:|
|Force paired with its stored-energy voltage response|3 V|0.15 nJ|0 nJ|
|Same force, voltage response to the extra force omitted|5 V|0.25 nJ|+0.10 nJ by construction|

The small integration error in the paired trace is about 1.1 fJ. The larger force-only residual is a prediction about a *missing energy term*, not a measured source. A hidden store, coupling to a support or another electrical port could pay it. Returning position and terminal charge is not proof that all those states returned.

## What efficiency would let a load see even the stipulated excess?

Let `g` be stroke-to-bus efficiency, `r` discharge-to-bus efficiency, `k` actual charging energy divided by the ideal 0.50 nJ, and `A` all additional energy input per cycle in nJ. For these traces, excess electrical energy at the common bus would require **g × 0.35 + r × recovery > k × 0.50 + A** (nJ). Recovery credits charge drained into that bus once, not heat dissipated in a bleed resistor. Energy reused from that bus for the next charge must not also be counted as load export. A real device must measure actual load delivery and all inputs over a restored cycle. Efficiencies here are whole-path assumptions, not measured component ratings.

* Paired model: even ideal conversion and recovery only break even. Any real losses reduce delivered energy.
* Force-only model: with reversible charging, lossless charge recovery and no auxiliaries, stroke-to-bus conversion must exceed 5/7 (71.4%) to export more than the source provides. At 80% stroke conversion and 80% recovery, 0.28 + 0.20 = 0.48 nJ reaches the bus for 0.50 nJ in: a deficit even before auxiliaries.
* Charging a linear 10 pF capacitor from zero from a fixed 10 V supply through a resistor costs V × Q = 1.00 nJ, although only 0.50 nJ is stored. With that charger (`k=2`) even the force-only example with perfect collection gives only 0.60 nJ out. This is a charger comparison, not a claim about Exodus hardware.

Run from the extracted folder (Python 3, standard library):

```
python3 electrical_budget.py
python3 electrical_budget.py --generator .8 --recovery .8
python3 electrical_budget.py --charge-factor 2
```

The script integrates the force–position and voltage–charge paths from the two example CSVs. In the ideal comparison the uncharged return does no field work; do not assume a real mechanism returns without friction or controls. The budget assigns fractions of available work: it does **not** simulate a converter that achieves those efficiencies. No output power rating is possible from stroke energy alone; cycle rate and actual losses matter. A persistent indication on a stationary balance yields no stroke energy at all.

**What would change the conclusion:** existing synchronized calibrated data for the same article and run showing isolation, its charge/voltage history, force and displacement under load, electrical load energy, source and auxiliary energy through recharge/reset, and bounds on changes in other stores and environmental work. Compare active and control runs with uncertainty. The chamber force report and the separate rotation clips do not jointly supply these measurements. This package is a way to discriminate mechanisms, not a demonstrated COP above one.
