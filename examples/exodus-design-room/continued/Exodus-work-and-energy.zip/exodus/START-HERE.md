# Exodus: does a force after charging supply useful electricity?

**Run-by-run finding:** [What moved, what was switched, and what would establish generation](WHAT-MOVED.md). Includes observations from both T-blade clips.

**The available evidence does not demonstrate that it does.** The inventors report force-meter deflections. A static force supplies no mechanical power, and opening a charging circuit does not remove stored energy. To establish a new source, a moving article must do work against a load, then repeat the cycle after every depleted store and configuration has been restored. A measured electrical output must exceed all supplied energy by more than the combined error bound. Neither a plot of force versus time nor simulated resistor heating meets that test.

**What the public record adds.** In the [interview, company summary and patent comparison](PUBLIC-RECORD.md), the “unity” reported for propulsion means thrust equal to article weight, not electrical output equal to electrical input. The company describes energy applications as a future possibility. The [free-motion model](free_rotor/README.md) illustrates why even a real post-disconnect load signal would not, by itself, close that gap.

## Start with the claimed effect

1. [Read the patent figures against the proposed force law](source_audit/FROM-PLOT-TO-WORK.md). [Public experimental comparison](source_audit/PUBLIC-COMPARATOR.md) gives a separate point of reference. The [source audit](source_audit/FINDINGS.md) distinguishes disclosed apparatus, reported observations and missing records. [Conventional field calculation](source_audit/FIELD-MODEL.md) shows why large *internal* forces in an asymmetric assembly need not yield net thrust, and how an enclosure can change the result.
2. **Test work before designing for continuous power.** The short-stroke suspension preserves the static orientation and asks whether the article moves a known load. Recoverable gravitational energy on one stroke is not a surplus. The rotor asks a stronger question: does the force remain tangential for a whole turn, exceeding drag and pickup reaction torque? A force anchored to the room gives a different prediction. Neither the proposed 5 V controls nor the air coupons duplicate the patent’s encapsulated test articles.
3. **Count the joules.** The 5 V PCB illustrates finite energy after disconnection. The separate coil converts shaft work to electricity. The example at a prescribed 1 rpm gives 0.352 nJ per turn in the load, requiring 0.382 nJ per turn at the shaft **before bearing losses**. Neither value identifies what turned the rotor. Use the electrical and shaft reducers on synchronized data and compare identical initial and final states.

## Open the files

See the [module guide](MODULE-GUIDE.md) for editable CAD and drawings, KiCad schematic and PCB, Gerbers, drill, BOM, simulations and the original control protocols. These are designs for investigating the premise, **not build files for a demonstrated surplus generator**. Historical build and operating notes describe design intent, not authorization. This issue is for research and digital design only: do not order, fabricate or power anything under this brief.

New experiment and analysis modules:
- [translation](translation/README.md)
- [rotor_audit](rotor_audit/README.md)
- [pickup_metrology](pickup_metrology/README.md)
- [pickup_transfer](pickup_transfer/START-HERE.md)
- [rotor_metrology](rotor_metrology/START-HERE.md)

See [existing-record return](RECORD-RETURN.md) for what would change the conclusion. Hashes of all payload files except the manifest itself are in `PACKAGE-SHA256.txt` (relative to this directory). Numerical examples throughout are model outputs or explicitly synthetic records unless an external observation is attributed to its source.

### Does the force do work on the way back?
Use the [signed path-work comparison](path_work/README.md) when force and position are known together. A 235.36 µN force does +14.1216 nJ over a 60 µm outward stroke. Leave it unchanged through the same return stroke and its signed loop work is zero. Remove it for the return and the same channel does +14.1216 nJ on the loop; the energy cost of changing its state is then essential. Neither history is identified by a stationary force trace. A functional generator must deliver electrical energy after **all** such costs are counted.

## What if the speed is not imposed?
[Free rotor from rest or initial spin](free_rotor/README.md) solves for motion against drag and the stationary pickup. Compare the zero-drive coasting, subthreshold and stipulated-torque cases. Positive load energy in the coasting case comes from initial kinetic energy. In the driven case the torque is an assumed work input, not derived from the patent.

[Public talk and whole-device momentum balance](PUBLIC-TALK-AND-MOMENTUM.md)

[Public evidence and the two different unity claims](PUBLIC-RECORD.md)

[Conference evidence, independent control and worked fixed-charge alternative](chamber_comparison/README.md)
