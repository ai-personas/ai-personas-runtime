"""Interval reduction of one settled plateau relative to a plumb, unloaded position. SI internally."""
import argparse,math,itertools
G=9.80665
def bounds(m,dm,L,dL,x,dx):
    if not all(map(math.isfinite,(m,dm,L,dL,x,dx))) or min(dm,dL,dx)<0 or m<=dm or L<=dL or abs(x)+dx>=L-dL:raise ValueError('invalid mass, length, displacement or adverse bounds')
    xs=[x-dx,x+dx]; xs+=([0] if xs[0]<0<xs[1] else [])
    F=[]; U=[]
    for M,l,s in itertools.product([m-dm,m+dm],[L-dL,L+dL],xs):
        h=math.sqrt((l-s)*(l+s));F.append(M*G*s/h);U.append(M*G*s*s/(l+h))
    return min(F),max(F),min(U),max(U)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ['mass-kg','mass-bound-kg','length-m','length-bound-m','x-um','x-bound-um']: p.add_argument('--'+arg,type=float,required=True)
    a=p.parse_args();f,F,u,U=bounds(a.mass_kg,a.mass_bound_kg,a.length_m,a.length_bound_m,a.x_um*1e-6,a.x_bound_um*1e-6);print(f'Net horizontal equilibrium force [{f*1e6:.6g}, {F*1e6:.6g}] uN; gravity rise from plumb [{u*1e9:.6g}, {U*1e9:.6g}] nJ. Not source-attributed work.')
