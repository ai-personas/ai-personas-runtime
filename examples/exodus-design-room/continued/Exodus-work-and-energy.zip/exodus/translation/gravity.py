"""Passive displacement and lift, SI. Exact four-parallel-line model. No applied-power or anomalous-force model."""
import math,argparse
G=9.80665
def model(m,L,F):
    if not all(map(math.isfinite,(m,L,F))) or m<=0 or L<=0: raise ValueError('finite SI values; positive mass and length')
    weight=m*G; norm=math.hypot(weight,F); x=L*(F/norm); z=L*(F/norm)*(F/(norm+weight)); return x,weight*z
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mass-kg',type=float,default=.4);p.add_argument('--length-m',type=float,default=1.);p.add_argument('--force-uN',type=float,nargs='+',default=[237.,421.]); a=p.parse_args()
    for f in a.force_uN:
        x,U=model(a.mass_kg,a.length_m,f*1e-6);print(f'{f:g} uN imposed -> {x*1e6:.5f} um equilibrium; {U*1e9:.5f} nJ stored; {f*x*1e3:.5f} nJ constant-force work to that coordinate')
