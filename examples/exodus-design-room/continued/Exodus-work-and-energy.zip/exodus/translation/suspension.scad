// Passive, unpowered kinematic model; mm. +X is the tested horizontal axis.
// Coordinates of suspension vertices refer to hole axes at facing plate surfaces.
mode="assembly"; L=1000; x=0; X=120; Y=180; thick=5; ax=48; ay=78; d=2;
assert(abs(x)<L); dz=sqrt(L*L-x*x); $fn=48;
module outline(){difference(){square([X,Y],center=true);for(i=[-1,1],j=[-1,1])translate([i*ax,j*ay])circle(d=d);}}
module plate(){linear_extrude(thick)outline();}
if(mode=="flat")outline();
if(mode=="plate")plate();
if(mode=="assembly"){
 color("gray")translate([0,0,L])plate();
 color("wheat")translate([x,0,L-dz-thick])plate();
 // Reference envelope ONLY: 3 x 5 inch back face; 20 mm depth assumed. Not hardware.
 color("skyblue")translate([x-10,-63.5,L-dz])cube([20,127,76.2]);
 for(i=[-1,1],j=[-1,1])color("gray")translate([i*ax+x,j*ay,L-dz])rotate([0,-asin(x/L),0])cylinder(h=L,r=0.4);
}
