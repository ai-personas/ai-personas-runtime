"""Bound signed mechanical work from independently bounded monotone segments (SI)."""
import argparse,csv,math,json

def reduce(path):
    with open(path,newline='') as f:
        r=csv.DictReader(f); fields=['x_m','ux_m','Fx_low_N','Fx_high_N']; rows=list(r)
        if r.fieldnames!=fields or len(rows)<3: raise ValueError('expected header '+','.join(fields)+' and at least three positions')
    endpoints=[]; intervals=[]; prev=None
    for i,row in enumerate(rows):
        if None in row or any(v is None for v in row.values()): raise ValueError('malformed row')
        x,u=map(float,[row['x_m'],row['ux_m']]); xl,xh=x-u,x+u
        if not all(map(math.isfinite,[xl,xh])) or u<0: raise ValueError('invalid position bound')
        endpoints.append((xl,xh))
        if prev is None:
            if row['Fx_low_N'] or row['Fx_high_N']: raise ValueError('initial point must have empty force fields')
        else:
            l,h=map(float,[row['Fx_low_N'],row['Fx_high_N']]); dl,dh=xl-prev[1],xh-prev[0]
            if not all(map(math.isfinite,[l,h])) or h<l: raise ValueError('invalid segment force envelope')
            a=[v*d for v in (l,h) for d in (dl,dh)]; intervals.append((min(a),max(a)))
        prev=(xl,xh)
    lo,hi=(math.fsum(z) for z in zip(*intervals)); dx=[endpoints[-1][0]-endpoints[0][1],endpoints[-1][1]-endpoints[0][0]]
    if not all(map(math.isfinite,[lo,hi,*dx])): raise ValueError('nonfinite result')
    return {'segments':len(intervals),'W_J':[lo,hi],'x_final_minus_initial_m':dx,'segment_W_J':intervals}

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('trace');ap.add_argument('--control');args=ap.parse_args();a=reduce(args.trace);o={'trace':a}
    if args.control:
        b=reduce(args.control);o.update(control=b,contrast_W_J=[a['W_J'][0]-b['W_J'][1],a['W_J'][1]-b['W_J'][0]])
    print(json.dumps(o,indent=2,allow_nan=False))
