import math,tempfile
from pathlib import Path
from path_work import reduce
base=Path(__file__).resolve().parent
z=reduce(base/'unchanged_force.csv'); a=reduce(base/'removed_on_return.csv'); b=reduce(base/'bounded_cycle.csv'); assert z['W_J']==[0.,0.] and z['segment_W_J'][0][0]>0 and z['segment_W_J'][1][1]<0; assert all(math.isclose(v,14.1216e-9,rel_tol=1e-12) for v in a['W_J']); assert b['W_J'][0]<0<b['W_J'][1] and b['x_final_minus_initial_m'][0]<0<b['x_final_minus_initial_m'][1]
with tempfile.TemporaryDirectory() as d:
    t=Path(d)/'bad.csv'; t.write_text((base/'bounded_cycle.csv').read_text().replace('0.000230,0.000240','0.000250,0.000240'))
    try: reduce(t)
    except ValueError: pass
    else: raise AssertionError('accepted inverted force bound')
print('synthetic loop J, constant:',z['W_J'],'removed:',a['W_J'],'finite bounds:',b['W_J'])
