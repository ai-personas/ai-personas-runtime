# What did Buhler say persisted?

Christopher Plain’s [April 19, 2024 report in *The Debrief*](https://thedebrief.org/physics/nasa-veterans-propellantless-propulsion-drive-that-physics-says-shouldnt-work-just-produced-enough-thrust-to-defeat-earths-gravity), section **Understanding the Physics is a Job for Science**, second paragraph, quotes Buhler speaking to Tim Ventura: “if they still have charge in them, they are still producing thrust.” The preceding words describe articles sitting **on a scale for days**. This is the quotation as printed, not an independent transcription of the recording.

The reported observable is a persistent scale indication on a supported article. Buhler interprets it as thrust associated with the charged state. Neither the phrase “no constant input of electrical charge” nor a stationary reading measures electrical isolation, motion and delivered power together. For comparison, a charged capacitor facing an external electrode can sustain a force at fixed spacing without doing mechanical work there. That counterexample does not diagnose the Exodus apparatus. A force-time integral has units of impulse; work requires force along a displacement.

## Two different meanings of unity

In **The Device and The Thrust**, the paragraph beginning “The aim is to approach and exceed unity” defines unity as enough thrust to lift the test article. That ratio is force divided by weight, F/(mg), not load joules divided by supplied joules. The same section quotes about 10 mN as a stacked-system maximum. Do not pair it with a mass from another description unless both belong to the same run. Even a verified thrust-to-weight ratio of one would not determine electrical gain.

For a generator inference, identify the same run and system boundary: switch states and leakage, remaining charge, force along a measured path against a load, and synchronized signed electrical port power. Compare input and load energy through recharge and mechanical reset, with matched or bounded endpoint energies. Bound interactions with the support and chamber and account for external drive separately. The quoted passages provide no such cycle record.

## Recording locators, not transcripts

Tim Ventura’s *Propellantless Propulsion Device | Charles Buhler* lists [19:59 — Force Duration & Applied Charge](https://www.youtube.com/watch?v=WhsKMWOYuYo&t=1199s) and [22:55 — Conservation of Energy](https://www.youtube.com/watch?v=WhsKMWOYuYo&t=1375s). The watch page lists English automatic captions, but the timed-text request returned an empty body. The timestamps locate discussions; no spoken wording or experimental result was verified from them.

[Danny Jones Podcast #422, Buhler and Andrew Aurigema](https://podcasts.apple.com/us/podcast/422-we-cracked-antigravity-nasa-physicists-shows-proof/id1441238966?i=1000783348206) lists 01:43:48 for a video demo and 01:49:43 for skeptics’ criticism. These too are publisher chapter labels, not verified descriptions of footage or energy measurements.
