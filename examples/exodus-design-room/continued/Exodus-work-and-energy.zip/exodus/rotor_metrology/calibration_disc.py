"""Optional replacement for disc_8. Run in any directory (CadQuery + ezdxf). Dimensions mm."""
from pathlib import Path
import cadquery as cq, ezdxf, math
R=Path(__file__).resolve().parent
base=cq.importers.importStep(str(R/'source/disc_8.step')).val(); orig=base.Volume(); s=base
D=ezdxf.readfile(R/'source/disc_8.dxf'); m=D.modelspace()
assert D.units==4 and abs(base.BoundingBox().xlen-310)<1e-5
for y in (140,-140):
    cut=cq.Solid.makeCylinder(1.6,10,cq.Vector(0,y,-1)); s=s.cut(cut)
    m.add_circle((0,y),1.6,dxfattribs={'layer':'THRU'})
cq.exporters.export(s,str(R/'disc_static_cal.step')); D.saveas(R/'disc_static_cal.dxf')
# Reimport both. Include a displaced pin which must collide as control.
out=cq.importers.importStep(str(R/'disc_static_cal.step')).val(); dx=ezdxf.readfile(R/'disc_static_cal.dxf'); assert not dx.audit().has_errors
assert out.isValid() and len(out.Solids())==1 and abs(orig-out.Volume()-2*math.pi*1.6**2*8)<1e-4
for y in (140,-140):
    assert len([e for e in dx.modelspace().query('CIRCLE') if e.dxf.layer=='THRU' and abs(e.dxf.center.y-y)<1e-8 and abs(e.dxf.center.x)<1e-8 and abs(e.dxf.radius-1.6)<1e-8])==1
    p=cq.Solid.makeCylinder(1.5,8,cq.Vector(0,y,0)); assert out.intersect(p).Volume()<1e-7 and out.intersect(p.translate((4,0,0))).Volume()>50
print('Original and modified disc volumes (cm3):',orig/1000,out.Volume()/1000)
print('Hypothetical modified disc mass alone at 1.41 g/cm3 (kg):',out.Volume()*1.41e-6)
