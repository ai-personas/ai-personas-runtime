"""Reduce same-angle CCW/CW *positive magnitude* incipient tangential pull samples. Stdlib only."""
import argparse,csv,math,statistics
from collections import defaultdict
p=argparse.ArgumentParser(description=__doc__);p.add_argument('csv');p.add_argument('--article-force-uN',type=float,default=1,help='stipulated force per article; not data');a=p.parse_args(); rows=defaultdict(list)
if not math.isfinite(a.article_force_uN) or a.article_force_uN<0: p.error('force must be finite and nonnegative')
for rec in csv.DictReader(open(a.csv,newline='')):
    angle,fwd,rev,arm,uf,ur=map(float,[rec[k] for k in ('angle_deg','ccw_mN','cw_mN','arm_mm','abs_force_error_mN','abs_arm_error_mm')]);
    if not all(map(math.isfinite,(angle,fwd,rev,arm,uf,ur))) or not(0<=angle<360 and min(fwd,rev,uf,ur)>=0 and arm>ur): p.error('invalid angle, force, length or absolute error bound')
    # mN times mm = micro N m. Arm means perpendicular distance to measured force line.
    rows[angle].append((arm*fwd,arm*rev,uf*arm+ur*max(fwd,rev)+uf*ur))
if not rows:p.error('no measurements')
angles=sorted(rows);drive=2*.100*a.article_force_uN
print('angle_deg,n,mean_CCW_uNm,mean_CW_uNm,halfwidth_uNm,apparent_bias_uNm,worst_CCW_upper_uNm')
bias=[]; worst=-1
for deg in angles:
    samples=rows[deg]; x,y=[statistics.mean(s[i] for s in samples) for i in (0,1)];v=(y-x)/2;bias.append(v); upper=max(s[0]+s[2] for s in samples);worst=max(upper,worst)
    print(f'{deg:g},{len(samples)},{x:.6g},{y:.6g},{(x+y)/2:.6g},{v:.6g},{upper:.6g}')
print(f'Granted CCW torque: {drive:g} uN m; worst sampled CCW threshold incl. stated instrument bounds: {worst:.6g} uN m. No inference at unsampled angles or about dynamic torque.')
if len(angles)>=4 and all(abs((angles[(i+1)%len(angles)]-d)%360-360/len(angles))<1e-6 for i,d in enumerate(angles)):
    c,s=[2/len(angles)*sum(b*f(math.radians(d)) for b,d in zip(bias,angles)) for f in (math.cos,math.sin)];print(f'Apparent bias mean {statistics.mean(bias):.6g} uN m; first harmonic amplitude {math.hypot(c,s):.6g} uN m. Directional friction asymmetry is inseparable here; this fit is NOT thrust.')
