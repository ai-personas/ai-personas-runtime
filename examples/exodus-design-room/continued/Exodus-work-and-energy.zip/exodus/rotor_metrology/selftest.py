from pathlib import Path
import subprocess,sys,tempfile
p=Path(__file__).resolve().parent
def run(path):return subprocess.run([sys.executable,str(p/'breakaway.py'),str(path)],capture_output=True,text=True)
r=run(p/'SYNTHETIC.csv');assert r.returncode==0 and 'bias mean 3 uN m; first harmonic amplitude 20 uN m' in r.stdout and '5021.59' in r.stdout
assert run(p/'EMPTY.csv').returncode!=0
with tempfile.TemporaryDirectory() as t:
 f=Path(t)/'x.csv';hdr=(p/'EMPTY.csv').read_text();
 for row in ['0,nan,10,140,0.1,0.1','0,1,2,1,.1,1','90,-1,2,140,0,0']:
  f.write_text(hdr+row+'\n');assert run(f).returncode!=0
 f.write_text(hdr+'0,2,1,140,0,0\n');r=run(f);assert '0,1,280,140,210,-70,280' in r.stdout and 'harmonic' not in r.stdout
print('PASS: synthetic bias and upper bound; CW bias sign; empty, nonfinite, negative and invalid-arm cases')
