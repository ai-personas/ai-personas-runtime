"""Conditional single external capacitor model. SI units. No measured apparatus parameters."""
import argparse, math

def stroke(force, voltage, capacitance, dx):
    if not all(math.isfinite(a) for a in (force,voltage,capacitance,dx)) or min(force, voltage, capacitance, dx)<=0: raise ValueError('All four inputs must be finite and positive')
    grad=2*force/voltage**2
    dc=grad*dx
    frac=dc/capacitance
    u0=0.5*capacitance*voltage**2
    # At fixed charge, integral F(x) dx, evaluated without subtracting almost equal energies.
    w=u0*frac/(1+frac)
    return dict(gradient_F_per_m=grad, delta_C_F=dc, initial_field_J=u0, final_voltage_V=voltage/(1+frac), final_force_N=force/(1+frac)**2, outward_work_J=w, ideal_return_input_J=w, round_trip_net_J=0.0)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--force-N',type=float,default=0.0009);p.add_argument('--voltage-V',type=float,default=9500);p.add_argument('--capacitance-F',type=float,default=1e-10);p.add_argument('--travel-m',type=float,default=.001);a=p.parse_args();
    for k,v in stroke(a.force_N,a.voltage_V,a.capacitance_F,a.travel_m).items():print(f'{k}: {v:.10g}')
