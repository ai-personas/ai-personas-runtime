# What can a charged article do after its supply is disconnected?

**Answer from the reported chamber force alone:** it could stay still and do no translational work; it could move and use stored field energy; or there could be another interaction. A force reading at one position does not choose between these. In particular, it does not set a generator rating. Power under translation is force **along motion** times speed, and even measured mechanical power does not identify its source.

[Three public conference accounts](conference.md) distinguish the chamber-voltage example, the switched apparent-weight example and the reports of charge persistence. [The independent electret study](comparator.md) gives a control precedent, not a replication. Do not splice the force from one article, the isolation condition from another and visible motion from a third into an energy measurement.

## A counterexample with the chamber numbers

The chamber report quotes roughly 0.90 mN at a plate voltage magnitude of 9.5 kV. **Suppose**, for comparison only, that a moving conductor also has 9.5 kV *relative to a stationary chamber surface*. Let its external capacitance be `C(x)=C0+g*x` over a short travel x. This is a local model; it is not the internal capacitance between rigidly joined plates. Isolate the moving node at charge `Q=C0*V0`. Then

- Field energy `U=Q²/(2C)`; external force `F=-dU/dx=Q²*g/(2*C²)`.
- Matching the force at x=0 needs `g=2*F0/V0²`, about 20 pF/m. The equal and opposite force acts on the surroundings. Neither lead current nor propellant flow is necessary for this force.
- With an **assumed** C0 of 100 pF, a 1 mm outward stroke increases C by about 0.020 pF. About 0.90 µJ of mechanical work is available, from about 4.51 mJ already in the field. The force changes by less than 0.05% in this example. Even near-constant force over such a stroke would not rule out stored energy.
- To restore x and Q reversibly by the same path requires that mechanical work back. Switching the electrical boundary conditions for the return can change the mechanical integral, but then the electrical transfer at switching and recharge belongs in the ledger. Real loss does not help the net output.

Run `python3 field_work.py` here; use `--help` for the four inputs. Change C0 or the travel to see which conclusions depend on unmeasured values. The initial observed scale reading **cannot determine C0, g or common-mode voltage individually**. In particular the applied plate voltage is NOT evidence of the assumed conductor-to-chamber voltage. This construction exhibits non-uniqueness; it neither fits an actual apparatus nor establishes the cause of any reported trace.

## Which records would distinguish the forces?

For a multi-electrode assembly relative to a grounded enclosure the instantaneous external-force term in a linear electrostatic model is `F=(1/2) vᵀ C′ v`. Here `C′` differentiates the *whole moving body's position*, not an internal plate gap. At fixed differential voltage write `v=v_diff+u*e`, where `u` shifts the common potential of the specified moving nodes and `e` selects them. Then `F(u)=A+B*u+D*u²`. Other unshifted potentials, trapped charge, position changes or dielectric relaxation may require more terms or state variables. A family of readings at several known common potentials, with unchanged internal field configuration, could reveal external coupling via the linear or quadratic terms. A null slope at one bias, or invariance on reversing all potentials, does not bound the constant external term A. A discriminating record needs geometry and independently bounded backgrounds as well as applied voltage. For isolated nodes the potentials must be solved from their charges rather than held by an uncounted supply.

For propulsion, identify what moves together and which chamber, support, probe or emitted flux can take momentum. For generation, identify where energy goes: signed force integrated over actual travel or torque over actual angle under a known load, then electrical power integrated at **all** boundary ports until mechanical, charge and other relevant states are restored or their differences bounded. The two questions require different evidence.
