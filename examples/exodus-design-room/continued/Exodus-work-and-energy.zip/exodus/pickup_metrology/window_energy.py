"""Deterministic bounds on LOAD DISSIPATION, not a COP or a torque measurement."""
import argparse, math

def bounds(v_rms, err_rms, r, r_frac, t):
    # Reverse triangle inequality in L2 over the SAME time window
    if not all(math.isfinite(x) for x in (v_rms,err_rms,r,r_frac,t)) or min(v_rms,err_rms)<0 or min(r,t)<=0 or not 0<=r_frac<1: raise ValueError('invalid load, window or uncertainty')
    return (t*max(0,v_rms-err_rms)**2/(r*(1+r_frac)), t*(v_rms+err_rms)**2/(r*(1-r_frac)))

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__)
    for key in ['vrms_uv','total_error_rms_uv','resistance_ohm','resistance_fraction','duration_s']: a.add_argument(key,type=float)
    x=a.parse_args(); lo,hi=bounds(x.vrms_uv*1e-6,x.total_error_rms_uv*1e-6,x.resistance_ohm,x.resistance_fraction,x.duration_s); print(f'load energy bounds J: {lo:.9g} .. {hi:.9g}')
