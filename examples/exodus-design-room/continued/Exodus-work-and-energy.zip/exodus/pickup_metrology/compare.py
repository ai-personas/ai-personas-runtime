"""Periodic steady state at prescribed 1 rpm. Synthetic input, not a run record."""
from pathlib import Path
import math,csv
p=Path(__file__).resolve().parent
with (p/'wave_1.csv').open() as f: rows=[{k:float(v) for k,v in r.items()} for r in csv.DictReader(f)]
n=len(rows); a=[r['theta_rad'] for r in rows]; assert n==512
# Periodic trapezoid includes last-to-first interval once; integrate on actual angular coordinates.
ds=[y-x for x,y in zip(a,a[1:]+[a[0]+math.tau])]; assert min(ds)>0 and max(abs(d-math.tau/n) for d in ds)<1e-6
w=math.tau/60
def integ(fn):
    y=[fn(r) for r in rows]; return math.fsum(d*(v+u)/2 for d,v,u in zip(ds,y,y[1:]+y[:1]))
el=integ(lambda r:r['Vload_V']**2/100)/w
cu=integ(lambda r:r['I_A']**2*8.43)/w
shaft=-integ(lambda r:r['reaction_on_rotor_Nm'])
rms=math.sqrt(sum(r['Vload_V']**2 for r in rows)/n)
assert abs(el-rms**2*60/100)<el*1e-5 and abs(el+cu-shaft)<shaft*.001 and shaft>el>0
print('Prescribed speed: 1 rpm; 512 synthetic samples; one turn; 100 ohm load; rounded winding resistance 8.43 ohm.')
print(f'Load RMS {rms*1e6:.6f} uV; load {el*1e9:.8f} nJ; winding {cu*1e9:.8f} nJ; opposing work from electromagnetic torque {shaft*1e9:.8f} nJ.')
print(f'Mean load-equivalent torque {el/math.tau*1e12:.4f} pN m; mean electromagnetic braking magnitude {shaft/math.tau*1e12:.4f} pN m. No bearing drag included.')
print('Agreement checks circuit accounting at prescribed speed. It does not identify what drives the shaft, or measure work by the article.')
