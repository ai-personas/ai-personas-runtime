"""Loaded free rotor, conditional model in SI units; Python 3 standard library."""
import argparse,csv,json,math
from pathlib import Path
HERE=Path(__file__).resolve().parent
DEFAULT=dict(inertia=0.002,initial_rpm=1.0,initial_angle_rad=0.0,force_per_article_N=0.0,radius_m=0.1,static_Nm=6e-6,kinetic_Nm=4e-6,viscous_Nms=0.0,winding_ohm=8.428444444444443,load_ohm=100.0,duration_s=120.0,dt_s=0.02)
def coupling(path):
    with open(path) as f:a=list(csv.DictReader(f))
    n=len(a); k=[float(x['k_Vs_per_rad']) for x in a]; t=[float(x['theta_rad']) for x in a]
    if n<32 or n%2 or not all(map(math.isfinite,k+t)) or max(abs(y-j*math.tau/n) for j,y in enumerate(t))>1e-7:raise ValueError('expected full-turn uniform bins, no duplicate endpoint')
    if abs(sum(k)/n)>max(1e-18,0.001*math.sqrt(sum(v*v for v in k)/n)):raise ValueError('nonclosing coupling')
    def interp(th):
        x=(th%math.tau)*n/math.tau;j=math.floor(x);u=x-j
        return (1-u)*k[j%n]+u*k[(j+1)%n]
    return interp,n

def solve(params,kpath,trace=None):
    p=DEFAULT.copy(); unknown=set(params)-set(p)
    if unknown:raise ValueError('unknown parameters '+str(unknown))
    p.update(params)
    if not all(type(x) in (int,float) and math.isfinite(x) for x in p.values()):raise ValueError('finite real parameters required')
    I=p['inertia'];s=p['static_Nm'];f=p['kinetic_Nm'];b=p['viscous_Nms'];rl=p['load_ohm'];rw=p['winding_ohm'];R=rl+rw;dt=p['dt_s'];end=p['duration_s'];r=p['radius_m'];D=2*r*p['force_per_article_N']
    if min(I,rl,rw,r,dt,end)<=0 or min(f,b,s-f)<0:raise ValueError('require positive scale parameters and static >= kinetic >= 0')
    k,n=coupling(kpath);t=0.;th=th0=p['initial_angle_rad'];w=w0=p['initial_rpm']*math.tau/60;K0=I*w*w/2
    load=cu=dry=vis=work=0.;peak=0.;maxstep=0.;stopped=None
    if trace:trace.writerow('time_end_s dt_s theta_end_rad omega_end_rad_s Vload_mid_V drive_work_cum_J dry_loss_cum_J viscous_loss_cum_J load_cum_J winding_cum_J'.split())
    # Midpoint balance. On a zero-speed crossing, end the substep there and reapply static friction.
    while t<end:
        h=min(dt,end-t);direction=math.copysign(1,w if w else D)
        if w==0 and abs(D)<=s:
            if stopped is None:stopped=t
            h=end-t;w1=0.;wm=0.;v=0.
        else:
            g=k(th+w*h/2);B=b+g*g/R;A=D-direction*f
            w1=((I-h*B/2)*w+h*A)/(I+h*B/2)
            if w*w1<0:
                h=I*w/(B*w/2-A);w1=0.;stopped=t+h if abs(D)<=s else stopped
            wm=(w+w1)/2;v=rl*g*wm/R
        d=wm*h;th+=d;work+=D*d;dry+=f*abs(d);vis+=b*wm*wm*h;load+=v*v/rl*h;cu+=(v/rl)**2*rw*h
        maxstep=max(maxstep,abs(d));peak=max(peak,abs(v));t+=h;w=w1
        if trace:trace.writerow([t,h,th,w,v,work,dry,vis,load,cu])
    final=I*w*w/2
    return dict(turns=(th-th0)/math.tau,final_rpm=w*60/math.tau,initial_kinetic_J=K0,final_kinetic_J=final,stipulated_drive_J=work,dry_loss_J=dry,viscous_loss_J=vis,winding_heat_J=cu,load_J=load,energy_residual_J=K0+work-final-dry-vis-cu-load,peak_load_V=peak,stuck_from_s=stopped,max_angle_step_bins=maxstep*n/math.tau)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('case',type=Path);ap.add_argument('--k',type=Path,default=HERE/'k.csv');ap.add_argument('--trace',type=Path);a=ap.parse_args();p=json.loads(a.case.read_text());f=a.trace.open('w',newline='') if a.trace else None
    try:result=solve(p,a.k,csv.writer(f) if f else None)
    finally:
        if f:f.close()
    print(json.dumps(result,indent=2,allow_nan=False))
if __name__=='__main__':main()
