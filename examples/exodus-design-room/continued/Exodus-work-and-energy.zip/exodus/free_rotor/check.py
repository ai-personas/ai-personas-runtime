"""Receiver self-check. No physical data or third-party modules required."""
import math,json,csv,tempfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
from solve import solve,DEFAULT
H=Path(__file__).resolve().parent
K=H/'k.csv'
def near(x,y,rel=1e-9,ab=1e-16):
    if not math.isclose(x,y,rel_tol=rel,abs_tol=ab):raise AssertionError((x,y))
with tempfile.TemporaryDirectory() as td:
    z=Path(td)/'zero.csv'
    with K.open() as f:rows=list(csv.DictReader(f))
    with z.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['theta_rad','k_Vs_per_rad']);w.writerows((r['theta_rad'],0.) for r in rows)
    I=DEFAULT['inertia'];f=DEFAULT['kinetic_Nm'];w=math.tau/60
    for sign in (1,-1):
        q=solve({'initial_rpm':sign},z);near(q['stuck_from_s'],I*w/f);near(q['turns'],sign*I*w*w/(2*f*math.tau));near(q['load_J'],0)
    q=solve({'kinetic_Nm':0,'static_Nm':0,'viscous_Nms':2e-5},z)
    near(q['final_rpm'],math.exp(-2e-5*120/I),1e-8)
    a=solve({'initial_rpm':1,'force_per_article_N':-4e-5},z);tc=I*w/(8e-6+f);neww=-(8e-6-f)*(120-tc)/I
    near(a['final_rpm'],neww*60/math.tau);near(a['turns'],(w*tc/2+neww*(120-tc)/2)/math.tau)
    for c in ('coast','driven','subthreshold'):
        par=json.loads((H/(c+'.json')).read_text()); trace=Path(td)/'trace.csv'
        with trace.open('w',newline='') as out:q=solve(par,K,csv.writer(out))
        with trace.open() as inp:load=sum(float(r['dt_s'])*float(r['Vload_mid_V'])**2/100 for r in csv.DictReader(inp))
        near(q['load_J'],load,1e-12,1e-25)
        fine=solve(dict(par,dt_s=0.005),K);near(q['load_J'],fine['load_J'],1e-4,1e-22);near(q['turns'],fine['turns'],1e-6)
        near(q['energy_residual_J'],0,ab=1e-15);near(q['load_J']*DEFAULT['winding_ohm']/100,q['winding_heat_J'],1e-12,1e-24)
        if c=='subthreshold': assert q['turns']==q['load_J']==q['stipulated_drive_J']==0
        else: assert q['load_J']>0
        print(c,'load (J), dt and dt/4:',q['load_J'],fine['load_J'],'turns:',q['turns'])
print('Analytic dry-stop (+/-), viscous decay, driven reversal, trace power, static threshold, time refinement and kinetic-energy ledger passed.')
