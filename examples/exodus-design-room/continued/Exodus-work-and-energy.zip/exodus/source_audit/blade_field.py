"""2-D textbook null, not a prediction of propulsion. Run: python3 blade_field.py"""
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu
import argparse,json
EPS=8.8541878128e-12
INCH=.0254
# Coordinates in inches only for constructing masks. Gradients and integrals are SI.
def solve(h,wall,shift):
    n=int(round(2*wall/h)); x=(np.arange(n+1)-n/2)*h; X,Y=np.meshgrid(x,x); Y=Y-shift; tol=h*1e-5
    def rect(x0,x1,y0,y1): return (X>=x0-tol)&(X<=x1+tol)&(Y>=y0-tol)&(Y<=y1+tol)
    base=rect(-1.25,1.25,-.30,-.25); low=base.copy()
    for j in range(-4,5):low |=rect(.30*j-.025,.30*j+.025,-.25,0)
    high=rect(-1.25,1.25,.25,.30); outer=np.zeros_like(low);outer[[0,-1],:]=True;outer[:,[0,-1]]=True
    metal=low|high;free=~(metal|outer); ids=np.full(X.shape,-1); ids[free]=np.arange(free.sum()); yy,xx=np.where(free); ii=ids[free];rows=[ii];cols=[ii];vals=[np.full(len(ii),4.)]; rhs=np.zeros((len(ii),2)); # columns: unit on low, unit common
    for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
        ny,nx=yy+dy,xx+dx;m=free[ny,nx];rows.append(ii[m]);cols.append(ids[ny[m],nx[m]]);vals.append(np.full(m.sum(),-1.));rhs[:,0]+=low[ny,nx];rhs[:,1]+=metal[ny,nx]
    A=coo_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(len(ii),len(ii))).tocsc();v=splu(A).solve(rhs);f=np.zeros((*X.shape,2));f[:,:,0]=low;f[:,:,1]=metal;f[free]=v
    # Charge per axial metre by finite-volume flux over all metal/free faces.
    def charge(mask):
        y,x=np.where(mask);q=np.zeros(2)
        for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
            ny,nx=y+dy,x+dx;m=free[ny,nx];q+=(f[y[m],x[m]]-f[ny[m],nx[m]]).sum(axis=0)
        return EPS*q
    q1=charge(low);q2=charge(high);s=-(q1+q2)[0]/(q1+q2)[1];V=f[:,:,0]+s*f[:,:,1];qlo=q1[0]+s*q1[1];qhi=q2[0]+s*q2[1];dy,dx=np.gradient(-V,h*INCH);txy=EPS*dx*dy;tyy=EPS*(dy**2-dx**2)/2
    def contour(xwall,ymin,ymax):
        idx=lambda a:int(np.argmin(abs(x-a)));l,r,b,t=map(idx,(-xwall,xwall,ymin+shift,ymax+shift));step=h*INCH
        # y traction over a CLOSED rectangular vacuum contour, CCW normals outward
        return float((np.trapz(txy[b:t+1,r]-txy[b:t+1,l])+np.trapz(tyy[t,l:r+1]-tyy[b,l:r+1]))*step)
    a=contour(1.45,-.50,.125); b=contour(1.45,.125,.50); pair=contour(1.45,-.50,.50); farther=contour(1.60,-.65,.65)
    assert abs((a+b)-pair)<1e-10*max(abs(a),abs(b)) and abs(qlo+qhi)<1e-10*abs(qlo)
    return dict(grid_in=h,wall_halfwidth_in=wall,offset_y_in=shift,Cdiff_F_per_m=float(qlo),net_charge_C_per_m=float(qlo+qhi),low_Fy_N_per_m=a,high_Fy_N_per_m=b,pair_Fy_N_per_m=pair,outer_contour_Fy_N_per_m=farther,net_over_internal=pair/abs(a))
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--case',nargs=3,type=float,metavar=('GRID_IN','BOX_HALF_IN','Y_OFFSET_IN'));args=parser.parse_args();cases=[args.case] if args.case else [(0.025,2.,0.),(0.0125,2.,0.),(.025,3.,0.),(.025,3.,1.5),(.025,4.,0.)]
    for h,w,s in cases:
        if not 0<h<=.025 or w<=1.7 or abs(s)+.7>=w:parser.error('require grid <= .025 in and vacuum clearance outside contours')
        print(json.dumps(solve(h,w,s)),flush=True)
