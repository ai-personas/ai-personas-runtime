"""Two conditional laws matching the same static net tangential force at theta=0. Not Exodus data."""
import argparse, math

def work(force_N, radius_m, n=3600):
    dtheta=2*math.pi/n
    # One equivalent tangential application point, lab-fixed external stator.
    torques=((force_N*radius_m*math.cos((i+0.5)*dtheta), force_N*radius_m) for i in range(n))
    return tuple(math.fsum(row)*dtheta for row in zip(*torques))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--force-uN',type=float,default=1,help='stipulated total tangential force at theta=0')
    p.add_argument('--radius-mm',type=float,default=10,help='example moment arm, not a patent dimension')
    q=p.parse_args(); f=q.force_uN*1e-6;r=q.radius_mm*1e-3
    if not(math.isfinite(f) and math.isfinite(r) and r>0): p.error('finite force and positive finite radius required')
    w0,w1=work(f,r); scale=2*math.pi*abs(f*r)
    assert abs(w0)<=1e-12*scale and math.isclose(w1,2*math.pi*f*r,rel_tol=1e-12)
    print(f'Stipulated torque at zero angle in BOTH laws: {f*r:.9g} N m')
    print(f'Work over 2pi (J), fixed lab direction: {w0:.9g}; constant follower torque: {w1:.9g}')
    print('The second integral is a required energy transfer, not a prediction that a source exists. Neither is measured.')
if __name__=='__main__': main()
