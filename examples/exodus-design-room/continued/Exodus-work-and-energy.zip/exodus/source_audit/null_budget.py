"""Equivalent single parasitic capacitance gradients, not a fit to Exodus data. SI internally."""
from math import isclose

def gradient(force,volts): return 2*force/volts**2
if __name__=='__main__':
    print('mean_uN  dCdx_fF_per_mm  F_example_5V_pN')
    for u in [237,421]:
        g=gradient(u*1e-6,25000)
        assert isclose(.5*25000**2*g,u*1e-6)
        print(f'{u:7d}  {g*1e12:13.4f}  {.5*5**2*g*1e12:16.2f}')
