import csv,json,math,tempfile,subprocess,sys
from pathlib import Path
from audit import reduce_cycle,FIELDS,product
from fixture import rows
root=Path(__file__).resolve().parent
fixture=json.loads((root/'example.json').read_text()); tests=[]
def eq(x,y): assert math.isclose(x,y,rel_tol=1e-12,abs_tol=1e-12),(x,y)
with tempfile.TemporaryDirectory() as tmp:
    tr=Path(tmp)/'r.csv'; mf=Path(tmp)/'m.json'
    def run(rr=rows,**opts):
        m=json.loads(json.dumps(fixture)); m['bounds'].update(opts.pop('bounds',{}));m.update(opts);mf.write_text(json.dumps(m))
        with tr.open('w',newline='') as f:
            w=csv.writer(f);w.writerow(FIELDS);w.writerows(rr)
        return reduce_cycle(tr,mf)
    def refuse(label,*a,**kw):
        try:run(*a,**kw)
        except ValueError:tests.append(label)
        else:raise AssertionError(label)
    r=run(); e=r['whole_cycle_J']; eq(e['load_lower_J'],.1);eq(e['source_positive_upper_J'],.13);eq(e['shaft_positive_upper_J'],math.pi*.05); eq(r['residual_lower_J'],.1-.13-math.pi*.05);eq(r['net_turns'],1);tests.append('analytic energy and turns')
    eq(r['per_phase_J']['isolated']['source_positive_nom_J'],0);eq(r['per_phase_J']['isolated']['load_nom_J'],.1);tests.append('disconnect-only output does not survive whole-cycle accounting')
    e=run(bounds={'u_load_V':.1,'u_R_ohm':1.,'u_dt_s':.01,'load_integration_W':.001,'depletion_max_J':.2}); eq(e['whole_cycle_J']['load_lower_J'],.99*(.81/11-.001)); assert e['residual_lower_J']<r['residual_lower_J'];tests.append('adverse bound direction')
    eq(run(bounds={'u_load_V':1.1})['whole_cycle_J']['load_lower_J'],0); assert product(-2,0,-3,0)==(6,6) and product(2,0,-3,0)==(0,0);tests.append('offset-dominated and signed inputs')
    # Invented anomalous output to test routing only.
    boosted=[tuple(list(z[:-1])+[4]) if z[0]=='isolated' else z for z in rows]; assert run(boosted)['residual_lower_J']>0 and run(boosted,closure='unresolved')['screen']=='unresolved endpoint state';tests.append('positive residual cannot override unresolved closure')
    refuse('missing reset',rows[:-2]);refuse('single-row reset',rows[:-1]);refuse('missing charge',rows[:2]+rows[4:]);refuse('long sample gap',bounds={'max_gap_s':.5});refuse('unresolved duration',bounds={'u_dt_s':1});refuse('impossible R bound',bounds={'u_R_ohm':10});refuse('missing bound basis',basis={});refuse('nonfinite',bounds={'u_load_V':'nan'});refuse('unobserved switch gap',[z if k!=2 else (z[0],1.1,*z[2:]) for k,z in enumerate(rows)])
print('\n'.join('PASS '+x for x in tests))
