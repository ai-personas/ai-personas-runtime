"""Generate a SYNTHETIC recorder-format example, not a device simulation."""
import csv,json,math
from pathlib import Path
from audit import FIELDS,KEYS
root=Path(__file__).resolve().parent
p=math.pi
# Each second is a separate interval; successive rows at a switch give its two sides.
rows=[('prepare',0,0,0,.1,0,0,0),('prepare',1,p/2,p,.1,0,0,0),('charge',1,p/2,p,0,5,.02,0),('charge',2,1.5*p,p,0,5,.02,0),('isolated',2,1.5*p,p,0,0,0,-1),('isolated',3,2*p,0,0,0,0,-1),('reset',3,2*p,0,0,3,.01,0),('reset',4,2*p,0,0,3,.01,0)]
if __name__=='__main__':
    with (root/'example.csv').open('w',newline='') as f:
        wr=csv.writer(f);wr.writerow(FIELDS);wr.writerows(rows)
    b=dict.fromkeys(KEYS,0.); b.update(R_ohm=10.,max_gap_s=1.)
    m=dict(record_kind='synthetic',closure='documented',state_evidence='Stipulated synthetic one-turn fixture only: start and end at rest, discharged, same orientation and environment.',bounds=b,basis={k:'Exact stipulated test-fixture value; not a calibration or a bound for apparatus.' for k in KEYS})
    (root/'example.json').write_text(json.dumps(m,indent=2)+'\n')
