"""Bound the energy surplus of one full loaded rotor cycle. Python 3 stdlib, SI.
Accepts synchronized calibrated records, not predictions of anomalous thrust.
"""
import argparse,csv,json,math
from pathlib import Path

FIELDS='phase t_s theta_rad omega_rad_s drive_Nm src_V src_A load_V'.split()
PHASES='prepare charge isolated reset'.split()
KEYS='R_ohm u_R_ohm u_load_V u_src_V u_src_A u_drive_Nm u_omega_rad_s u_dt_s max_gap_s load_integration_W charge_integration_W drive_integration_W other_input_max_J depletion_max_J transition_input_max_J'.split()

def num(x):
    y=float(x)
    if not math.isfinite(y): raise ValueError('nonfinite number')
    return y

def product(a,u,b,v):
    corners=[(a+i*u)*(b+j*v) for i in [-1,1] for j in [-1,1]]
    return max(0.,min(corners)), max(0.,max(corners)) # positive inward power only

def reduce_cycle(path, manifest):
    m=json.loads(Path(manifest).read_text()); c=m['bounds']; notes=m['basis']; kind=m['record_kind']
    if kind not in ('synthetic','recorded'): raise ValueError('record_kind must be synthetic or recorded')
    if set(c)!=set(KEYS) or set(notes)!=set(KEYS): raise ValueError('supply value and basis for every bound: '+','.join(KEYS))
    if any(not isinstance(notes[k],str) or not notes[k].strip() for k in KEYS): raise ValueError('missing bound basis')
    c={k:num(c[k]) for k in KEYS}
    if min(c.values())<0 or c['R_ohm']<=c['u_R_ohm'] or c['max_gap_s']<=0: raise ValueError('invalid bound')
    if not isinstance(m['state_evidence'],str) or not m['state_evidence'].strip(): raise ValueError('endpoint record required')
    if m['closure'] not in ('unresolved','documented'): raise ValueError('closure must be unresolved or documented')
    R,uR=c['R_ohm'],c['u_R_ohm']; phase=-1; prev=None; start=end=None
    totals=[0.]*6; by={}; counts={}; first_theta=None
    with open(path,newline='') as f:
        rows=csv.DictReader(f)
        if rows.fieldnames!=FIELDS: raise ValueError('expected '+','.join(FIELDS))
        for row in rows:
            if None in row or None in row.values(): raise ValueError('malformed row')
            tag=row['phase']; idx=PHASES.index(tag); t,theta,w,tau,v,i,l=map(num,[row[k] for k in FIELDS[1:]])
            if start is None: start=[t,theta,w]
            end=[t,theta,w]; uv=c['u_load_V']; ec=product(v,c['u_src_V'],i,c['u_src_A']); ed=product(tau,c['u_drive_Nm'],w,c['u_omega_rad_s'])
            # Lower bound on resistor power remains zero for offset-dominated readings.
            powers=[l*l/R,max(0.,abs(l)-uv)**2/(R+uR),max(0.,v*i),ec[1],max(0.,tau*w),ed[1]]
            if idx!=phase:
                if idx!=phase+1 or (prev is not None and (counts[PHASES[phase]]<1 or t!=prev[0])): raise ValueError('missing/out-of-order phase, empty interval, or boundary gap')
                counts[tag]=0; by[tag]=[0.]*6; phase=idx; first_theta=theta
            else:
                dt=t-prev[0]; ud=c['u_dt_s']
                if not ud<dt<=c['max_gap_s']: raise ValueError('unresolved duration or sample gap')
                a=[(x+y)/2 for x,y in zip(prev[1],powers)]
                inc=[dt*a[0],(dt-ud)*max(0.,a[1]-c['load_integration_W']),dt*a[2],(dt+ud)*(a[3]+c['charge_integration_W']),dt*a[4],(dt+ud)*(a[5]+c['drive_integration_W'])]
                by[tag]=[x+y for x,y in zip(by[tag],inc)]; totals=[x+y for x,y in zip(totals,inc)]; counts[tag]+=1
            prev=(t,powers)
    if phase!=3 or counts['reset']<1: raise ValueError('need all phases through reset')
    lab=['load_nom_J','load_lower_J','source_positive_nom_J','source_positive_upper_J','shaft_positive_nom_J','shaft_positive_upper_J']
    allowances=sum(c[k] for k in ['other_input_max_J','depletion_max_J','transition_input_max_J']); budget=totals[3]+totals[5]+allowances; residual=totals[1]-budget
    if not all(math.isfinite(x) for x in totals+[budget,residual]): raise ValueError('numeric overflow')
    return {'record_kind':kind,'closure_as_declared':m['closure'],'per_phase_J':{k:dict(zip(lab,v)) for k,v in by.items()},'whole_cycle_J':dict(zip(lab,totals)),'additional_debits_J':{k:c[k] for k in ['other_input_max_J','depletion_max_J','transition_input_max_J']},'start_end_t_angle_speed':[start,end],'net_turns':(end[1]-start[1])/math.tau,'residual_lower_J':residual,'screen':('unresolved endpoint state' if m['closure']!='documented' else 'inspect boundary and replicate independently' if residual>0 else 'no positive lower bound'),'notice':'User bounds and state evidence are not validated by arithmetic. Not a measured COP determination.'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('trace');p.add_argument('manifest');a=p.parse_args()
    try: print(json.dumps(reduce_cycle(a.trace,a.manifest),indent=2,allow_nan=False))
    except (OSError,TypeError,ValueError,KeyError,OverflowError) as e:p.exit(2,'audit refused: '+str(e)+'\n')
