"""Constant-speed, periodic response of the two-magnet Exodus test rotor. SI units."""
import argparse, csv, json, math
from pathlib import Path
import numpy as np
from scipy.special import ellipk
PI=np.pi

def linkage(n=512,br=1.0,zshift=0.0,q=6):
    # Uniform magnetization M=Br/mu0 along z: equivalent azimuthal sheet K=M.
    # Mutual inductance of offset circular filaments integrated over magnet height,
    # winding height, layers. Global azimuth integrated analytically (ellipk takes m=k^2).
    # At angle zero the positive magnet is directly over the pickup. Opposite one is shifted pi.
    theta=np.arange(n//2+1)*2*PI/n
    d=(.120*np.sin(theta/2))[:,None,None,None]
    g,w=np.polynomial.legendre.leggauss(q)
    h=(.0481+zshift+.003*g[None,:])-(.030+.005*g[:,None]); h=h[None,:,:,None]
    weights=w[None,:,None,None]*w[None,None,:,None]/4
    count=8*q; ca=np.cos((np.arange(count)+.5)*2*PI/count)[None,None,None,:]
    b=.003
    single=np.zeros(len(theta))
    for a in .006+.0002*(.5+np.arange(6)):
        rho=np.sqrt(a*a+b*b-2*a*b*ca)
        den=(d+rho)**2+h*h
        azmean=(2/PI)*ellipk(4*d*rho/den)/np.sqrt(den)
        single+=50*br*.006*PI*a*b*np.sum(weights*np.mean(ca*azmean,axis=3,keepdims=True),axis=(1,2,3))
    one=np.r_[single,single[-2:0:-1]]
    return one-np.roll(one,n//2)

def gradient_factor(lam):
    # e=-dLambda/dt=omega*k(theta); drop unresolvable Nyquist derivative.
    m=np.fft.fftfreq(len(lam),1/len(lam)); m[len(m)//2]=0
    return np.fft.ifft(-1j*m*np.fft.fft(lam)).real

def circuit(k,rpm,rw,rl,L):
    om=rpm*2*PI/60; m=np.fft.fftfreq(len(k),1/len(k)); e=k*om
    i=np.fft.ifft(np.fft.fft(e)/(rw+rl+1j*m*om*L)).real
    # k is EMF per positive speed. Work demanded from shaft by pickup = k*i*dtheta.
    v=i*rl; demand=k*i
    def rms(x):return np.sqrt(np.mean(x*x))
    p=rl*np.mean(i*i); heat=rw*np.mean(i*i); shaft=om*np.mean(demand)
    if not np.isclose(p+heat,shaft,rtol=1e-10,atol=1e-24):raise ArithmeticError('periodic energy mismatch')
    out=dict(rpm=rpm,omega_rad_s=om,Voc_peak_V=max(abs(e)),Vload_peak_V=max(abs(v)),Vload_rms_V=rms(v),Pload_W=p,Pwinding_W=heat,shaft_power_W=shaft,mean_pickup_demand_Nm=np.mean(demand),peak_abs_pickup_demand_Nm=max(abs(demand)),Eload_per_turn_J=(p*60/abs(rpm) if rpm else None))
    return out,e,v,i,demand

def read_k(path):
    a=np.genfromtxt(path,delimiter=',',names=True,ndmin=1)
    t=a['theta_rad']; k=a['k_Vs_per_rad']; n=len(k)
    if n<32 or n%2 or not np.all(np.isfinite(k)) or not np.allclose(t,2*PI*np.arange(n)/n,rtol=0,atol=1e-7):raise ValueError('expected even, uniform, finite full-turn bins starting at zero, omit duplicate endpoint')
    if abs(k.mean())>max(1e-18,0.001*np.sqrt(np.mean(k*k))):raise ValueError('nonclosing integral of emf per speed: check baseline, angles, coverage')
    return k-k.mean()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--rpm',type=float,nargs='+',default=[0,1,3,10]);p.add_argument('--br-T',type=float,default=1.,help='assumed uniform remanence T, equal magnitudes, opposed polarities');p.add_argument('--shift-mm',type=float,default=0,help='add to both magnet heights');p.add_argument('--winding-ohm',type=float,default=None);p.add_argument('--load-ohm',type=float,default=100.);p.add_argument('--L-mH',type=float,default=1.,help='constant self-inductance; illustrative until measured');p.add_argument('--bins',type=int,default=512);p.add_argument('--quad',type=int,default=6);p.add_argument('--cal',help='calibrated open-circuit EMF/speed CSV instead of field model');p.add_argument('--out',type=Path,default=Path('prediction'))
    a=p.parse_args();rw=a.winding_ohm if a.winding_ohm is not None else 1.724e-8*300*2*PI*.0066/(PI*.00009**2);rl=a.load_ohm;L=a.L_mH*.001
    if not all(map(math.isfinite,[rw,rl,L,a.br_T,a.shift_mm,*a.rpm])) or min(rw,rl)<=0 or L<0 or a.br_T<0 or a.shift_mm<=-10.1 or a.bins<32 or a.bins%2 or a.quad<2:p.error('check finite SI parameters, separated magnet/coil, positive R and even grid')
    if a.cal:k=read_k(a.cal);lam=None
    else:lam=linkage(a.bins,a.br_T,a.shift_mm/1000,a.quad);k=gradient_factor(lam)
    n=len(k);t=np.arange(n)*2*PI/n;a.out.mkdir(exist_ok=True,parents=True)
    np.savetxt(a.out/'k.csv',np.c_[t,k],delimiter=',',header='theta_rad,k_Vs_per_rad',comments='')
    if lam is not None:np.savetxt(a.out/'linkage.csv',np.c_[t,lam],delimiter=',',header='theta_rad,flux_linkage_Wb_turn',comments='')
    rows=[]
    for j,rpm in enumerate(a.rpm):
        out,e,v,i,demand=circuit(k,rpm,rw,rl,L);rows.append(out);np.savetxt(a.out/f'wave_{j}.csv',np.c_[t,e,v,i,-demand],delimiter=',',header='theta_rad,Voc_V,Vload_V,I_A,reaction_on_rotor_Nm',comments='')
    info=dict(type='conditional constant-speed prediction; not measured power or COP',source_k=a.cal or 'uniformly magnetized cylinder + air winding model',winding_ohm=rw,load_ohm=rl,L_H=L,assumed_br_T=(None if a.cal else a.br_T),magnet_height_shift_mm=(None if a.cal else a.shift_mm),rows=rows)
    (a.out/'summary.json').write_text(json.dumps(info,indent=2,allow_nan=False)+'\n');print(json.dumps(info,indent=2))
if __name__=='__main__':main()
