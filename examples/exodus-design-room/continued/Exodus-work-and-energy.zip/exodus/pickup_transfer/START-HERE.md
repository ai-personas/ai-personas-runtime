# What this pickup can measure

**Result:** With the rotor *externally driven* at 1 rpm, the nominal geometry, assumed 1 T remanence and a 100 Ω load give **24.2 µV RMS** at the load (75.1 µV peak). That is **5.86 pW**, or **0.352 nJ per revolution**. This is a speed-to-voltage prediction, not evidence of rotation or a measured COP. The apparatus is the two-magnet rotor and stationary air-core coil in the companion coupled-rotor CAD; this supplement contains the editable calculation, not a second rotor design.

## Reproduce or change the prediction

Python 3, NumPy and SciPy. From this directory run `python3 verify.py` to exercise the independent field integral, angular refinement, reversal, winding-height sensitivity and synthetic calibration checks. The nominal model CLI and calibration CLI are reproduced below. Example files in `example/` are simulated, not measurements. Coordinates are metres in the magnetic integrals; signed angular speed is rad/s internally (rpm × 2π/60). The two opposite axial magnet polarities matter: do not sum two identical unsigned pulses. Magnetic remanence, placement, air winding distribution, copper resistance, load and lumped inductance are model parameters, not metrology.

## Where the energy goes

The two magnets change the signed flux linkage λ of a stationary winding. Define k(θ)=−dλ/dθ; the generated EMF is e=kω. In periodic steady motion with a resistive load and a series winding, L di/dt+(Rw+RL)i=e; VL=i RL. The compensating shaft torque is k i, and the reaction on the rotor is −k i. Average e i = average i²(Rw+RL) over a whole period; the inductor's net energy change is zero **over that period**, not at every sample. Bearings, aerodynamic loss and drive inefficiency are additional. This model prescribes speed; it never computes a self-start or attributes shaft work to the test articles.

At 1 rpm the mean compensating pickup torque is 6.07×10⁻¹¹ N m; even its peak magnitude is only 5.83×10⁻¹⁰ N m. For scale, *if* two 2 µN tangential forces acted at 50 mm, their total torque would be 2.0×10⁻⁷ N m. The mean pickup load here would be about 0.030% of that assumed torque. This comparison neither asserts those forces nor accounts for stiction. A 100 Ω resistor delivering little power at that speed would thus be a poor proxy for the total possible work. At standstill e=0 regardless of a static torque. Consult the separate bidirectional breakaway analysis before interpreting no motion. A forced spin, even with no propulsion whatsoever, generates these pulses.

## Discriminating a signal at the terminals

At one revolution per minute, one mechanical cycle is 60 s; do not use an AC meter with unspecified sub-hertz response, or treat peak as RMS. Record signed differential voltage with DC response and a calibrated transfer function, synchronized to shaft angle, at sufficient bandwidth and sample density to resolve the pulses. High input impedance should be specified relative to RL; include probe resistance in parallel and account for input capacitance at relevant harmonics. Record actual winding R versus temperature and effective RL. Retain raw voltages. Reversing speed reverses open-circuit e at a fixed angle. A phase-locked waveform on externally driven, *uncharged* runs validates the pickup chain, not a force. Include equal-duration stationary baselines, zero-input recordings, drive-off, dummy and charged/reversed controls; check drift, thermoelectric offsets, EMI from the drive, digitizer range, bandwidth and clock alignment. A disconnected lead is not a matched source-impedance blank.

As a **resolution target**, a bound of 2.4 µV RMS on total additive voltage error over the same window is ~10% of the nominal 1-rpm signal. This is **not** a claim the instrument has that error. For a recorded voltage RMS A and an independently justified RMS error bound δ, true voltage RMS lies between max(0,A−δ) and A+δ by the triangle inequality. Bound resistive output energy over duration T using T max(0,A−δ)²/Rmax to T(A+δ)²/Rmin, with synchronized sampling/quadrature/timebase errors bounded separately. At small signals, squaring noise yields apparent positive power even on a stationary rig. Zero-mean noise cannot just be assumed to disappear on squaring. This is a terminal-output bound only; use the separate full-cycle audit for all input ports, stored energy, endpoint restoration and uncertainties.

## Replace the geometric coupling with a trace

For **existing** open-circuit calibration recordings, supply CSV columns `time_s,theta_rad_unwrapped,Voc_V`. Give the phase datum, signed winding terminals, timestamps and calibrated gains/offsets. One monotone direction per file; use more than three turns, aligned fiducial, enough samples that no angle gap exceeds one requested bin. Recover per-bin k from ∫Voc dt divided by signed angle increment. The reducer checks closure before removing the small residual mean; inspect closure and bin scatter, not only its exit code. Compare independent positive and negative runs at the same phase, as well as held-out speeds and loads. Do not supply loaded terminal voltage as open-circuit EMF. A constant offset at variable speed, velocity-dependent parasitics or an over-broad closure tolerance can bias k. A high-impedance probe is only effectively open after checking loading. Replace Rw, L and RL with characterized values for the same apparatus. A model calibrated to one run needs held-out tests; calibrating the pickup never establishes the source of shaft work.

## Numerical checks and limitations

The alternative direct area integral of Biot–Savart Bz over turns agrees with the nominal flux linkage to better than 5×10⁻¹⁰ of peak at the five checked angles. Angular/quadrature refinement changes k by less than 4×10⁻⁹ of peak. The signed synthetic calibration agrees with a prescribed sinusoid within 0.011% of peak in either direction. These are numerical checks under idealized assumptions, **not** physical accuracy estimates. Shifting magnet height by −1, 0, +1 mm gives respectively 29.20, 24.22, 20.25 µV RMS at 1 rpm. Nearby magnetic hardware, actual pole strength, runout and winding position can dominate solver differences. No measured drive, voltage, motion or net gain is supplied. No ordering, fabrication or powered testing is authorized.

## Command interfaces

```text
usage: model.py [-h] [--rpm RPM [RPM ...]] [--br-T BR_T] [--shift-mm SHIFT_MM]
                [--winding-ohm WINDING_OHM] [--load-ohm LOAD_OHM]
                [--L-mH L_MH] [--bins BINS] [--quad QUAD] [--cal CAL]
                [--out OUT]

Constant-speed, periodic response of the two-magnet Exodus test rotor. SI
units.

options:
  -h, --help            show this help message and exit
  --rpm RPM [RPM ...]
  --br-T BR_T           assumed uniform remanence T, equal magnitudes, opposed
                        polarities
  --shift-mm SHIFT_MM   add to both magnet heights
  --winding-ohm WINDING_OHM
  --load-ohm LOAD_OHM
  --L-mH L_MH           constant self-inductance; illustrative until measured
  --bins BINS
  --quad QUAD
  --cal CAL             calibrated open-circuit EMF/speed CSV instead of field
                        model
  --out OUT

usage: calibrate.py [-h] [--bins BINS] [--closure-frac CLOSURE_FRAC] trace out

Reduce a disconnected, externally driven, OPEN-circuit calibration trace. Not
a test for excess energy.

positional arguments:
  trace
  out

options:
  -h, --help            show this help message and exit
  --bins BINS
  --closure-frac CLOSURE_FRAC
```
