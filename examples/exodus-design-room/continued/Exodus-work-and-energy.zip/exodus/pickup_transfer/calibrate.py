"""Reduce a disconnected, externally driven, OPEN-circuit calibration trace. Not a test for excess energy."""
import argparse, json
import numpy as np

def reduce(t,theta,e,n=128,closure_frac=.01):
    if n<32 or n%2 or not 0<closure_frac<1:raise ValueError('even bin count >=32; relative closure tolerance between 0 and 1')
    if min(len(t),len(theta),len(e))<4 or not np.isfinite(np.r_[t,theta,e]).all() or np.any(np.diff(t)<=0):raise ValueError('need finite time-increasing data')
    s=np.sign(theta[-1]-theta[0]); dt=np.diff(t); d=s*np.diff(theta)
    if not np.all(d>0):raise ValueError('one direction per run; supply unwrapped angle, no duplicate encoder samples')
    tau=2*np.pi; h=tau/n
    if np.max(d)>h*(1+1e-9):raise ValueError('trace contains angle gap larger than a requested bin')
    # Flux in time order retains sign for a reversed traversal. Difference F along
    # increasing angle then gives e/omega regardless of traversal direction.
    F=np.r_[0,np.cumsum(.5*(e[:-1]+e[1:])*dt)]
    x=theta if s>0 else theta[::-1]; f=F if s>0 else F[::-1]
    lo=int(np.ceil((x[0]+h/2)/tau)); hi=int(np.floor((x[-1]+h/2)/tau)); N=hi-lo
    if N<2:raise ValueError('need >=2 complete aligned cycles; record >3 turns with phase fiducial')
    edges=tau*lo-h/2+h*np.arange(n*N+1); cycles=np.diff(np.interp(edges,x,f)).reshape(N,n)/h
    means=np.mean(cycles,axis=1); rms=np.sqrt(np.mean(cycles**2,axis=1)); frac=np.abs(means)/np.maximum(rms,1e-30)
    if np.any(rms==0) or np.max(frac)>closure_frac:raise ValueError('cycle EMF closure or nonzero-signal check failed: '+str(frac))
    k=cycles.mean(axis=0); k-=k.mean()
    return h*np.arange(n),k,dict(turns=N,direction=int(s),max_gap_rad=float(max(d)),per_cycle_mean_k=means.tolist(),closure_fracs=frac.tolist(),max_bin_sd_k=float(np.std(cycles,axis=0,ddof=1).max()),closure_limit=closure_frac)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('trace');p.add_argument('out');p.add_argument('--bins',type=int,default=128);p.add_argument('--closure-frac',type=float,default=.01);a=p.parse_args();z=np.genfromtxt(a.trace,names=True,delimiter=',',ndmin=1);t,k,report=reduce(z['time_s'],z['theta_rad_unwrapped'],z['Voc_V'],a.bins,a.closure_frac);np.savetxt(a.out,np.c_[t,k],delimiter=',',comments='',header='theta_rad,k_Vs_per_rad');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
