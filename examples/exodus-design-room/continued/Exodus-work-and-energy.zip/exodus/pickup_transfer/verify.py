"""No physical data. Check the nominal magnet calculation by integrating Bz over the receiving turns."""
import numpy as np, json
import model,calibrate
from numpy.polynomial.legendre import leggauss
pi=np.pi

def flux(d,q=10):
    # Biot-Savart, current sheet K=Br/mu0. bz(dA) = Br/(4pi) dz dphi_m * b*(b-x*cos(phi_m)-y*sin(phi_m))/distance^3 * dA.
    g,w=leggauss(q);az=2*pi*np.arange(8*q)/(8*q); ca=np.cos(az);sa=np.sin(az); b=.003; total=0
    for a in .006+.0002*(.5+np.arange(6)):
        r=(g+1)[:,None]*a/2; x=(r*ca-d)[:,:,None]; y=(r*sa)[:,:,None]; r2=(x-b*ca)**2+(y-b*sa)**2; num=b*(b-x*ca-y*sa)
        for i in range(q):
            for j in range(q):
                z=(.030+.005*g[i])-(.0481+.003*g[j]); av=(num/(r2+z*z)**1.5).mean(axis=(1,2)); total+=50*.006*(w[i]*w[j]/4)*pi*np.sum(av*r[:,0]*a/2*w)
    return total

lam=model.linkage(); k=model.gradient_factor(lam); kfine=model.gradient_factor(model.linkage(1024,q=9))[::2]; n=len(lam); errors={}
for idx in [0,8,16,32,64]:
    theta=idx*2*pi/n; direct=flux(.12*abs(np.sin(theta/2)))-flux(.12*abs(np.cos(theta/2))); errors[str(idx)]=abs(direct-lam[idx])/max(abs(lam));assert errors[str(idx)]<1e-5,(idx,direct,lam[idx])
refine=max(abs(k-kfine))/max(abs(k));assert refine<1e-4 and max(abs(k+np.roll(k,n//2)))<1e-12
Rw=8.4284444444; pos,neg=[model.circuit(k,s,Rw,100.,.001)[0] for s in (1.,-1.)];assert abs(pos['Pload_W']/neg['Pload_W']-1)<1e-10 and pos['mean_pickup_demand_Nm']>0>neg['mean_pickup_demand_Nm'];assert model.circuit(k,0,Rw,100.,.001)[0]['shaft_power_W']==0
sensitivity={str(shift):model.circuit(model.gradient_factor(model.linkage(zshift=shift*.001)),1,Rw,100.,.001)[0]['Vload_rms_V'] for shift in [-1,0,1]}
# Analytic calibration trace: known k(phase) at nonuniform speed. Check both signed directions.
calerr={}
for sign in [1,-1]:
    t=np.arange(0,27,.001); angle=sign*(t+.1*np.sin(t)); omega=sign*(1+.1*np.cos(t)); e=.0003*np.sin(angle)*omega
    a,b,report=calibrate.reduce(t,angle,e); calerr[str(sign)]=max(abs(b/.0003-np.sin(a)));assert calerr[str(sign)]<.0002
    try:calibrate.reduce(t,angle,e+.0001)
    except ValueError as er:assert 'closure' in str(er)
    else:raise RuntimeError('failed to reject offset')
print(json.dumps(dict(type='numerical checks only; no measured data',area_integral_error_rel_peak=errors,refinement_k_error_rel_peak=refine,synthetic_cal_error_rel_peak=calerr,shift_mm_to_Vrms_at_1rpm=sensitivity),indent=2))
