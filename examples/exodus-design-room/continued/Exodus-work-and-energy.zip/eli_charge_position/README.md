# Charge, move, recover, return

**Question.** Suppose an isolated charged article pulls in the direction of a load. Does the stroke spend electric field energy, or deliver work that the measured terminal port cannot account for? This digital reference is a two-body actuator, not a claim that Exodus acts by this mechanism.

**Convention.** Relative displacement x increases from A to B. F is the force the actuator exerts along +x, q is free charge delivered at the positive reference terminal, and V is its potential relative to the return terminal. For a reversible quasistatic state with all other coordinates fixed, dU = V dq − F dx. Thus ∂F/∂q = −∂V/∂x wherever U is smooth. The reaction body must be specified: pulling a carriage relative to a fixed electrode does not accelerate the center of mass of their isolated combination.

**Cycle.** Charge 0→Q at A, move A→B at Q, recover Q→0 at B, return B→A uncharged. A lossless reversible converter would pay ∫ at A and receive the magnitude of ∫ at B; a resistor discharging at B dissipates that energy instead. For any conservative force and voltage pair, stroke work minus return cost equals ∮ V dq. During an isolated stroke the terminal current can vanish while energy in the field falls. In an actual implementation a pickup supplies only a fraction of the available mechanical work. Do not add pickup output and its driving shaft work as two outputs.

**Three predictions.** C(x)=A+(B−A)x/L (here A,B are endpoint capacitances). Start with U=q²/(2C), giving F=q²C′/(2C²) and V=q/C. The force-only case adds G(q/Q)² at every position with unchanged V. The paired case adds the same force but also the potential-energy term −Gx(q/Q)², hence the additional voltage −2Gxq/Q². The full-charge force changes between cases; the force traces for force-only and paired are identical. Only their electrical traces differ. A q-independent force cannot be identified by the charge contrast alone. Losses, leakage, incomplete isolation, other electrodes, field sources, dielectric relaxation and mechanical history can make the one-port two-coordinate model incomplete. These are alternatives to, not evidence of, an anomalous source.

| Synthetic ideal case | Mechanical out (nJ) | Charge input at A (nJ) | Recovery at B (nJ) | Residual (nJ) |
|---|---:|---:|---:|---:|
| variable capacitor | 0.25 | 0.50 | 0.25 | 0 |
| force only | 0.35 | 0.50 | 0.25 | +0.10 by construction |
| force + voltage counterpart | 0.35 | 0.50 | 0.15 | 0 |

In the paired example the full-charge terminal voltage at B is 3 V instead of 5 V. In its intended domain the modified stored energy remains positive. This illustrative effect magnitude is not fitted to any Exodus article. The extra force with omitted energy source is a diagnostic hypothesis, not a self-consistent generator. A residual that reverses with the loop can also arise from a second, unmetered reversible port.

**Run (Python 3, standard library, from this directory):**

```
python3 cycle.py generate nominal.json paired my-trace.csv
python3 cycle.py reduce examples/capacitor.csv
python3 check.py
```

Use `--reverse` or change the signed full charge in a copy of the config. `check.py` regenerates the three synthetic examples. For your own traces use CSV headings `x_m,q_C,F_N,V_V` in time order; program does not assume four straight edges, sort samples, impose closure, or credit endpoint energy. Integrates with adjacent-sample trapezoids. Its positive and returned amounts refer to terminal segments, not to wall input or useful load output. Nonzero endpoint deltas require an open-path analysis, not a cycle claim. Zero deltas do not prove other stores restored. The discretization error in the example is checked by refinement; no bounds on real measurement errors are provided by that check.

**Evidence needed.** Record plate geometry and grounding, charge/current and voltage including reference and probe burden, calibrated force/displacement and load output, isolation state and timing, converter input and return through reset. Meter each independent electrical port. Trapped charge in a nominally neutral dielectric is not necessarily terminal q: if inaccessible it requires an additional state or independent energy bound. Reverse the cycle and field polarity, compare uncharged runs, and vary reaction-body spacing with the same moving article. Test common translation of the whole assembly separately from motion relative to its fixed electrodes. Bound friction, polarization, all environmental inputs, endpoint stores and uncertainties before interpreting any electrical excess. Research and digital design only; no order, fabrication or powered test is authorized.

For a specific double-gap overlap actuator, CAD/CAM files and signed port interpretation, see [geometry/PORTS.md](geometry/PORTS.md). From this directory run `python3 geometry/build.py` and `python3 cycle.py generate geometry/geometry-cycle.json capacitor reference.csv`.
