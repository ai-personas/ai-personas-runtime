#!/usr/bin/env python3
"""Create ideal q-x cycles or integrate a SI trace. Standard library only."""
import argparse,csv,json,math
from pathlib import Path
FIELDS=('x_m','q_C','F_N','V_V')

def config(path):
    d=json.loads(Path(path).read_text()); need={'stroke_m','C_A_F','C_B_F','q_full_C','extra_F_N'}
    if set(d)!=need or not all(isinstance(v,(float,int)) and not isinstance(v,bool) and math.isfinite(v) for v in d.values()): raise ValueError('require five finite SI parameters: '+str(sorted(need)))
    L,ca,cb,Q,G=(d[k] for k in ('stroke_m','C_A_F','C_B_F','q_full_C','extra_F_N'))
    if min(L,ca,cb)<=0 or Q==0: raise ValueError('positive stroke and capacitances, nonzero full charge required')
    return L,ca,cb,Q,G

def simulate(params,case,n):
    if n<1: raise ValueError('steps per edge must be positive')
    L,ca,cb,Q,G=params
    if case=='paired' and (1/max(ca,cb)-max(0,2*G*L/Q**2))<=0: raise ValueError('parameters outside guaranteed positive-elastance domain')
    corners=[(0.,0.),(0.,Q),(L,Q),(L,0.),(0.,0.)]; pts=[corners[0]]
    for (a,b),(c,d) in zip(corners,corners[1:]):
        pts.extend((a+(c-a)*j/n,b+(d-b)*j/n) if j<n else (c,d) for j in range(1,n+1))
    for x,q in pts:
        C=ca+(cb-ca)*x/L
        F=q*q*(cb-ca)/(2*L*C*C); V=q/C
        if case!='capacitor': F+=G*(q/Q)**2
        if case=='paired': V-=2*G*x*q/Q**2
        yield (x,q,F,V)

def write(path,data):
    with open(path,'w',newline='') as f:
        w=csv.writer(f); w.writerow(FIELDS); w.writerows(data)

def read(path):
    with open(path,newline='') as f:
        r=csv.DictReader(f)
        if not r.fieldnames or len(set(r.fieldnames))!=len(r.fieldnames) or not all(k in r.fieldnames for k in FIELDS): raise ValueError('missing or duplicate CSV headings; need '+str(FIELDS))
        return [tuple(float(row[k]) for k in FIELDS) for row in r]

def reduce(rows):
    if len(rows)<2 or not all(math.isfinite(v) for row in rows for v in row): raise ValueError('need at least two finite samples')
    mech=[]; port=[]
    for (x,q,F,V),(y,r,H,Z) in zip(rows,rows[1:]):
        mech.append((y-x)*(F+H)/2); port.append((r-q)*(V+Z)/2)
    wm=math.fsum(mech); we=math.fsum(port)
    return dict(n=len(rows),dx_endpoint_m=rows[-1][0]-rows[0][0],dq_endpoint_C=rows[-1][1]-rows[0][1],mechanical_out_J=wm,terminal_in_J=we,terminal_positive_J=math.fsum(v for v in port if v>0),terminal_return_magnitude_J=-math.fsum(v for v in port if v<0),work_minus_terminal_J=wm-we)

def main():
    p=argparse.ArgumentParser(description=__doc__); s=p.add_subparsers(dest='cmd',required=True); g=s.add_parser('generate'); g.add_argument('config'); g.add_argument('case',choices=('capacitor','force_only','paired')); g.add_argument('csv'); g.add_argument('--steps',type=int,default=256); g.add_argument('--reverse',action='store_true'); h=s.add_parser('reduce'); h.add_argument('csv'); a=p.parse_args()
    if a.cmd=='generate':
        rows=list(simulate(config(a.config),a.case,a.steps)); write(a.csv,rows[::-1] if a.reverse else rows)
    print(json.dumps(reduce(read(a.csv)),indent=2,allow_nan=False))
if __name__=='__main__': main()
