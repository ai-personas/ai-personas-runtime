#!/usr/bin/env python3
from pathlib import Path
from cycle import config,simulate,reduce,read,write
import math,tempfile
D=Path(__file__).resolve().parent
L,A,B,Q,G=config(D/'nominal.json'); cap=Q**2*(1/A-1/B)/2
for case in ('capacitor','force_only','paired'):
    w=cap+(0 if case=='capacitor' else G*L); e=cap+(G*L if case=='paired' else 0)
    for charge in [Q,-Q]:
        for rev in (False,True):
            rows=list(simulate((L,A,B,charge,G),case,256)); rows=rows[::-1] if rev else rows
            with tempfile.TemporaryDirectory() as t:
                f=Path(t)/'cycle.csv'; write(f,rows); z=reduce(read(f))
            sign=-1 if rev else 1
            for key,expected in [('mechanical_out_J',sign*w),('terminal_in_J',sign*e),('work_minus_terminal_J',sign*(w-e))]:
                assert abs(z[key]-expected)<3e-15,(case,key,z,expected)
            assert z['dx_endpoint_m']==z['dq_endpoint_C']==0
    rows=list(simulate((L,A,B,Q,G),case,256)); write(D/'examples'/f'{case}.csv',rows)
    z=reduce(rows); print(case,'F(A),F(B) nN',rows[256][2]*1e9,rows[512][2]*1e9,'V(A),V(B)',rows[256][3],rows[512][3], 'mech/terminal/residual nJ',*[round(z[k]*1e9,7) for k in ('mechanical_out_J','terminal_in_J','work_minus_terminal_J')])
errors=[abs(reduce(list(simulate((L,A,B,Q,G),'capacitor',n)))['mechanical_out_J']-cap) for n in (8,16,32,64)]
assert all(3.9<a/b<4.1 for a,b in zip(errors,errors[1:])),errors
openpath=reduce([(0,0,1,1),(1,2,1,1)]); assert openpath['dx_endpoint_m']==1 and openpath['dq_endpoint_C']==2 and openpath['work_minus_terminal_J']==-1
try: reduce([(0,0,0,0),(0,0,float('nan'),0)])
except ValueError: pass
else: raise AssertionError('nonfinite force accepted')
print('analytic, CSV polarity/reversal, open path, invalid data and quadrature-refinement checks passed')
