SetFactory("OpenCASCADE");
Geometry.OCCBooleanPreserveNumbering = 1;
Box(100) = {0,-38.0,-2.5,36.0,76.0,1};
Cylinder(101) = {8.0,-34.0,-3.5,0,0,3,1.7};
Cylinder(102) = {8.0,34.0,-3.5,0,0,3,1.7};
Cylinder(103) = {28.0,-34.0,-3.5,0,0,3,1.7};
Cylinder(104) = {28.0,34.0,-3.5,0,0,3,1.7};
BooleanDifference{ Volume{100}; Delete; }{ Volume{101,102,103,104}; Delete; }
Box(200) = {0,-38.0,1.5,36.0,76.0,1};
Cylinder(201) = {8.0,-34.0,0.5,0,0,3,1.7};
Cylinder(202) = {8.0,34.0,0.5,0,0,3,1.7};
Cylinder(203) = {28.0,-34.0,0.5,0,0,3,1.7};
Cylinder(204) = {28.0,34.0,0.5,0,0,3,1.7};
BooleanDifference{ Volume{200}; Delete; }{ Volume{201,202,203,204}; Delete; }
Box(300) = {0,-38.0,-1.5,36.0,8.0,3};
Cylinder(301) = {8.0,-34.0,-2.5,0,0,5,1.7};
Cylinder(302) = {28.0,-34.0,-2.5,0,0,5,1.7};
BooleanDifference{ Volume{300}; Delete; }{ Volume{301,302}; Delete; }
Box(400) = {0,30.0,-1.5,36.0,8.0,3};
Cylinder(401) = {8.0,34.0,-2.5,0,0,5,1.7};
Cylinder(402) = {28.0,34.0,-2.5,0,0,5,1.7};
BooleanDifference{ Volume{400}; Delete; }{ Volume{401,402}; Delete; }
Box(500) = {-36.0,-28.235,-0.5,46.0,56.47,1};
Cylinder(501) = {-29.0,-18.0704,-1.5,0,0,3,1.7};
Cylinder(502) = {-29.0,18.0704,-1.5,0,0,3,1.7};
BooleanDifference{ Volume{500}; Delete; }{ Volume{501,502}; Delete; }
Box(600) = {-36.0,-28.235,0.5,14.0,56.47,4};
Cylinder(601) = {-29.0,-18.0704,-0.5,0,0,6,1.7};
Cylinder(602) = {-29.0,18.0704,-0.5,0,0,6,1.7};
BooleanDifference{ Volume{600}; Delete; }{ Volume{601,602}; Delete; }
