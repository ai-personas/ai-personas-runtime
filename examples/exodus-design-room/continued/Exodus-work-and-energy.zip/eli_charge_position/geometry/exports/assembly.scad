// mm. Set travel=0 at A or stroke at B; z=0 at blade mid-plane.
stroke=10.0; travel=0; $fn=80;
assert(travel >= 0 && travel <= stroke);
color("lightgray") translate([0,-38.0,-2.5]) difference() { cube([36.0,76.0,1.0]);
 translate([8,4.0,-1]) cylinder(d=3.4,h=3.0);
 translate([8,72.0,-1]) cylinder(d=3.4,h=3.0);
 translate([28.0,4.0,-1]) cylinder(d=3.4,h=3.0);
 translate([28.0,72.0,-1]) cylinder(d=3.4,h=3.0);
}
color("lightgray") translate([0,-38.0,1.5]) difference() { cube([36.0,76.0,1.0]);
 translate([8,4.0,-1]) cylinder(d=3.4,h=3.0);
 translate([8,72.0,-1]) cylinder(d=3.4,h=3.0);
 translate([28.0,4.0,-1]) cylinder(d=3.4,h=3.0);
 translate([28.0,72.0,-1]) cylinder(d=3.4,h=3.0);
}
color("teal") translate([0,-38.0,-1.5]) difference() { cube([36.0,8.0,3.0]);
 translate([8,4.0,-1]) cylinder(d=3.4,h=5.0);
 translate([28.0,4.0,-1]) cylinder(d=3.4,h=5.0);
}
color("teal") translate([0,30.0,-1.5]) difference() { cube([36.0,8.0,3.0]);
 translate([8,4.0,-1]) cylinder(d=3.4,h=5.0);
 translate([28.0,4.0,-1]) cylinder(d=3.4,h=5.0);
}
color("orange") translate([-36.0+travel,-28.235,-0.5]) difference() { cube([46.0,56.47,1.0]);
 translate([7.0,10.1646,-1]) cylinder(d=3.4,h=3.0);
 translate([7.0,46.3054,-1]) cylinder(d=3.4,h=3.0);
}
color("teal") translate([-36.0+travel,-28.235,0.5]) difference() { cube([14.0,56.47,4.0]);
 translate([7.0,10.1646,-1]) cylinder(d=3.4,h=6.0);
 translate([7.0,46.3054,-1]) cylinder(d=3.4,h=6.0);
}
