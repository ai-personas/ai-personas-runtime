#!/usr/bin/env python3
"""Generate overlap actuator drawings, assembly and model config; units mm except config (SI)."""
from pathlib import Path
import json,math,argparse
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser(); p.add_argument('--step',action='store_true',help='also export STEP/FCStd using FreeCAD Python modules'); a=p.parse_args()
d=json.loads((D/'dimensions.json').read_text()); w,l,g,t,o,s,fw,fl,rw,cl,ct,hd=(float(d[k]) for k in ('blade_width_mm','blade_length_mm','gap_each_mm','plate_thickness_mm','overlap_A_mm','travel_mm','frame_width_mm','frame_length_mm','rail_width_mm','clamp_length_mm','clamp_thickness_mm','hole_diameter_mm'))
assert min(w,l,g,t,o,s,fw,fl,rw,cl,ct,hd)>0 and o+s<fl and o+s<l-cl and w<fw-2*rw and rw>hd and fl>16+hd and cl>hd and w>hd+4
H=t+2*g
# name, x,y,z origin at A, size X,Y,Z, local through-hole centers, moving?
parts=[]
def add(n,x,y,z,X,Y,Z,holes,moving=False):
    assert all(hd/2<u<X-hd/2 and hd/2<v<Y-hd/2 for u,v in holes)
    parts.append((n,x,y,z,X,Y,Z,holes,moving))
fixedholes=[(u,v) for u in (8,fl-8) for v in (rw/2,fw-rw/2)]
for n,z in [('lower',-H/2-t),('upper',H/2)]: add(n,0,-fw/2,z,fl,fw,t,fixedholes)
for n,y in [('rail_L',-fw/2),('rail_R',fw/2-rw)]: add(n,0,y,-H/2,fl,rw,H,[(u,rw/2) for u in (8,fl-8)])
bladeholes=[(cl/2,v) for v in (w*.18,w*.82)]
add('blade',o-l,-w/2,-t/2,l,w,t,bladeholes,True)
add('clamp',o-l,-w/2,t/2,cl,w,ct,bladeholes,True)
out=D/'exports'; out.mkdir(exist_ok=True)
# R12 DXF. The rectangular cut and circles are all nominal finished contours, no tool compensation.
def dxf(X,Y,holes):
    pairs=[]
    def tag(k,v): pairs.extend((str(k),format(v,'.12g') if isinstance(v,float) else str(v)))
    for k,v in [(0,'SECTION'),(2,'HEADER'),(9,'$ACADVER'),(1,'AC1009'),(0,'ENDSEC'),(0,'SECTION'),(2,'ENTITIES')]: tag(k,v)
    for k,v in [(0,'POLYLINE'),(8,'CUT'),(66,1),(10,0),(20,0),(30,0),(70,1)]: tag(k,v)
    for x,y in [(0,0),(X,0),(X,Y),(0,Y)]:
        for k,v in [(0,'VERTEX'),(8,'CUT'),(10,x),(20,y),(30,0)]: tag(k,v)
    tag(0,'SEQEND'); tag(8,'CUT')
    for x,y in holes:
        for k,v in [(0,'CIRCLE'),(8,'CUT'),(10,x),(20,y),(30,0),(40,hd/2)]: tag(k,v)
    tag(0,'ENDSEC'); tag(0,'EOF'); return chr(10).join(pairs)+chr(10)
sc=['// mm. Set travel=0 at A or stroke at B; z=0 at blade mid-plane.',f'stroke={s}; travel=0; $fn=80;', 'assert(travel >= 0 && travel <= stroke);']
for n,x,y,z,X,Y,Z,holes,m in parts:
    (out/f'{n}.dxf').write_text(dxf(X,Y,holes)); color='orange' if n=='blade' else 'lightgray' if n in ('upper','lower') else 'teal'
    sc.append(f'color("{color}") translate([{x}'+('+travel' if m else '')+f',{y},{z}]) difference() {{ cube([{X},{Y},{Z}]);')
    for u,v in holes: sc.append(f' translate([{u},{v},-1]) cylinder(d={hd},h={Z+2});')
    sc.append('}')
(out/'assembly.scad').write_text(chr(10).join(sc)+chr(10))
EPS=8.8541878128e-12; Cp=2*EPS*w/g; A=Cp*o/1000; B=Cp*(o+s)/1000
cfg=dict(stroke_m=s/1000,C_A_F=A,C_B_F=B,q_full_C=1e-10,extra_F_N=1e-8)
(D/'geometry-cycle.json').write_text(json.dumps(cfg,indent=2)+chr(10)); print('Geometry: C_A/C_B pF',A*1e12,B*1e12,'Cprime nF/m',Cp*1e9,'side rail clearance mm',(fw-w)/2-rw,'clamp setback at B mm',l-cl-o-s)
if a.step:
    import FreeCAD as App,Part
    V=App.Vector; doc=App.newDocument('Actuator_A'); solids=[]
    for n,x,y,z,X,Y,Z,holes,m in parts:
        plate=Part.makeBox(X,Y,Z)
        for u,v in holes: plate=plate.cut(Part.makeCylinder(hd/2,Z,V(u,v,0)))
        assert plate.isValid() and abs(plate.Volume-(X*Y-len(holes)*math.pi*hd**2/4)*Z)<1e-5
        plate.translate(V(x,y,z)); obj=doc.addObject('Part::Feature',n); obj.Shape=plate; solids.append(obj)
    doc.recompute(); doc.saveAs(str(out/'at_A.FCStd')); Part.export(solids,str(out/'at_A.step'))
    for o3,part in zip(solids,parts):
        if part[-1]: o3.Placement.Base # set whole placement below
        if part[-1]: o3.Placement=App.Placement(V(s,0,0),App.Rotation())
    doc.recompute(); Part.export(solids,str(out/'at_B.step'))
    for fname in ('at_A.step','at_B.step'):
        shp=Part.read(str(out/fname)); assert len(shp.Solids)==6 and shp.isValid(); print(fname,len(shp.Solids),'solids',shp.Volume,'mm^3')
