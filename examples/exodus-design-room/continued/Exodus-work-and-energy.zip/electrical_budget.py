"""Illustrative electrical collection budget for the two bundled ideal cycle traces only."""
import argparse,csv,math,pathlib
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--generator',type=float,default=1.0,help='fraction of stroke work reaching the electrical bus')
ap.add_argument('--recovery',type=float,default=1.0,help='fraction of recoverable discharge energy reaching the same bus')
ap.add_argument('--charge-factor',type=float,default=1.0,help='source charging energy divided by reversible charge work (>=1)')
ap.add_argument('--aux-nJ',type=float,default=0.0,help='additional external energy per complete cycle, in nJ')
a=ap.parse_args()
if not (0<=a.generator<=1 and 0<=a.recovery<=1 and math.isfinite(a.charge_factor) and a.charge_factor>=1 and math.isfinite(a.aux_nJ) and a.aux_nJ>=0):ap.error('invalid efficiency, charge factor or auxiliary energy')
for case in ('paired','force_only'):
 path=pathlib.Path(__file__).resolve().parent/'eli_charge_position'/'examples'/(case+'.csv')
 with path.open() as f:r=[tuple(float(v[k]) for k in ('x_m','q_C','F_N','V_V')) for v in csv.DictReader(f)]
 assert r[0][:2]==r[-1][:2] and all(math.isfinite(v) for row in r for v in row)
 w=inc=rec=0.
 for (x,q,F,V),(y,h,G,U) in zip(r,r[1:]):
  w+=0.5*(F+G)*(y-x)*1e9
  d=0.5*(V+U)*(h-q)*1e9
  inc+=max(0,d);rec+=max(0,-d)
 cost=inc*a.charge_factor+a.aux_nJ
 out=a.generator*w+a.recovery*rec
 print(f'{case}: charge input + aux {cost:.5f} nJ; converted stroke {a.generator*w:.5f} nJ; recovered discharge {a.recovery*rec:.5f} nJ; bus out minus input {out-cost:+.5f} nJ; stroke efficiency at break-even {(cost-a.recovery*rec)/w:.4f}')
