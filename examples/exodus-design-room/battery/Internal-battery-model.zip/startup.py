"""Ordinary battery-only counterexample. No source except the initial battery."""
import json, math, sys
from pathlib import Path

def cycle(c):
    keys=('battery_initial_Wh','startup_withdrawal_Wh','battery_dis_eff','buffer_fill_eff','buffer_release_eff','load_W','return_bus_W','return_converter_eff','battery_charge_eff')
    if not all(type(c.get(k)) in (int,float) and math.isfinite(c[k]) for k in keys): raise ValueError('missing or nonfinite field')
    E,q,d,f,h,L,B,r,a=(c[k] for k in keys)
    if not (0<q<=E and L>0 and B>=0 and all(0<x<=1 for x in (d,f,h,r,a))): raise ValueError('invalid energy, power or efficiency')
    # Phase A: transfer energy from battery to initially empty buffer, with loss.
    bank=q*d*f; startup_loss=q-bank
    # Phase B: external supply remains disconnected. Buffer alone drives the two branches.
    gross=L+B/r; bank_power=gross/h; t=bank/bank_power
    # Store rates and losses are Wh/h = W. Positive battery change means recharge.
    recharged=B*a*t; work=L*t; final=E-q+recharged
    release_loss=(bank_power-gross)*t; return_loss=(B/r-B)*t; charge_loss=B*(1-a)*t
    losses=startup_loss+release_loss+return_loss+charge_loss
    return dict(battery_at_start_Wh=E,buffer_at_start_Wh=0,battery_after_fill_Wh=E-q,buffer_after_fill_Wh=bank,fill_loss_Wh=startup_loss,buffer_discharge_W=bank_power,load_W=L,battery_terminal_charge_W=B,battery_storage_charge_W=B*a,loaded_s=t*3600,load_Wh=work,battery_regained_Wh=recharged,buffer_at_end_Wh=0,battery_at_end_Wh=final,release_loss_Wh=release_loss,return_loss_Wh=return_loss,battery_charge_loss_Wh=charge_loss,total_loss_Wh=losses,external_in_Wh=0,balance_error_Wh=E-final-work-losses)

if __name__=='__main__':
    print(json.dumps(cycle(json.loads(Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_name('startup.json')).read_text())),indent=2))
