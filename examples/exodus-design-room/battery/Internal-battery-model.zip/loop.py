"""Piecewise-constant DC energy ledger. All cases are models, never measurements."""
import argparse, csv, json, math, sys
from pathlib import Path


def finite(x):
    return type(x) in (float,int) and math.isfinite(x)


def solve(c):
    fields = ('stage_in_W','gain','feedback_fraction','eta_return','eta_dis','eta_ch','aux_W','store_initial_Wh','store_max_Wh','duration_h')
    if not all(k in c and finite(c[k]) for k in fields): raise ValueError('missing or nonfinite numeric case field')
    i,g,r,er,ed,ec,a,e0,em,t = [c[k] for k in fields]
    if not (i>0 and g>=0 and 0<=r<=1 and 0<er<=1 and 0<ed<=1 and 0<ec<=1 and a>=0 and em>0 and 0<=e0<=em and t>0): raise ValueError('case outside physical parameter ranges')
    gross=i*g; divert=gross*r; load=gross-divert; ret=er*divert
    bat=i+a-ret  # positive: leaves the battery terminal
    dE=-bat/ed if bat>=0 else -bat*ec  # Wh/h
    batt_heat=-dE-bat
    limit=(e0/(-dE) if dE<0 else (em-e0)/dE if dE>0 else math.inf)
    actual=min(t,limit); end=max(0.,min(em,e0+dE*actual))
    stage_loss=max(i-gross,0.); src=max(gross-i,0.)  # conservative lower bound if stipulated gain>1
    losses=stage_loss+(divert-ret)+batt_heat+a
    balance=src*actual-load*actual-losses*actual-(end-e0)
    return dict(case=c['case'],stage_in_W=i,gross_W=gross,load_W=load,divert_W=divert,return_bus_W=ret,battery_out_W=bat,store_rate_Wh_per_h=dE,aux_W=a,stage_loss_W=stage_loss,return_loss_W=divert-ret,battery_loss_W=batt_heat,undemonstrated_stage_power_W=src,requested_h=t,modeled_h=actual,end_reason=('empty' if dE<0 else 'full') if limit<=t else 'requested time',store_initial_Wh=e0,store_end_Wh=end,load_Wh=load*actual,undemonstrated_stage_Wh=src*actual,losses_Wh=losses*actual,balance_error_Wh=balance)


def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('cases',nargs='?',default=str(Path(__file__).with_name('cases.json'))); ap.add_argument('--out',help='write CSV here instead of stdout'); args=ap.parse_args()
    cases=json.loads(Path(args.cases).read_text()); rows=[solve(c) for c in cases]
    if not rows: raise ValueError('no cases')
    out=open(args.out,'w',newline='') if args.out else sys.stdout
    try:
        w=csv.DictWriter(out,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    finally:
        if args.out: out.close()
if __name__=='__main__': main()
