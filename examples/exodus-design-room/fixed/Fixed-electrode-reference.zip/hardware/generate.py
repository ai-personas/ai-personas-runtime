#!/usr/bin/env python3
"""Emit rigid field coupon schematic and board. All distances in mm."""
from pathlib import Path
from uuid import NAMESPACE_URL,uuid5
import json,os
os.chdir(Path(__file__).resolve().parent)
J=json.loads(Path('../geometry.json').read_text());du,dv=J['drive_size_mm'];pu,pv=J['pickup_size_mm'];dx,dy=J['pickup_offset_mm'];uid=lambda x:str(uuid5(NAMESPACE_URL,'fixed-field-coupon-A/'+x));file=lambda n,t:Path(n).write_text(t+'\n')
parts=[('P1','Wire','IN',57,69,['IN']),('R1','R','1k',63,69,['IN','DRIVE']),('P2','Wire','COM',57,82,['COM']),('R2','R','1M',63,82,['COM','DRIVE']),('C1','Field','Fixed opposed copper',100,75,['DRIVE','PICKUP']),('R3','R','100k',127,75,['PICKUP','COM']),('P3','Wire','OUT',127,82,['PICKUP'])];nets=['','IN','DRIVE','PICKUP','COM'];names={'Field':'FixedOpposed','Wire':'WirePad_10','R':'Axial_1016'};fp=lambda k:'Fixed:'+names[k]
b=['(kicad_pcb (version 20240108) (generator pcbnew) (general (thickness 1.6)) (paper "A4") (layers (0 "F.Cu" signal) (31 "B.Cu" signal) (36 "B.SilkS" user "b.silkscreen") (37 "F.SilkS" user "f.silkscreen") (38 "B.Mask" user) (39 "F.Mask" user) (44 "Edge.Cuts" user) (49 "F.Fab" user)) (setup (pad_to_mask_clearance 0))']+[f'(net {i} "{n}")' for i,n in enumerate(nets)];Path('Fixed.pretty').mkdir(exist_ok=True)
for ref,k,v,x,y,nn in parts:
 body=[];tx,ty=(5.08,-2.3) if k=='R' else ((0,-15.5) if k=='Field' else (0,-2.2))
 for prop,val,oy,layer in [('Reference',ref,ty,'F.SilkS'),('Value',v,-ty,'F.Fab')]:body.append(f'(property "{prop}" "{val}" (at {tx} {oy}) (layer "{layer}") (effects (font (size .9 .9) (thickness .15))))')
 if k=='R':body.append('(fp_rect (start 1.83 -1.25) (end 8.33 1.25) (stroke (width .15) (type default)) (fill none) (layer "F.SilkS"))')
 for i,n in enumerate(nn):
  if k=='Field':a=f'(pad "{i+1}" smd rect (at {dx if i else 0} {dy if i else 0}) (size {pu if i else du} {pv if i else dv}) (layers "{"B.Cu" if i else "F.Cu"}")'
  else:a=f'(pad "{i+1}" thru_hole {"rect" if k=="R" and not i else "circle"} (at {i*10.16} 0) (size {"1.6 1.6" if k=="R" else "2 2"}) (drill {0.85 if k=="R" else 1.0}) (layers "*.Cu" "*.Mask")'
  body.append(a+f' (net {nets.index(n)} "{n}") (pintype "passive"))')
 attr='smd' if k=='Field' else 'through_hole';b.append(f'(footprint "{fp(k)}" (layer "F.Cu") (uuid {uid(ref+"-fp")}) (at {x} {y}) (path "/{uid(ref+"-sym")}") (attr {attr})\n'+'\n'.join(body)+')');import re
 local=re.sub(r' \(net \d+ "[^"]+"\) \(pintype "passive"\)','', '\n'.join(body)).replace(f'"Reference" "{ref}"','"Reference" "REF**"').replace(f'"Value" "{v}"',f'"Value" "{names[k]}"');file(f'Fixed.pretty/{names[k]}.kicad_mod',f'(footprint "{names[k]}" (version 20240108) (generator pcbnew) (layer "F.Cu") (attr {attr})\n'+local+')')
 if k=='Wire':b.append(f'(gr_text "{v}" (at {x} {y+2.2}) (layer "F.SilkS") (effects (font (size 1 1) (thickness .15))))')
def route(n,pts,l):
 for (x,y),(u,v) in zip(pts,pts[1:]):b.append(f'(segment (start {x} {y}) (end {u} {v}) (width .4) (layer "{l}.Cu") (net {nets.index(n)}))')
route('IN',[(57,69),(63,69)],'F');route('DRIVE',[(73.16,69),(74,69),(80,75),(100,75)],'F');route('DRIVE',[(73.16,82),(73.16,81.84),(80,75)],'F');route('PICKUP',[(100+dx,75+dy),(127,75),(127,82)],'B');route('COM',[(57,82),(63,82),(63,92),(66,95),(134,95),(137.16,91.84),(137.16,75)],'B');b.append('(gr_rect (start 52 55) (end 143 99) (stroke (width .05) (type default)) (fill none) (layer "Edge.Cuts"))');b.append('(gr_text "FIXED FIELD / A    IN - R1 - DRIVE    OUT = PICKUP" (at 95 96) (layer "F.SilkS") (effects (font (size 1 1) (thickness .15))))');file('fixed.kicad_pcb','\n'.join(b+[')']))
font='(effects (font (size 1.27 1.27)))';hidden=font[:-1]+' hide)';stroke='(stroke (width .254) (type default)) (fill (type none))';sheet=uid('sheet')
def pin(x,y,a,L,i):return f'(pin passive line (at {x} {y} {a}) (length {L}) (name "~" {font}) (number "{i}" {font}))'
def capline(x):return f'(polyline (pts (xy {x} -2.54) (xy {x} 2.54)) {stroke})'
def sym(k,r,g,p):return f'(symbol "{k}" (pin_names (offset 0) hide) (pin_numbers hide) (in_bom yes) (on_board yes) (property "Reference" "{r}" (at 0 3.81 0) {font}) (property "Value" "{k}" (at 0 -3.81 0) {font}) (property "Footprint" "{fp(k)}" (at 0 0 0) {hidden}) (symbol "{k}_0_1" {g}) (symbol "{k}_1_1" {p}))'
syms=[sym('R','R',f'(rectangle (start -2.54 1.016) (end 2.54 -1.016) {stroke})',pin(-5.08,0,0,2.54,1)+pin(5.08,0,180,2.54,2)),sym('Field','C',capline(-1.27)+capline(1.27),pin(-5.08,0,0,3.81,1)+pin(5.08,0,180,3.81,2)),sym('Wire','P',f'(circle (center 0 -.635) (radius .635) {stroke})',pin(0,2.54,270,2.54,1))];file('Fixed.kicad_sym','(kicad_symbol_lib (version 20231120) (generator kicad_symbol_editor)\n'+'\n'.join(syms)+')');file('sym-lib-table','(sym_lib_table (version 7) (lib (name "Fixed")(type "KiCad")(uri "${KIPRJMOD}/Fixed.kicad_sym")(options "")(descr "Fixed field coupon")))');file('fp-lib-table','(fp_lib_table (version 7) (lib (name "Fixed")(type "KiCad")(uri "${KIPRJMOD}/Fixed.pretty")(options "")(descr "Fixed field coupon")))');file('fixed.kicad_pro','{}');s=[f'(kicad_sch (version 20231120) (generator eeschema) (uuid {sheet}) (paper "A4") (title_block (title "Fixed field | input, storage and load") (rev "A")) (lib_symbols '+''.join(t.replace('(symbol "','(symbol "Fixed:',1) for t in syms)+')'];xy={'P1':(40.64,53.34,0),'R1':(60.96,50.8,0),'C1':(99.06,50.8,0),'P3':(139.7,53.34,0),'R2':(86.36,76.2,180),'R3':(116.84,76.2,180),'P2':(101.6,91.44,0)}
for ref,k,v,_,__,nn in parts:
 x,y,a=xy[ref];s.append(f'(symbol (lib_id "Fixed:{k}") (at {x} {y} {a}) (unit 1) (in_bom yes) (on_board yes) (uuid {uid(ref+"-sym")})');
 for p,w,oy,ef in [('Reference',ref,2.8 if k=='Wire' else -3.81,font),('Value',v,5.1 if k=='Wire' else 3.81,font),('Footprint',fp(k),0,hidden)]:s.append(f'(property "{p}" "{w}" (at {x} {y+oy} 0) {ef})')
 for i,n in enumerate(nn):s.append(f'(pin "{i+1}" (uuid {uid(ref+str(i))}))');
 s.append(f'(instances (project "fixed" (path "/{sheet}" (reference "{ref}") (unit 1)))))')
def wire(*pts):
 for (x,y),(u,v) in zip(pts,pts[1:]):s.append(f'(wire (pts (xy {x} {y}) (xy {u} {v})) (stroke (width 0) (type default)) (uuid {uid(str((x,y,u,v)))}))')
wire((40.64,50.8),(55.88,50.8));wire((66.04,50.8),(73.66,50.8),(93.98,50.8));wire((104.14,50.8),(129.54,50.8),(139.7,50.8));wire((73.66,50.8),(73.66,76.2),(81.28,76.2));wire((91.44,76.2),(101.6,76.2),(111.76,76.2));wire((121.92,76.2),(129.54,76.2),(129.54,50.8));wire((101.6,76.2),(101.6,88.9));
for x,y in [(73.66,50.8),(129.54,50.8),(101.6,76.2)]:s.append(f'(junction (at {x} {y}) (diameter 0) (color 0 0 0 0) (uuid {uid(str(x))}))')
for n,x,y,a in [('IN',40.64,50.8,180),('DRIVE',73.66,50.8,180),('PICKUP',139.7,50.8,0),('COM',101.6,88.9,180)]:s.append(f'(global_label "{n}" (shape passive) (at {x} {y} {a}) (effects (font (size 1.27 1.27)) (justify {"right" if a==180 else "left"})) (uuid {uid(n)}))')
for i,t in enumerate(['C1 = patterned copper, not a fitted component. 10.25 pF is the nominal overlap term.','Additional shunts to COM are assumptions in the simulation, not installed capacitors.','Input P1 and load readout P3 share return P2. After precharge, IN is open.']):s.append(f'(text "{t}" (at 40.64 {109.22+i*5.08} 0) (effects (font (size 1.27 1.27)) (justify left)) (uuid {uid(t)}))')
file('fixed.kicad_sch','\n'.join(s+['(sheet_instances (path "/" (page "1")))',')']))
