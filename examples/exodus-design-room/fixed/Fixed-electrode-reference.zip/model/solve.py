#!/usr/bin/env python3
"""Fixed two-node RC network, SI units internally. Python 3 standard library."""
from pathlib import Path
import csv,json,math,cmath
D=Path(__file__).resolve().parent
j=json.loads((D.parent/'geometry.json').read_text())
w,h=j['drive_size_mm'];u,v=j['pickup_size_mm']; x,y=j['pickup_offset_mm']
def overlap(a,b,d):return max(0,min(a/2,d+b/2)-max(-a/2,d-b/2))
area=overlap(w,u,x)*overlap(h,v,y)
C=8.8541878128e-12*j['epsilon_r']*area*1e-6/(j['dielectric_mm']*1e-3); A=C+j['drive_shunt_pF']*1e-12; B=C+j['pickup_shunt_pF']*1e-12
rs,rp,rl=[j[n+'_ohm'] for n in ('series','bleed','load')]; gs,gp,gl=1/rs,1/rp,1/rl;U=j['sine_rms_V']; V0=j['precharge_V']*rp/(rp+rs)
assert min(C,A-C,B-C,gs,gp,gl,U)>0
# Open input: Cmat * dv/dt = -Gv, G=diag(gp,gl), Cmat=[[A,-C],[-C,B]].
det=A*B-C*C; tr=(B*gp+A*gl)/det; prod=gp*gl/det
k2=(tr+math.sqrt(tr*tr-4*prod))/2; k1=prod/k2
def coeff(y0,dy):
    b=(-dy-k1*y0)/(k2-k1); return y0-b,b
m=coeff(V0,-B*gp*V0/det); n=coeff(0,-C*gp*V0/det)
def voltage(a,t):return a[0]*math.exp(-k1*t)+a[1]*math.exp(-k2*t)
def loss(a,t,g):
    def integ(k):return -math.expm1(-k*t)/k
    return g*(a[0]**2*integ(2*k1)+2*a[0]*a[1]*integ(k1+k2)+a[1]**2*integ(2*k2))
def stored(d,p):return .5*((A-C)*d*d+(B-C)*p*p+C*(d-p)**2)
E0=stored(V0,0); end=16/k1; dis=[]
for ii in range(1001):
    t=end*ii/1000; d=voltage(m,t); p=voltage(n,t); f=stored(d,p); drain=loss(m,t,gp); load=loss(n,t,gl)
    assert abs(E0-f-drain-load)<1e-12*E0
    dis.append([t,d,p,p*p*gl,f,load,drain])
def csvout(name,head,rows):
    with (D/name).open('w',newline='') as out:
        w=csv.writer(out);w.writerow(head.split(',')); w.writerows(rows)
csvout('isolated.csv','t_s,Vdrive_V,Vpickup_V,Pload_W,Ufield_J,Eload_J,Ebleed_J',dis)
# RMS phasors; Re(V*conj(I)) at IN, not apparent power.
sweep=[]
for ii in range(201):
    f=10**(1+6*ii/200); s=2j*math.pi*f; aa=gs+gp+s*A; bb=gl+s*B; cc=s*C; denom=aa*bb-cc**2
    d=U*gs*bb/denom; p=U*gs*cc/denom; i=(U-d)*gs; va=U*i.conjugate(); heat=abs(p)**2*gl; series=abs(i)**2*rs; bleed=abs(d)**2*gp
    assert abs(va.real-heat-series-bleed)<2e-11*va.real
    sweep.append([f,abs(d),abs(p),va.real,va.imag,heat,series,bleed,heat/va.real])
csvout('ac.csv','f_Hz,Vdrive_rms,Vpickup_rms,Pin_W,Qin_var,Pload_W,Pseries_W,Pbleed_W,load_over_real_input',sweep)
(D/'open.cir').write_text(f'''Fixed initially charged board; IN open; no source
Cdp d p {C:.15g} ic={V0:.15g}
Cd d 0 {A-C:.15g} ic={V0:.15g}
Cp p 0 {B-C:.15g} ic=0
Rb d 0 {rp}
Rl p 0 {rl}
.control
set wr_singlescale
set wr_vecnames
tran {end/2000:.15g} {end:.15g} uic
wrdata open-spice.dat v(d) v(p)
quit
.endc
.end
''')
(D/'driven.cir').write_text(f'''Fixed continuously driven board; ac quantities interpreted as RMS
Vs in 0 dc 0 ac {U}
Rs in d {rs}
Cdp d p {C:.15g}
Cd d 0 {A-C:.15g}
Cp p 0 {B-C:.15g}
Rb d 0 {rp}
Rl p 0 {rl}
.control
set wr_singlescale
set wr_vecnames
ac dec 30 10 10Meg
let pin=-real(i(Vs))*{U}
let pout=mag(v(p))^2/{rl}
wrdata driven-spice.dat pin pout
quit
.endc
.end
''')
print('nominal overlap mm2',area,'Cmut pF',C*1e12,'stored pJ',E0*1e12,'post-isolation load pJ',dis[-1][5]*1e12,'open source IN: i=0');print('highest efficiency sampled (not continuous optimum):',max(sweep,key=lambda r:r[-1]));print('Hz 10000 nominal row:',sweep[100]);print('DC precharge steady divider draws W',j['precharge_V']**2/(rp+rs))
