"""Plot unmodified ngspice data from the two cases. P is real, not apparent."""
from pathlib import Path
import json
import numpy as np, matplotlib
matplotlib.use('Agg');import matplotlib.pyplot as plt
r=Path(__file__).resolve().parents[1];find=lambda name:next((r/'model').rglob(name));out=Path(__file__).resolve().parent
f,pin,pl=np.loadtxt(find('driven-spice.dat'),skiprows=1).T
fig,ax=plt.subplots(2,1,figsize=(7.2,6.2),sharex=True,layout='constrained');ax[0].loglog(f,pin*1e6,label='IN: real power supplied');ax[0].loglog(f,pl*1e6,label='LOAD: heat in R3');ax[0].legend();ax[0].set_ylabel('Real power (µW)');ax[1].semilogx(f,pl/pin*100);ax[1].set_ylabel('Load / input (%)');ax[1].set_ylim(0,105);ax[1].set_xlabel('Sinusoidal drive frequency (Hz)');fig.suptitle('Continuous 1 V RMS drive — fixed geometry, model only');[a.grid(True,alpha=.25) for a in ax];fig.savefig(out/'driven.svg');plt.close(fig)
t,d,p=np.loadtxt(find('open-spice.dat'),skiprows=1).T
fig,ax=plt.subplots(2,1,sharex=True,figsize=(7.2,5.5),layout='constrained');ax[0].plot(t*1e6,d,label='DRIVE');ax[0].plot(t*1e6,p,label='PICKUP');ax[0].set_ylabel('Voltage to COM (V)');ax[0].legend();power=p*p/json.loads((r/'geometry.json').read_text())['load_ohm'];e=np.r_[0,np.cumsum(np.diff(t)*(power[:-1]+power[1:])/2)];ax[1].plot(t*1e6,e*1e12);ax[1].set_xlabel('Time after opening IN (µs)');ax[1].set_ylabel('Load energy (pJ)');[a.grid(True,alpha=.25) for a in ax];fig.suptitle('After a settled 5 V charge — finite discharge, model only');fig.savefig(out/'isolated.svg');print('ngspice integrated R3 heat (pJ)',e[-1]*1e12,'last recorded (s)',t[-1])
