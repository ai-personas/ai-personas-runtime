# Can a fixed electrical circuit double the useful power from one port?

**Yes, relative to the signal port; no, relative to all supplied power in this design.** Open `circuit.svg` for the circuit and `power.svg` for the two different denominators. This is a conventional, electrically pumped resonator. There is no rotor, moving electrode, propulsion assumption, measured COP or 20 W rating.

## Connection to Exodus

US 2023/0121805 A1 [0181] places different permittivities at different positions. That spatial variation does not prescribe a periodic change with time. [0190] allows applied voltages or external fields to vary in time; [0204] allows man-made or environmental fields. None of these passages supplies a measured power-vs-load law for a dielectric that modulates itself. A force at a fixed support has no mechanical power there (F·v = 0). The pump below is **our comparison**, not an inferred feature of a proprietary article.

## Two models, two boundaries

For the reduced differential tank (`tank.py`), q = C(t)v and U = q²/(2C). Thus dU/dt = v dq/dt − ½v² dC/dt. The last term is the power **into** the field from modulation. Lower C at high |v|, raise it at low |v|, and the modulator does positive work on average. Reverse its phase and the same modulation can attenuate the signal. A specified C(t) is not a free physical actuator. The reduced model charges the *net differential-mode work* to the modulator, but omits the common-mode pump current and its resistor losses. At the selected pump amplitude its load/signal ratio is 2.0000 and its load/(signal + ideal modulation work) is 0.98550.

The separate ngspice model charges the actual modeled source ports. Two reverse-biased junctions have differential capacitance Cj(u)=100 pF / sqrt(1+u/0.7 V), u = cathode minus anode voltage. They share pump node p. A center-tapped winding and opposed signal terminals give differential resonance while allowing common-mode displacement current at twice the signal frequency. Only power in the 150 kΩ resistor is useful output. Explicit leakage, winding and driver resistance are paid losses. Junction energy is ∫u Cj(u) du, not Cj(u)u²/2. The netlist is the editable circuit; all parameters including winding coupling and parasitics are illustrative.

## What reaches the load?

All numbers below are **simulated signed averages** from 276 to 300 µs; pump port includes its DC bias. Both endpoints have the same nominal drive phases. At 0.5 ns maximum step:

|Case|Signal input (nW)|Pump input (nW)*|Load (nW)|Load/signal|
|---|---:|---:|---:|---:|
|No AC pump, bias on|0.73912|0.03203|0.72840|0.98549|
|Pump aligned|1.50095|834.2145|3.00748|2.00371|
|Pump reversed 180°|0.48937|832.4987|0.32046|0.65485|
|Pump only|0|832.6625|numerical zero|undefined|

\*Charge-integral method. In the aligned case about 666.118 nW goes to the 5 Ω driver resistor and 166.574 nW to the winding resistors. Charging the common junction capacitance cyclically drives real current through those resistors even with the signal off. The aligned load receives **0.3599% of the two net port inputs**, not 200% of battery input. The pump-only null is for exactly matched modeled branches, not a prediction of perfect rejection in hardware.

For an internal battery and ideal reversible source electronics the aligned circuit needs about **835.7 nW** net from the battery just for the two drives; nonideal drivers and controls cost more. Sending load power back to the battery would reduce what is available to the external load. This nanowatt example must not be scaled into a 20 W hardware design. In any steady, restored-state interval with a separate 10 W source and 20 W useful load, another source must provide at least 10 W plus losses. If the 10 W circulates internally and the battery returns to its initial *energy*, the required net outside contribution is at least **20 W plus losses**. A waveform generator hidden inside the enclosure is not an additional energy source.

## Reproduce

1. With Python 3 alone: `python3 report.py` checks the archived balances and regenerates `power.svg` from `ports.csv`.
2. With Python 3, NumPy and ngspice on PATH: from this directory run `python3 ports.py` then `python3 report.py`. This rewrites all 12 editable decks and port rows and the resampled final period of the 1 ns aligned run (`gain_period.csv`). Each deck can also be opened and run separately with `ngspice -b`; the deck writes `trace.dat` in the working directory. `ports.py` integrates the full adaptive-step trace, **not** the downsampled period illustration.
3. Check two independent pump integrals in `ports.csv`: (a) average of −v_ps i_Vpump, (b) integration by parts of the total junction charge against v_ps, plus leakage work. Both include endpoint terms. At 0.5 ns they differ by 0.036 nW in the aligned case. Including storage change, signed residuals fall from +1.20 / −0.262 nW at 2 ns to +0.0195 / −0.0165 nW at 0.5 ns. That is numerical convergence, **not** an experimental uncertainty bound.

To reproduce `ideal_checks.csv` rather than the general phase sweep, run `python3 check_ideal.py`. It solves each listed pump amplitude, phase, time step and cycle count again with a 24-cycle averaging window, then checks every output column. In the reduced two-junction solver the pump integral is the signed electrical work at its ideal prescribed-voltage node. Common-mode reactive current is present, but there is no series pump-driver resistance or common-mode winding loss in that model.

## Design and evidence boundary

The previously issued fixed-capacitance KiCad board, CAD/CAM, Gerbers, drill, BOM and meter are in the separate **Exodus with fixed electrodes** collection (`exodus/fixed/START-HERE.md`). It does not implement this parametric circuit. The comparator deliberately uses an editable nonlinear junction model and ideal controlled sources, not unverified orderable component identifiers. No demonstrated surplus source exists here for a generator PCB to implement. To test the claim with existing records, the useful return is synchronized same-device load and port V/I through startup, operation and reset, including the pump electronics, timing calibration and independent bounds on recoverable battery and dielectric energy. Research and digital design only; no ordering, fabrication or powered testing.
