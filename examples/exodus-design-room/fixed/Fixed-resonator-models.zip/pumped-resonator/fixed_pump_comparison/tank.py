"""Fixed-junction, differential parametric tank. SI units; ideal center tap.
Positive current/power from each source into the modeled circuit.
Run with Python 3. No third-party modules.
"""
import math,csv,sys
from pathlib import Path
from math import sin,cos,sqrt,pi
C0=100e-12; VJ=.7; BIAS=4.; F=1e6; W=2*pi*F; IS=1e-7
RL=150e3; RS=5.; CF=3e-12
# Center-tapped tank: outer nodes at +/-v/2, common cathode at p.
def cj(x): return C0/sqrt(1+x/VJ)
def uj(x):
    # integral V*dQ from 0 to x. Stable equivalent of y**3/3-y+2/3.
    y=sqrt(1+x/VJ); return 2*C0*VJ**2*(y-1)**2*(y+2)/3
L=1/(W*W*(CF+cj(BIAS)/2))
def run(amp,phase,n=96,cycles=240,window=24):
    if not 0<window<cycles: raise ValueError('need startup and whole-cycle averaging window')
    dt=1/(F*n); v=i=0.; sums=[0.]*4; lo=1e30; peak=0.
    def source(t): return BIAS+amp*sin(2*W*t+phase),2*W*amp*cos(2*W*t+phase),IS*cos(W*t)
    def energy(t,v,i):
        p,_,_=source(t);return uj(p-v/2)+uj(p+v/2)+CF*v*v/2+L*i*i/2
    def rhs(t,v,i):
        p,pdot,isin=source(t); x=p-v/2; y=p+v/2
        if min(x,y)<0:raise ValueError('reverse-bias domain exceeded')
        a,b=cj(x),cj(y); k=(b-a)/2; d=CF+(a+b)/4
        vd=(isin-v/RL-i-k*pdot)/d; idot=(v-RS*i)/L
        ip=(a+b)*pdot+k*vd
        return vd,idot,isin*v,p*ip,v*v/RL,RS*i*i
    for j in range(n*cycles):
        t=j*dt; use=j>=(cycles-window)*n
        if j==(cycles-window)*n: e0=energy(t,v,i)
        a=rhs(t,v,i); b=rhs(t+dt/2,v+a[0]*dt/2,i+a[1]*dt/2); c=rhs(t+dt/2,v+b[0]*dt/2,i+b[1]*dt/2); d=rhs(t+dt,v+c[0]*dt,i+c[1]*dt)
        def inc(k): return dt/6*(a[k]+2*b[k]+2*c[k]+d[k])
        if use:
            for k in range(4): sums[k]+=inc(2+k)
            lo=min(lo,source(t)[0]-abs(v)/2);peak=max(peak,abs(v))
        v+=inc(0); i+=inc(1)
    ps,pp,pl,pr=[x*F/window for x in sums]; du=(energy(cycles/F,v,i)-e0)*F/window
    return dict(pump_peak_V=amp,phase_rad=phase,steps_per_period=n,signal_W=ps,pump_W=pp,load_W=pl,winding_loss_W=pr,storage_change_W=du,balance_error_W=ps+pp-pl-pr-du,load_over_signal=(pl/ps if ps>0 else None),load_over_all=(pl/(ps+pp) if ps+pp>0 else None),min_reverse_bias_V=lo,peak_load_V=peak)
if __name__=='__main__':
    rows=[run(a,k*pi/2) for a in (0,.5,1.,1.4) for k in (range(1) if a==0 else range(4))]; writer=csv.DictWriter(sys.stdout,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
