"""Disconnect both ideal source ports without interrupting winding current.
Requires python3, numpy, scipy, ngspice. Run from any directory.
Units internal to ODE: V, pC, us, uA, H, pF, pJ.
"""
import csv, subprocess,tempfile
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parent
C=100.; VJ=.7; S=3.; L=2*.0002841633671867732*(1+.999); R=150000.; Rc=5.
def charge(u):return 2*C*u/(1+np.sqrt(1+u/VJ))
def voltage(q):return q/C+q*q/(4*C*C*VJ)
def field(q):return q*q/(2*C)+q**3/(12*C*C*VJ)
def derived(m,n,i):
 A=1/C+m/(2*C*C*VJ);d=n/(1+2*S*A);v=2*A*d
 return d,v,voltage(m-d),voltage(m+d), A*d*d+S*v*v/2+L*i*i/2
def rhs(t,state):
 m,n,i,_,_,_=state;d,v,x,y,D=derived(m,n,i)
 # reverse leakage p->a,b, including the deck's gmin. Forward exponential negligible for the verified reverse biases.
 lx=(1e-12+1e-15)*1e6*x+1e-12;ly=(1e-12+1e-15)*1e6*y+1e-12
 return [-(lx+ly)/2,-i-1e6*v/R-(ly-lx)/2,(v-Rc*i*1e-6)/L,1e6*v*v/R,Rc*1e-6*i*i,x*lx+y*ly]
def save(name,rows):
 with (ROOT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def solve(raw,st,tag,j,rtol,trace=False):
 t,_,ps,p,a,b,_,it,ib=raw;gap=it-ib
 w=gap[j]/(gap[j]-gap[j+1]);at=lambda s:s[j]+w*(s[j+1]-s[j]); m1=charge(at(p-a));m2=charge(at(p-b));m=(m1+m2)/2;n=(m2-m1)/2+S*at(a-b);i=at((it+ib)/2)*1e6
 assert abs(at(gap))<1e-18
 y0=[m,n,i,0.,0.,0.];D0=derived(m,n,i)[4];U0=2*field(m)+D0
 ts=np.linspace(0,80,4001); sol=solve_ivp(rhs,(0,ts[-1]),y0,method='DOP853',rtol=rtol,atol=[1e-12,1e-16,1e-14,1e-17,1e-19,1e-18],t_eval=ts,max_step=.1 if trace else .05)
 assert sol.success
 M,N,I,EL,EC,EG=sol.y;d,v,x,y,D=derived(M,N,I);U=2*field(M)+D
 assert min(x.min(),y.min())>1
 err=U0-U-EL-EC-EG
 if trace:save('trace_'+tag+'.csv',[dict(after_cut_us=t0,load_V=v0,series_uA=i0,load_pJ=e0,differential_pJ=d0,total_pJ=u0) for t0,v0,i0,e0,d0,u0 in zip(ts,v,I,EL,D,U)])
 return dict(deck_step_ns=st,cut=tag,rtol=rtol,cut_us=at(t)*1e6,bias_at_cut_V=at(p),load_at_cut_V=at(a-b),series_at_cut_uA=i,initial_common_pJ=2*field(m),initial_diff_pJ=D0,end_us=ts[-1],end_common_pJ=2*field(M[-1]),end_diff_pJ=D[-1],load_pJ=EL[-1],copper_pJ=EC[-1],leak_pJ=EG[-1],max_balance_error_pJ=np.max(abs(err)),reverse_regime_tail_bound_pJ=D[-1],passivity_tail_bound_pJ=U[-1],min_reverse_V=min(x.min(),y.min()))
def main():
 rows=[]
 for st in ('1','0.5'):
  with tempfile.TemporaryDirectory() as td:
   r=subprocess.run(['ngspice','-b',str(ROOT/('gain_'+st+'ns.cir'))],cwd=td,capture_output=True,text=True);assert r.returncode==0 and 'aborted' not in (r.stdout+r.stderr).lower();raw=np.loadtxt(Path(td)/'trace.dat').T
  t,_,_,p,*_=raw;gap=raw[-2]-raw[-1];inds=np.where((t[:-1]>=299e-6)&(gap[:-1]*gap[1:]<0))[0];assert len(inds)==4
  for tag,j in [('high',max(inds,key=lambda j:p[j])),('low',min(inds,key=lambda j:p[j]))]:
   # Force same signal half-cycle across mesh sizes. Two instances per bias polarity per signal period.
   j=next(j for j in inds if (p[j]>4)==(tag=='high'))
   for tol in (1e-9,2e-11):rows.append(solve(raw,st,tag,j,tol,st=='0.5' and tol==2e-11))
 save('ledger.csv',rows)
 for r in rows: print(r)
if __name__=='__main__':main()
