"""Fixed-geometry dielectric absorption control. SI units. No measured parameters."""
import csv, math, sys
from pathlib import Path
CF, CA, RA = 1e-6, 0.1e-6, 10e6 # fast capacitor, slow capacitor, relaxation resistance

def energy(v,w): return (CF*v*v+CA*w*w)/2

def segment(v,w,T,g,S):
    # CF from terminal v to common; RA from v to hidden w; CA from w to common.
    # Single external conductance g to an ideal source S (0 V for passive loads).
    k=1/RA; a=-(g+k)/CF; b=k/CF; c=k/CA; d=-k/CA
    tr=a+d; delta=math.sqrt((a-d)**2+4*b*c); fast=(tr-delta)/2; slow=(g*k/(CF*CA))/fast
    x,y=v-S,w-S; fx=((a-slow)*x+b*y)/(fast-slow); fy=(c*x+(d-slow)*y)/(fast-slow)
    def state(t):
        f=math.exp(fast*t); h=math.exp(slow*t);return S+fx*f+(x-fx)*h,S+fy*f+(y-fy)*h
    # Each voltage difference has the form A exp(fast*t) + B exp(slow*t).
    def integral(rate): return T if rate==0 else math.expm1(rate*T)/rate
    def area(A,B): return A*integral(fast)+B*integral(slow)
    def square_area(A,B): return A*A*integral(2*fast)+2*A*B*integral(fast+slow)+B*B*integral(2*slow)
    source=-S*g*area(fx,x-fx)
    series_heat=g*square_area(fx,x-fx)
    relaxation_heat=k*square_area(fx-fy,(x-fx)-(y-fy))
    return (*state(T),source,series_heat,relaxation_heat)

def main():
    v=w=0.; rows=[]
    phases=[('charge',10.,1/10000,5.),('brief_short',0.015,1/1000,0.)]
    phases+=[(name,T,g,0.) for _ in range(4) for name,T,g in [('recover_open',4.,0.),('load',0.05,1/10000)]]
    phases.append(('reset_dump',100.,1/10000,0.)) # remaining energy disposed, not useful output
    for i,(name,T,g,S) in enumerate(phases):
        v0,w0=v,w; v,w,source,external_heat,relax_heat=segment(v,w,T,g,S); U0=energy(v0,w0); U1=energy(v,w)
        residual=source+U0-U1-external_heat-relax_heat
        assert abs(residual)<1e-12, (i,residual)
        rows.append(dict(step=i,phase=name,duration_s=T,start_terminal_V=v0,end_terminal_V=v,end_hidden_V=w,start_stored_J=U0,end_stored_J=U1,source_J=source,load_J=(external_heat if name=='load' else 0.),charge_short_or_reset_loss_J=(0. if name=='load' else external_heat),dielectric_loss_J=relax_heat,balance_error_J=residual))
    with Path('recovery.csv').open('w',newline='') as f:
        cw=csv.DictWriter(f,fieldnames=rows[0]);cw.writeheader();cw.writerows(rows)
    for r in rows:print(r['phase'], 'terminal mV %.7g; hidden mV %.7g; load nJ %.7g; remaining nJ %.7g; balance error pJ %.3g'%(1000*r['end_terminal_V'],1000*r['end_hidden_V'],1e9*r['load_J'],1e9*r['end_stored_J'],1e12*r['balance_error_J']))
if __name__=='__main__':main()
