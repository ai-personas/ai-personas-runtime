# Can voltage come back after a short, with no new input?

Yes. In this fixed-electrode model, a terminal that reads 0.495 mV after a brief short rises to 443 mV after opening the circuit. Yet during that rise the energy in the two capacitors **falls**, from 1,215 nJ to 111 nJ. A voltage rising at one accessible terminal is not a measurement of increasing total energy.

## What is modeled

This is a conventional lumped model of dielectric absorption, independent of the Exodus article and of the dimensions of the issued PCB. It is not a fit to either. A 1 µF capacitor from the terminal to common is in parallel with a series branch consisting of 10 MΩ from terminal to a hidden node and 0.1 µF from that node to common. The hidden capacitor models delayed polarization. Call the two voltages v and w. The source voltage S is connected to v through conductance g in each phase; g=0 means open circuit. Starting voltages are zero.

```
C_fast dv/dt = g(S-v) - (v-w)/R_slow
C_slow dw/dt = (v-w)/R_slow
U = (C_fast v² + C_slow w²)/2
P_source = S g(S-v)
dU/dt = P_source - g(S-v)² - (v-w)²/R_slow
```

The last two terms are resistor heat. Only the designated load intervals count as useful output. Different resistances are used for charge, short and load; the final dump is a reset cost, not another load. The model switches ideal connections and assumes no switch energy or added charge. The initial charge phase uses 5 V through 10 kΩ. After that phase there is no powered feed. The short is 1 kΩ; each load is 10 kΩ. Recoveries are open circuit. The reset uses 10 kΩ. Times and endpoints are below.

| Phase | Duration (s) | Terminal at end (mV) | Hidden node at end (mV) | Useful load (nJ) |
|---|---:|---:|---:|---:|
| charge | 10 | 5000 | 4999.77 | 0 |
| brief_short | 0.015 | 0.494998 | 4930.27 | 0 |
| recover_open | 4 | 443.154 | 503.678 | 0 |
| load | 0.05 | 3.45524 | 483.357 | 98.3098 |
| recover_open | 4 | 46.547 | 52.439 | 0 |
| load | 0.05 | 0.36248 | 50.3271 | 1.08458 |
| recover_open | 4 | 4.84896 | 5.46239 | 0 |
| load | 0.05 | 0.0377604 | 5.24241 | 0.01177 |
| recover_open | 4 | 0.505102 | 0.569001 | 0 |
| load | 0.05 | 0.00393339 | 0.546086 | 0.000127713 |
| reset_dump | 100 | 2.2677e-47 | 2.24731e-44 | 0 |

The first load receives 98.31 nJ; the second gets 1.085 nJ. Including all four, 99.406 nJ reaches the load (0.3615% of the 27.500 µJ startup input). The rest is accounted for: 25.015 µJ of non-load external resistor heat, 2.386 µJ of internal relaxation heat, and negligible final stored energy (numbers rounded). Briefly making v nearly zero did not reset w. Extending the open interval redistributes the remaining charge; it cannot recharge both capacitors to their original charged state.

## Relation to the reported propulsion concept

[US20230121805A1, *System and method for generating forces using asymmetrical electrostatic pressure*](https://patents.google.com/patent/US20230121805A1/en), description [0181] (HTML anchor `p-0215`), places different dielectric materials **in space** between electrodes and attributes a force to that arrangement. Paragraph [0190] (`p-0224`) says “The applied electrode voltages, or the external electric fields, may be time varying”; [0204] (`p-0232`) explicitly allows an external field source. Those passages concern the claimed force. They do not report that permittivity varies on its own in time to deliver electrical work through a restored cycle. At a stationary support even a sustained force has zero mechanical power, F·v. None of that precludes an ordinary electrical discharge or transfer between electrical ports.

There are three distinct questions. (1) **Passive recovery:** does the load run briefly as hidden stored energy falls? This example says yes. (2) **Pumped transfer:** does load power exceed a small signal input because a second source modulates a parameter? Count signed work at the pump as well as the signal port; this model has no pump. (3) **Sustained surplus:** after restoring all internal stores, can a sole 10 W feed sustain 20 W at the load? The deficit is at least 10 J each second, plus losses. A passive memory only changes how long a finite store can be drawn down. To evaluate an actual surplus requires existing same-device synchronized port records, including auxiliaries, with uncertainty bounds on both power and changes in stored energy. A terminal voltage alone cannot supply the latter bound if polarization has memory.

## Reproduce the numbers

Extract all files together and run in that directory:

```
python3 recovery.py
python3 independent.py
```

The first command uses Python 3's standard library and writes `recovery.csv`, one row per phase with voltages in V, durations in s and energies in J. The second requires SciPy and consumes that CSV, checking both voltages and each energy term by integrating the circuit and power equations with Radau. The largest energy-term difference in the checked run was 4.51e-19 J. For a changed circuit, revise the constants in **both** solvers before interpreting agreement or disagreement. Both solve the same physical assumptions; agreement is not validation on hardware. No construction or powered test is authorized.
