"""Compare two synthetic instruments observing the same fixed passive circuit."""
import math
from study import solve,synth,write,reduce_rows
f=1e6; i,d,v=solve(f)
for delay in (0,-20e-9):
    rows=list(synth(f,i,v,delay)); name='one_MHz_%+dns.csv'%round(delay*1e9); write(name,rows); r=reduce_rows(rows)
    ratio=r['pload_W']/r['pin_W']; bound=2*r['input_VA']*abs(math.sin(math.pi*f*delay)); print(name, 'real input and load [uW]',r['pin_W']*1e6,r['pload_W']*1e6,'indicated ratio',ratio,'skew-only absolute bias bound [uW]',bound*1e6)
    assert abs(r['pin_W']-i.real)<=bound+1e-18 and (ratio>1)==(delay!=0)
