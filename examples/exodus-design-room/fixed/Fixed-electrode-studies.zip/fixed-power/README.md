# Can a timing error make a fixed passive board look like a generator?

Use Python 3, standard library only. From this directory run:

```
python3 study.py
python3 skew_example.py
python3 meter.py one_MHz_+0ns.csv
python3 meter.py one_MHz_-20ns.csv
```

Only the input-current timestamps **as interpreted by the meter** differ between those last two files: both label each row with the voltage timestamp, but the second supplies input current sampled 20 ns later. The physical circuit and load are unchanged. At 1 MHz this is 7.2° of phase error. Compare `pin_W` against `pload_W`; an apparent excess on the second record is spurious. These files contain generated samples, not instrument readings.

## Power boundary

IN is a 1 V RMS ideal sine source referred to COM. The board has 1 kΩ from IN to DRIVE, 1 MΩ from DRIVE to COM, and 100 kΩ from PICKUP to COM (the useful load). The fixed coupling capacitance is ε₀ × 4.1 × 432 mm² / 1.53 mm; each electrode also has 3 pF to COM. These are model inputs, not calibrated values. In steady periodic operation capacitors return to their initial energy each period. The input real power therefore equals heat in **all three** resistors, not just the useful load. `study.py` checks this independently of the waveform averaging. Neither a static force nor a nonzero AC voltage is a supply of continuous load power.

## Data interface and interpretation

`meter.py <csv>` reads t_s, vin_V, iin_A, vload_V, iload_A (seconds, volts, amperes). Positive input current enters the device; positive load current enters the load at its positive terminal. Samples represent consecutive equal-duration bins over a half-open record: do not duplicate the periodic endpoint. The means of the signed simultaneous voltage–current products are watts. Vrms × Irms is VA and generally differs from watts. `load_minus_input_J` is the indicated difference integrated over the window, not a claim about an energy source. Sampled instantaneous values approximate a continuous average only with adequate bandwidth, rate and window selection; the meter cannot detect hidden aliasing or a wrong timestamp.

For a single sine with true relative phase φ, a current delay τ rotates its phasor by −2πfτ. The absolute watt error is at most 2 Vrms Irms |sin(πfτ)|. For a bounded but unknown small delay use the maximum over its allowed interval, not the sine at an arbitrary upper endpoint. This bound alone does not cover offset, gain, probe loading, harmonics, leakage or common-mode error. Assess frequency-dependent gain and channel delay on the actual instrument chain; no calibration has been supplied here.

For the 10 W / 20 W target meter *all* external feeds, including driver and controller supplies. If IN is an internal port do not count it as a second external supply. Record signed energy at the useful load and changes in recoverable energy of battery, field and other stores through reset. A discharging capacitor can deliver output with zero contemporaneous input; the ratio in that interval is undefined, not infinite measured gain. A finite steady-looking trace does not establish indefinite operation. Digital analysis only; no fabrication or energized experiment is requested.

## Check against the circuit designer’s frequency sweep

Run `python3 crosscheck.py` to compare synchronous time-domain averages against `reference_ac.csv` (a snapshot of Eli’s `fixed-field-eli/model/ac.csv`). Or pass a replacement CSV path. The comparison uses the designer's input and useful-load watt columns at every listed frequency. Agreement checks port conventions and numerical reduction under shared nominal assumptions, not the physical component values. At 1 MHz the aligned synthetic traces give 7.992 µW in and 5.812 µW out. A 20 ns advance on the input-current channel alone indicates 3.714 µW in: the false ratio is 1.565 rather than 0.727.
