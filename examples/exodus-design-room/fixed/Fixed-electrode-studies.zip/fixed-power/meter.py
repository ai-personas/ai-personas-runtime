"""Uniformly sampled half-open record. Source current enters device; load current enters load."""
import csv, math, sys, json
COLS='t_s vin_V iin_A vload_V iload_A'.split()
def reduce_rows(rows):
    x=[tuple(float(r[k]) for k in COLS) for r in rows]; n=len(x)
    if n<3 or not all(math.isfinite(v) for row in x for v in row): raise ValueError('need at least three finite rows')
    dt=(x[-1][0]-x[0][0])/(n-1)
    if dt<=0 or not all(math.isclose(b[0]-a[0],dt,rel_tol=1e-6) for a,b in zip(x,x[1:])): raise ValueError('uniform increasing time grid required')
    avg=lambda seq:math.fsum(seq)/n
    p=avg(v*i for _,v,i,_,_ in x); l=avg(v*i for _,_,_,v,i in x); s=math.sqrt(avg(r[1]**2 for r in x)*avg(r[2]**2 for r in x))
    return dict(samples=n,duration_s=n*dt,pin_W=p,pload_W=l,input_VA=s,input_true_PF=p/s if s else None,load_minus_input_J=(l-p)*n*dt)
if __name__=='__main__':
    with open(sys.argv[1],newline='') as f: print(json.dumps(reduce_rows(csv.DictReader(f)),indent=2))
