import cmath, csv, math
from meter import reduce_rows,COLS
R1,R2,R3=1e3,1e6,1e5
Cm=8.8541878128e-12*4.1*432e-6/1.53e-3
Cs=3e-12
def solve(f):
    jw=2j*math.pi*f; yc=jw*Cm; yp=1/R3+jw*Cs
    # Series Cmut and parallel pickup load; combine with direct drive shunt
    yd=1/R2+jw*Cs+yc*yp/(yc+yp); i=yd/(1+R1*yd); d=1-R1*i; v=d*yc/(yc+yp)
    return i,d,v
def synth(f,i,v,delay=0,n=2048):
    for k in range(n):
        z=math.sqrt(2)*cmath.exp(2j*math.pi*k/n); h=cmath.exp(-2j*math.pi*f*delay)
        yield dict(zip(COLS,(k/(n*f),z.real,(i*h*z).real,(v*z).real,(v*z).real/R3)))
def write(path,rows):
    with open(path,'w',newline='') as out:
        w=csv.DictWriter(out,fieldnames=rows[0]); w.writeheader(); w.writerows(rows)
if __name__=='__main__':
    res=[]
    for f in [100,1000,10000,100000,1e6]:
        i,d,v=solve(f); p=i.real; l=abs(v)**2/R3; losses=abs(i)**2*R1+abs(d)**2/R2; assert math.isclose(p,l+losses,rel_tol=1e-12)
        for ns in [-100,-10,0,10,100]:
            rows=list(synth(f,i,v,ns*1e-9)); rr=reduce_rows(rows); apparent=(i*cmath.exp(-2j*math.pi*f*ns*1e-9)).real
            assert math.isclose(rr['pin_W'],apparent,rel_tol=1e-12,abs_tol=1e-17) and math.isclose(rr['pload_W'],l,rel_tol=1e-12)
            res.append(dict(f_Hz=f,delay_i_ns=ns,pin_true_W=p,pload_W=l,loss_W=losses,pin_indicated_W=rr['pin_W'],pf_true=p/abs(i),input_VA=abs(i)))
            if f==100000 and ns in (0,-100): write('example_%+dns.csv'%ns,rows)
        print(f,p,l,p/abs(i), 'efficiency',l/p)
    write('phase_sweep.csv',res)
    for i,p in [(1,1),(1j,0),(-1,-1),(.01+1j,.01)]: assert math.isclose(reduce_rows(synth(10,i,0))['pin_W'],p,abs_tol=1e-12)
    rows=list(synth(10,1,0)); n=len(rows)
    for k,r in enumerate(rows):
        a=2*math.pi*k/n; r['vin_V']+=math.sqrt(2)*.3*math.cos(3*a); r['iin_A']+=math.sqrt(2)*.2*math.cos(3*a+.4)
    assert math.isclose(reduce_rows(rows)['pin_W'],1+.06*math.cos(.4),rel_tol=1e-12)
    print('PASS: unity, quadrature, negative flow, low PF, harmonic real power, 25 delayed cases, and five resistor balances')
