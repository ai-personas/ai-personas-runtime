from pathlib import Path
import json,math
j=json.loads(Path('inputs/geometry.json').read_text()); f=1e6; w=2j*math.pi*f
for area in (432.0,433.2):
 C=8.8541878128e-15*j['epsilon_r']*area/j['dielectric_mm']; ys=w*C; yl=1/j['load_ohm']; yb=yl+w*j['pickup_shunt_pF']*1e-12
 yin=1/j['bleed_ohm']+w*j['drive_shunt_pF']*1e-12+ys*yb/(ys+yb); U=j['sine_rms_V']; vd=U/(1+j['series_ohm']*yin); vp=vd*ys/(ys+yb); I=vd*yin
 pin=(U*I.conjugate()).real; pl=abs(vp)**2*yl; loss=abs(I)**2*j['series_ohm']+abs(vd)**2/j['bleed_ohm']; assert abs(pin-pl-loss)<1e-17
 print(f'{area:.1f} mm2 | {C*1e12:.6f} pF | {pin*1e6:.6f} uW in | {pl*1e6:.6f} uW load | ratio {pl/pin:.6f}')
