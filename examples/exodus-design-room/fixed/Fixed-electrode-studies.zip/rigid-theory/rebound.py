#!/usr/bin/env python3
"""Synthetic fixed-geometry dielectric absorption control; SI units throughout.
C0 (v) in parallel with series Ra,Ca (u); first short, then open, then load.
Solve both state voltages by analytic propagation on each constant-R segment.
Heat is integrated independently by Simpson's rule, not backed out as residual.
"""
import csv, math, argparse
from pathlib import Path
C0,Ca,Ra=1e-6,.2e-6,10e6
V0=5.0

def propagate(v,u,r,t):
    # dv/dt = -a*v + b*u; du/dt = c*v - c*u
    g=0 if math.isinf(r) else 1/r
    b=1/(Ra*C0); c=1/(Ra*Ca); a=b+g/C0
    fast=-.5*(a+c+math.sqrt((a-c)**2+4*b*c))
    slow=(g/C0*c)/fast # det/lambda_fast avoids cancellation
    ef,es=math.exp(fast*t),math.exp(slow*t)
    def next_(x,dx):
        s=(dx-fast*x)/(slow-fast);return s*es+(x-s)*ef
    return next_(v,-a*v+b*u),next_(u,c*(v-u))

def stored(v,u):return .5*(C0*v*v+Ca*u*u)

def run(path):
    v=u=V0; start=stored(v,u); losses=0.; budget={}; t0=0.
    with open(path,'w',newline='') as f:
        w=csv.writer(f);w.writerow(['phase','t_s','terminal_V','hidden_V','stored_J','branch_heat_cum_J','external_resistor_heat_cum_J']);qint=qext=0.
        for phase,r,dur,n in [('short',1e3,.015,600),('open',math.inf,10.,400),('load',1e6,20.,1000)]:
            h=dur/n;sv,su=v,u;qi0,qe0=qint,qext
            for k in range(n+1):
                v,u=propagate(sv,su,r,k*h)
                if k:
                    mid=propagate(sv,su,r,(k-.5)*h); pi=lambda x:(x[0]-x[1])**2/Ra;pe=lambda x:0. if math.isinf(r) else x[0]**2/r
                    for fn,i in [(pi,0),(pe,1)]:
                        heat=h/6*(fn(prev)+4*fn(mid)+fn((v,u)))
                        if i:qext+=heat
                        else:qint+=heat
                w.writerow([phase,t0+k*h,v,u,stored(v,u),qint,qext]);prev=(v,u)
            budget[phase]=(v,u,qint-qi0,qext-qe0);t0+=dur
    residual=start-stored(v,u)-qint-qext
    for phase,(vv,uu,qi,qe) in budget.items():print(f'{phase}: end terminal {vv:.8f} V; hidden {uu:.8f} V; internal heat {qi*1e6:.8f} uJ; resistor heat {qe*1e6:.8f} uJ')
    print(f'precharged energy {start*1e6:.8f} uJ; final {stored(v,u)*1e6:.8f} uJ; balance residual {residual:.3g} J')
    assert abs(residual)<1e-12 and budget['open'][0]>budget['short'][0] and budget['load'][3]>0
    # No external charge enters during open interval. Terminal voltage approaches charge-weighted mean.
    s=budget['short'];o=budget['open'];q=lambda p:C0*p[0]+Ca*p[1];assert abs(q(s)-q(o))<1e-16 and abs(q(s)/(C0+Ca)-o[0])<.003
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--csv',type=Path,default=Path('rebound.csv'));run(p.parse_args().csv)
