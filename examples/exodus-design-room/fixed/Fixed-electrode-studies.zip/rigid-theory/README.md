# Can a stationary Exodus article power an electrical load?

**Finding:** A persistent force and a persistent supply of electrical energy are different claims. Even if the reported force is real, it supplies no mechanical power at a fixed point of application. An all-static generator is possible with an energy input (a photovoltaic cell is one example); the relevant question here is whether the charged device has such a port in addition to its 10 W electrical feed. The examined Exodus reports do not identify one with a measured power rating. We cannot specify a 20 W continuous generator on that basis.

## What the sources actually connect

| Source and locator | Reported quantity or proposal | Missing link to terminal power |
|---|---|---|
| [US 2023/0121805 A1](https://patents.google.com/patent/US20230121805A1/en), Figs. 21–23 and accompanying description | Shaped electrodes are proposed to generate net force from asymmetric electrostatic pressure. Fig. 22 labels two +25 kV intervals of the encapsulated epoxy test at 220 and 255 µN. | Force versus **time**, not a load V–I trace. Its time integral has units of impulse, not joules. A voltage command going low is not proof that both leads are isolated or the dielectric depolarized. |
| [Plain, *The Debrief*, April 19 2024](https://thedebrief.org/physics/nasa-veterans-propellantless-propulsion-drive-that-physics-says-shouldnt-work-just-produced-enough-thrust-to-defeat-earths-gravity), “Understanding the Physics is a Job for Science” | Buhler is quoted describing articles on a scale for days and associating thrust with retained charge. This is a published interview account. | Charge retention under little or no load is not charge replenishment under load. This is not a later segment of the patent run. |
| [Ventura, *Exodus Propellantless Propulsion Physics*, Aug. 2 2025](https://www.altsci.net/exodus-propellantless-propulsion-physics/), “The Third Order” / “Beyond Coulomb” | The host describes a proposed recoil of material particles with opposite momentum carried by the electromagnetic field. [Exodus](https://www.ept.space/) also describes a vacuum/background reaction in its *Mini White Paper*, pp. 1–2; energy applications there are prospective. | Assigning opposite **momentum** to a field is not specifying an inward flux of **energy**, its couplings to output terminals, or its behavior as the load draws current. These are attributed hypotheses, not independently established power laws. |

Ordinary surface pressure can be unequal on different faces; the net force concerns all material and field momentum and stresses crossing the chosen boundary. A bench, grounded enclosure or field can be a momentum partner. It does not follow that a stationary support supplies watts. Conversely, a fixed assembly *could* receive electrical or electromagnetic energy from outside while not moving; that energy belongs on the input side. Do not substitute the nominal plate-to-plate voltage for every conductor's potential relative to the enclosure.

## Two equations a proposed device has to satisfy

1. **Terminal law.** Choose a reference conductor. For stationary linear conductors in a time-independent passive dielectric, write the vector of free electrode charges as `q = C v + q₀`, with a symmetric, reduced capacitance matrix and a fixed polarization offset `q₀`. Current into the capacitive ports is `i = C dv/dt`. Thus `vᵀi = d(½ vᵀ C v)/dt`. Asymmetry changes entries of C, not this identity. Leakage adds dissipation. An AC drive can transfer *real* power to a resistor through a coupling capacitor; the drive supplies it. Measure average instantaneous products ⟨v(t)i(t)⟩, not a sum of apparent volt-amperes. At constant DC voltages the capacitive currents stop. A constant offset charge cannot push charge around a closed circuit indefinitely.
2. **Energy balance.** At fixed geometry `P_mech = F·dx/dt = 0`. Let `U` include field, internal polarization, battery, buffer and other accounted stores. Let `P_loss` be nonnegative exported/dissipated power not delivered to the useful load (do not count a heat term twice). Then `P_load = P_feed + P_other − P_loss − dU/dt`. At 20 W load and 10 W feed with restored stores, average `P_other = 10 W + P_loss`. In one hour, even the lossless deficit is **36 kJ = 10 Wh**. With a finite store and no other input, duration is bounded by available stored joules divided by 10 W, shorter with losses. With the startup feed removed entirely and 20 W still delivered, that denominator is at least 20 W. A ratio to a zero instantaneous input is not a generator efficiency.

A candidate microscopic theory could introduce a state `s` and `q(v,s)`; now `i = (∂q/∂v)·dv/dt + (∂q/∂s)·ds/dt` before conduction terms. This is a testable extension only after specifying an **evolution law**, geometry, material, initial state, predictions under load, work exchanged with `s`, its exhaustion or means of restoration, and bounds on parameters. A rectifier may steer such transient currents but cannot pay their reset cost. Even real time-varying polarization, temperature, capacitance or conduction need not represent a new energy source. For example, if a separate actuator varies C in a lossless capacitor, `vi − d(½Cv²)/dt = ½v² dC/dt`; omitting the actuator's energy exchange would give the wrong boundary. Here no mechanical motion or actuator is proposed. Adding an ideal current source adjusted until the output reads 20 W simply *stipulates* the missing power.

## A quantitative counterexample: voltage comes back with no moving parts

`rebound.py` is a separate dielectric-absorption model, **not a parameter estimate for Exodus or the companion PCB**. A 1 µF prompt capacitance C₀ is in parallel with a series 10 MΩ / 0.2 µF polarization branch. The terminal voltage is v, the slow capacitor voltage is u. Both start at 5 V, storing 15 µJ. No power source is attached thereafter. The external termination changes from a 1 kΩ discharge resistor (15 ms), to open (10 s), to a useful 1 MΩ load (20 s). These are ideal boundary conditions in software, not measured switch actions.

| End of interval | Terminal v | Hidden u | Heat in that interval's external resistor |
|---|---:|---:|---:|
| Brief discharge | 0.000498 V | 4.9651 V | 12.5013 µJ, discarded |
| Open | 0.82589 V | 0.83819 V | 0 |
| Loaded | 0.0000388 V | 0.000262 V | **0.367385 µJ**, useful |

The external charge is constant in the open interval: `C₀v + Cₐu = constant`. Internal redistribution raises v while dissipating **2.054 µJ** in the branch resistor. Adding the 0.367 µJ at the useful load does not raise output above the initial 15 µJ. Across all phases the two resistor heats plus the final stored energy reproduce the start energy to within 3×10⁻¹⁴ J for the supplied integration grid. Under a renewed identical load cycle one must pay to restore *both* capacitor voltages. A recovered voltage after a brief short is therefore an ambiguous signature even in a perfectly rigid device.

Reproduce with Python 3 (standard library) from this directory:

```
python3 rebound.py --csv rebound.csv
python3 check.py
```

Open `rebound.svg` for terminal and polarization voltages before and after loading; the three panels use separate time scales. `rebound.csv` is SI throughout. Heat columns are cumulative across intervals; phase boundaries repeat a timestamp with the same state. `check.py` compares the trace against independently stepped circuit equations and integrates resistor heat from the voltages. All numbers are synthetic.

## What would change the finding?

For an existing rigid-device run, identify every electrical port (including instrumentation, return paths and any oscillator), the load and the isolation state. Supply synchronized, calibrated voltage and signed current, bandwidth, relative phase uncertainty and a lower bound on load power over the stated duration. Include battery and field/polarization changes, leakage, thermal or environmental inputs and how those bounds were established. Compare with a passive dummy, source removed, matched reversed geometry, varied load and repeated restored cycles. A bounded excess beyond uncertainties merits investigation of omitted ports and mechanisms; it does not by itself identify vacuum energy or prove indefinite operation. Steady 20 W power, net energy over a whole reset cycle, and force have separate acceptance criteria. The present package supplies a calculation and a falsifiable distinction, not a physical test or permission to perform one.

See [the fixed-board comparison](FIXED-BOARD.md) for the nominal isolated and AC-driven load results and the corresponding field-energy boundary.
