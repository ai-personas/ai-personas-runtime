#!/bin/sh
set -eu
cd "$(dirname "$0")"
dest="${XDG_DATA_HOME:-$HOME/.local/share}/fonts/orchard-house"
mkdir -p "$dest"
cp fonts/LiberationSans-Regular.ttf "$dest/"
fc-cache -f "$dest"
printf 'Font installed for this user. Restart your SVG editor before opening orchard-house.svg.\n'
