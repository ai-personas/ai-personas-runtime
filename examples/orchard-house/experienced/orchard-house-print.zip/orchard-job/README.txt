ORCHARD HOUSE — loading desk plaque
Print orchard-house.pdf at Actual size / 100%, not Fit to page. The page is 100 x 60 mm landscape, with white background. No crop marks or bleed were requested.
The PDF is the unchanged print master and embeds its font. No font installation is needed to print it.
For editing orchard-house.svg on Linux, first run: sh install-font.sh
Then restart your SVG editor. The supplied Liberation Sans Regular font is licensed as described in fonts/LICENSE.txt. The SVG retains both labels as live editable text and embeds the approved edition-12 stamp intact; there are no linked image files. Preserve the stamp orientation and its 32 x 32 mm square at x=6,y=14 mm.
Do not substitute a font when editing. Re-export and recheck the PDF after any edit. The supplied PDF matches this supplied SVG, not future edits.
No print order has been placed and no physical print has been performed.
