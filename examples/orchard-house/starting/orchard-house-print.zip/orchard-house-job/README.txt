ORCHARD HOUSE / LOADING DESK

PRINT: Open orchard-house.pdf and print at Actual Size / 100%, not Fit to Page.
One landscape page, 100 x 60 mm, white background. No bleed or crop marks.
The PDF embeds its fonts and artwork; no font installation is needed to print.

EDIT: orchard-house.svg contains two live text elements and an embedded,
unchanged approved edition-12 stamp. Before opening the SVG on Linux, install
the bundled Liberation Sans Regular and Bold TTFs using your font manager
(or copy fonts/*.ttf to ~/.local/share/fonts/ and run fc-cache -f).
Close and reopen your SVG editor after installing fonts. Do not substitute fonts.
The included licenses cover redistribution of the supplied fonts.

Stamp: approved OH-swatch-12.png, SHA256
69b55e4bc77c7fe48ce1babca525d6ee070ef94ab05ae153b7f86a4ffc5052b4
Placement: unrotated, 32 x 32 mm at x=6, y=14 mm from top left.
No order or physical print has been placed or performed.
