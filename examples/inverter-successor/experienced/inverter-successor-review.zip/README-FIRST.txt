LOW-VOLTAGE BENCH INVERTER — successor prototype release
Recipient: Prototype shop / JLCPCB. Requested quantity: FIVE fully assembled boards.
No order, payment, or physical build has been authorized or performed.

SUPPORTED USE AND RELEASE LIMIT
This is a fabrication/assembly review edition, not an unconditionally production-qualified order. The board requires supplier process confirmation for six thermal vias under U1 exposed-pad paste. Confirm a suitable filled/capped via process or explicitly qualified assembly process before manufacturing. This is a process compatibility question, not a request to resolve component choices. If the supplier cannot support the supplied geometry, do not silently fabricate it as ordinary open vias or edit the CAD: return the process rejection for a revised edition.
Parts are fixed in Assembly/BOM.csv, including BOTH through-hole terminal blocks J1/J2; populate all 18 references. Use Assembly/CPL.csv with metric coordinates, top side, positive counterclockwise rotations. Include through-hole insertion/soldering; this is not an SMT-only order. Supplier stock in the frozen library is not a reservation or current quote. Confirm availability without substitution. Request five complete assembled prototypes, not five bare boards. Use the supplied fabrication layers and drill files; editable CAD is also included. Review component orientation against board pad numbers and assembly documentation before approval.

BENCH CONDITIONS
Low-voltage isolated bench supply only. No mains, grid connection, transformer output, or safety-rated isolation claim. Apply regulated 12.0 V measured at board VM using a current-limited supply capable of at least 1 A; verify connector polarity in the schematic/board before power. Load: 27 ohm resistor rated at least 10 W between the TWO floating bridge outputs. Neither output is ground. Do not connect an earth-referenced scope ground to either output; use an appropriate differential measurement. No reactive load qualification is claimed.
Nominal calculated output is approximately 5.1 W at approximately 49.4 Hz square wave with this source/load; switch loss and tolerances affect actual power. This is not measured 5 W delivery or a sine-wave inverter. Verify frequency, RMS load voltage, input current and thermal behavior on the first assembled prototype before extended operation. The resistor can become hot. Power off before wiring. Do not reverse the supply.

LIMITATIONS
No physical build, thermal test, EMC test, or supplier acceptance has occurred. Digital checks establish only their stated scope. Do not interpret CAD opening, DRC, or a successful export as electrical or manufacturing certification. The process limitation above prevents claiming a fully confirmed orderable production release.
