# Low-voltage bench inverter — successor prototype review edition

**Five complete JLCPCB prototypes are the intended order, but this edition is NOT approved for unchanged assembled ordering.** Exact connector mechanical compatibility remains unresolved. No order, payment or physical build has been initiated.

## Intended source and load
Use an isolated, correctly polarized, current-limited nominal 12.0 V DC bench source, measured at J1. No onboard fuse or reverse-polarity protection is provided. Output at J2 is an unregulated bipolar square wave, approximately 49.41 Hz nominal, not galvanically isolated from input. Never connect to mains/grid or ground either output with a scope clip. Use differential measurement.

The 5 W bench target assumes a measured 27 ohm resistive load rated at least 10 W and 12.0 V at the board. Achieving 5 W requires at least 11.619 V RMS across that load and total effective series resistance no greater than 0.8855 ohm. This is a conditional engineering target, not a demonstrated or guaranteed rating. Driver datasheet resistance at 24 V/25 C does not establish worst-case hot-board losses at 12 V. Measure true differential RMS voltage, load resistance and temperature; compute P=Vrms^2/R. Startup, overload, waveform and sustained thermal behavior remain untested. Supply/load tolerance can defeat 5 W even before losses.

## Included files and supported use
- design/: editable KiCad 9 project with project-relative symbol/footprint libraries.
- fabrication/: Gerber and drill exports for the candidate board.
- assembly/: complete 18-reference BOM/CPL including two THT connectors, with process and coordinate instructions.
- verification/: scoped digital checks and independent review; historical reports are not current certification.

The design supports review, editing and supplier quotation/DFM evaluation. It does not yet support a claim that five fully populated boards can be ordered unchanged. See assembly/SOURCING-GAPS.md and ASSEMBLY.md.

## Remaining release gates
C474881 / Cixi Kefa KF301-5.0-2P requires exact mechanical evidence for pitch, hole fit, outline and placement datum. A DORABO DB128L-5.08 drawing is not that evidence. Separately, JLCPCB must accept the included through-hole manualWeld process for J1/J2; catalog metadata is not order acceptance or stock confirmation. Do not omit connectors to describe this request as complete.

## Electrical evidence and limitations
R4=820 ohms supplies the L7805 minimum load: at 4.8 V and maximum 1% resistance it draws 5.80 mA. Selected timing C6 is 100 nF X7R, 10%, not a precision 5% timing part. Initial RC-only frequency range is about 44.48–55.46 Hz; temperature, bias, aging and IC errors add uncertainty. DRV8871 current threshold is approximately 0.909–1.063 A before resistor tolerance; it is not a board fault-safety guarantee. See the independent successor electrical review.

## Editing
Use the routed board as layout authority. Do not run build.py or assembly_docs.py: these historical generators can overwrite current work or restore stale claims. Re-export and refresh checks after edits. Manufacturing geometry, component identity, supplier process acceptance and physical qualification are separate questions.
