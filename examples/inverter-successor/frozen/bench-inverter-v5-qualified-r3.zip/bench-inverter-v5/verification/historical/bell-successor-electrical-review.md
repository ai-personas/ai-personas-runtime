# Successor electrical review — independent, provisional

This review is not a physical test or procurement authorization. Current board SHA256: `1c87d23dcd094a2df117cb1aa392f8bc8bef6ec75f2dbeef024d058ee3b1bb54`. Historical engineering-bom.csv and bell-corrective-review.md do not establish the successor purchasing identities.

## Power and safe use
At exactly 12.0 V input, a 27 ohm resistive load needs 11.619 V RMS for 5 W. The total allowable effective series resistance is 0.8855 ohm (bridge, board, source leads and contacts combined). An ideal bridge would deliver 5.333 W. DRV8871 data give typical combined on-resistance 565 milliohm, with 680 milliohm maximum specified under the datasheet 24 V/25 C conditions, not a guaranteed 12 V hot-board loss limit. Thus 5 W is a plausible bench target, not a guaranteed tested output rating. Use a >=10 W rated 27 ohm load and measure differential RMS voltage and temperature; compute real load power as Vrms squared / measured resistance. State voltage at board input, not merely the supply setting.

Use an isolated, correctly polarized, current-limited low-voltage bench supply only. Output is bipolar square wave and is not galvanically isolated from input. Never connect to mains/grid. Never ground either output using a scope ground clip. Startup, overload, prolonged thermal operation and load regulation have not been physically validated.

## Manufacturer-linked findings
The supplied L78 documentation specifies a minimum load of 5 mA for its characterized regulation range. The current 18-reference design includes R4 = 820 ohms, 1%, from +5V to GND. At 4.8 V with maximum resistance 828.2 ohms it draws 5.80 mA, exceeding the 5 mA minimum independently of logic consumption. At 5.2 V and minimum resistance 811.8 ohms its dissipation is 33.3 mW. At nominal 12 V input and 5 V output the bleeder contributes approximately 42.7 mW regulator loss; internal quiescent loss is additional. This resolves the previously identified minimum-load design gap, subject to the final BOM actually populating R4.
DRV8871 ILIM constant range 59–69 kV with 64.9 kohm nominal gives approximately 0.909–1.063 A before resistor tolerance. This is a current-limit threshold, not a promise of safe connector or board fault operation.
10 kohm / 68 kohm / 100 nF TLC555 oscillator followed by divide-by-two gives approximately 49.41 Hz nominal, 44.48–55.46 Hz from 1% resistor and 10% initial capacitor tolerances alone. Selected C6 is C1711 / CL21B104KBCNNNC, X7R, not a 5% timing capacitor. Temperature dependence (X7R), DC bias, aging, and IC errors add uncertainty beyond this initial-tolerance calculation; no full environmental frequency bound is established. No precision 50 Hz claim is supported.

## Assembly release gates
JLCPCB supplier acceptance of through-hole connectors must be established separately from a library match. A manualWeld process must be carried through the assembly instructions. The numeric assembly field is not interpreted here as an availability Boolean: no supplied evidence establishes that interpretation. Catalog presence and process metadata alone are not a supplier quotation or order acceptance. Do not describe a connector-excluded assembly as the requested complete five prototypes. Supplier approval is not obtained by this review.

Final board, schematic, supplier BOM/CPL, local libraries and manufacturing outputs need edition-consistent checks. A clean connectivity/DRC report is useful but does not establish supplier identity, polarity/rotation, thermal qualification, or physical 5 W output. Exact purchasing/pinout review is conditional on the final supplier mapping.

## Connectivity review and edition synchronization

Board pad/net inspection confirmed the intended oscillator/divider/bridge interconnections. U1 DRV8871 pads 1, 7 and exposed pad 9 connect to GND; pad 2 to NQ, pad 3 to Q, pad 4 to ILIM, pad 5 to VIN, pad 6 to OUT1 and pad 8 to OUT2. U2 L7805 pads 1/2/3 connect to VIN/GND/+5V respectively. Added R4 bridges +5V to GND. These are board connectivity findings, not proof of purchased component identity or physical operation.

The reviewed successor has 18 references including the regulator bleeder: 16 SMT components and two through-hole connectors. Final supplier BOM/CPL and refreshed instructions must include all 18 references, and the exact final board hash must be checked again after integration. The historical 30 ohm load example does not demonstrate 5 W at 12 V; use the conditional 27 ohm discussion above instead.

## Exact connector qualification blocker
The selected connector identity is C474881 / Cixi Kefa KF301-5.0-2P. The captured DORABO DB128L-5.08 drawing is not documentation for that exact selected component and does not independently establish its pin pitch, hole fit, outline or placement origin. Do not treat that drawing as proof of compatibility. Exact selected-part mechanical documentation or a supplier-confirmed fit is still required before claiming an orderable, fully qualified complete-board assembly. This identity/compatibility gap is separate from JLCPCB acceptance of the manualWeld process and from current stock availability.
