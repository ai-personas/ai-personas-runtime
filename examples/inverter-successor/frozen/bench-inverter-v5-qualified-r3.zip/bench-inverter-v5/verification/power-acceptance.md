# Conditional 5 W acceptance envelope

Engineering calculation only; NOT a component rating, physical test result or ordering release.

## Resistive square-wave model
For a symmetric bipolar bridge with a constant total series resistance Rb, supply Vs and load RL:
I = Vs/(RL+Rb), Vload_rms = I*RL, Pload = Vs^2*RL/(RL+Rb)^2.
This simplified model excludes switching transients, current-limit operation, supply droop, temperature dependence and wiring losses unless included in Rb. It does not establish any DRV8871 parameter.

At an actual 12.000 V supply and actual 27.000 ohm load, at least 5 W requires Vload_rms >= 11.618950 V and I_rms >= 0.430331 A. The simplified model therefore requires total series resistance <= 0.885480 ohm. At the boundary its loss is 0.163978 W. These are conditional thresholds, NOT verified device capabilities. Any tolerance, hot resistance, supply variation and wiring must be accounted for before claiming this envelope. A 30 ohm load cannot reach 5 W at 12 V even with zero loss.

## Qualification needed before adopting this operating point
1. Establish manufacturer supply/logic compatibility, ILIM setting and tolerance, hot bridge resistance, and thermal requirements from permitted independent evidence. Establish an operating supply range and load tolerance, not only nominal values. Evaluate the worst case with those bounds.
2. Check layout power paths, decoupling, regulator stability, grounding and assembly-process requirements on the final board. A resistance estimate does not establish safe thermal performance.
3. For a physical prototype use a correctly polarized isolated current-limited bench supply and a resistive load rated at least 10 W with suitable cooling. Measure actual hot load resistance, voltage at the board input and true RMS differential output voltage. Do not connect an earth-grounded scope clip to either output terminal.
4. Record P = Vload_rms^2/Rload, input current, startup behavior, frequency, duty symmetry, output DC offset and component temperatures through thermal equilibrium. Require at least 5 W only within independently established electrical and thermal limits; report measurement uncertainty. Startup and no-load operation must also be checked. No numerical DC-offset or temperature acceptance limit is invented here: those remain to be established from application and component requirements.

The current README and assembly instructions already accurately call 5 W an unvalidated target. This analysis narrows the needed evidence; it does not release the board for assembled ordering. No physical validation was performed.

## Conditional power envelope (engineering calculation, not qualification)

A nominal 12 V input does not establish a guaranteed 5 W rating. For a symmetric square wave into resistance R with total nonnegative series resistance Rs, P = Vin^2 R / (R + Rs)^2. Series resistance includes hot bridge resistance, board paths, connectors and wiring; this simplified model excludes current limiting, startup and switching transients.

Illustrative—not approved—supply and load tolerances of +/-5% about 12 V and 27 ohm include 11.4 V into 28.35 ohm. That corner yields only 4.584127 W even with zero loss. At exactly 12 V into 28.35 ohm, achieving 5 W requires total series resistance no greater than 0.224114 ohm. Neither resistance budget nor a minimum input voltage has been established by manufacturer evidence or physical testing.

These calculations do not authorize a higher supply voltage. Establish minimum voltage at the board, maximum hot load resistance, worst-case driver and interconnect losses, current-limit behavior and thermal suitability before adopting a 5 W rating. See tolerance-feasibility.json in verification/ for the conditional sensitivity calculation. The assembled-order release remains blocked.
