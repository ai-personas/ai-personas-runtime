# Release inspection scope

The release directory was inspected after fresh exports. It contains 18 populated references, including J1/J2, fabrication Gerbers and drill, BOM/CPL, editable KiCad project, and project-relative symbol and footprint tables. All 18 board footprint IDs resolve to retained Successor.pretty files.

Prior isolated HOME/config checks of a copied design successfully exported its netlist and ran PCB DRC. The subsequent diagnostic script failed on GetFPID().Format(), not on those completed CLI checks. This is a scoped headless portability check, not an observation of an interactive GUI session on another workstation.

These checks do not establish exact KF301 connector geometry, supplier acceptance of manualWeld assembly, current inventory, or physical operation. The README and sourcing gaps control supported use: review and quotation/DFM only, not unchanged assembled ordering. No purchase or physical build was authorized or performed.
