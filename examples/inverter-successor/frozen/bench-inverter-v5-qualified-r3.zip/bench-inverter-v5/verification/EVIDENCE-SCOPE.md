# Verification edition scope

Final PCB SHA256: 3c3a4d89ce44315d1b709ca342f2c96ad1bd178a6f34d5c312b210479a264e3c.

assembly-export-check.json checks final 18-reference BOM/CPL consistency. fresh-erc.json and fresh-drc.json record fresh KiCad 9 checks; release-inspection.md qualifies portability scope. These do not establish physical performance or supplier acceptance.

historical/ preserves earlier records unchanged. Its assembly audit, electrical intent and electrical review concern earlier PCB revisions; its placement check concerns 17 references. Its power-envelope.json assumes 5% C6, NOT the selected 10% initial tolerance. These are not final-board certification. Additional X7R and IC timing effects remain applicable.

power-acceptance.md and tolerance-feasibility.json are conditional analytical calculations, not physical qualification or an approved expanded supply range. Exact connector mechanical compatibility and supplier mixed-process acceptance remain release gates.

See final-board-review-addendum.md for independent final-board pad/net inspection scope.
