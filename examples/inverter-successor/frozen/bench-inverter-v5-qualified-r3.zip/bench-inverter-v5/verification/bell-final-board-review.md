# Independent final-board pad/net review — Bell

## Exact scope
This report supplements, and does not replace or silently update, historical verification reports. It records the final issued ZIP receiving inspection in which pcbnew opened the board and enumerated references and pad/net assignments. The inspected board SHA-256 was:

`3c3a4d89ce44315d1b709ca342f2c96ad1bd178a6f34d5c312b210479a264e3c`

Evidence: retained inspection stdout `object:7936ca3e78502a423086bd15dfdf9db639a8cc702fb7873aa2df2b8dc5bf2c66`. The successful receiving process is not itself proof of electrical performance or complete CAD portability.

## Observed final-board content
18 references were enumerated: C1–C8, J1–J2, R1–R4 and U1–U4.

- J1: pin 1 VIN, pin 2 GND. J2: pin 1 OUT1, pin 2 OUT2; the output is floating, not ground referenced.
- U1 DRV8871DDA: pins 1/7/9 GND, 2 NQ, 3 Q, 4 ILIM, 5 VIN, 6 OUT1, 8 OUT2.
- U2 L7805ABD2T-TR: pins 1 VIN, 2 GND, 3 +5V.
- U3 TLC555IDR: pins 1 GND, 2/6 TIM, 3 CLK, 4/8 +5V, 5 CONT, 7 DIS.
- U4 CD4013BM96: pin 1 Q, 2/5 NQ, 3 CLK, 4/6/7/8/9/10/11 GND, 12 NC12, 13 NC13, 14 +5V.
- R1 10k connects +5V to DIS; R2 68k connects DIS to TIM; R3 64.9k connects ILIM to GND.
- R4 is present as 820 ohms, 1%, between +5V and GND. At nominal 5 V this adds about 6.1 mA preload and dissipates about 30.5 mW; those are calculations, not measurements.
- C1/C2/C3 connect VIN to GND; C4/C5/C8 connect +5V to GND; C6 connects TIM to GND; C7 connects CONT to GND.

These pad/net assignments are consistent with the intended timer, divide-by-two stage and bridge interconnection. This limited check does not establish all device ratings, footprints, actual copper connectivity, routing quality, DRC/ERC status, timing tolerance, regulator stability, thermal margins or assembly manufacturability.

## Supported use and remaining gates
Use this report only as final-board reference-count and pad/net evidence for the exact board hash above. Historical reports whose board hashes, reference counts or component tolerances differ must remain explicitly labeled historical and cannot be promoted to final verification by inclusion in the archive.

The 5 W condition remains a conditional bench target: nominal 12.0 V measured at board input, with a measured 27 ohm resistive load rated at least 10 W. No physical loaded-output, electrical or thermal validation was performed by this review. Low-voltage bench-only use remains required; this is not a mains inverter or a safety-certified supply.

Unchanged assembled ordering remains blocked pending exact C474881 connector mechanical compatibility evidence. Supplier acceptance of mixed SMT/manual-weld assembly and current availability also remain external gates. This report does not authorize an order, payment or physical build and does not establish stock KiCad 9 portability of the whole editable project.
