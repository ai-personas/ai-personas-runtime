# Successor release gates

This edition contains explicit supplier selections and complete BOM/CPL for 18 references, including J1/J2. These files are an engineering candidate, not an accepted assembled order.

1. **Identity/compatibility blocker:** C474881 / Cixi Kefa KF301-5.0-2P lacks independently verified exact mechanical documentation. The captured DORABO DB128L-5.08 drawing is a different identity. Obtain the exact KF301 drawing or supplier-confirmed fit for pitch, drilled-hole fit, body outline and placement datum before releasing unchanged assembly.
2. **Supplier-only process/availability gate:** confirm JLCPCB accepts the J1/J2 manualWeld population for five boards, all other assembly processes, and the exact selected stock. This is separate from mechanical compatibility. No order or payment is authorized.
3. **Physical qualification not performed:** conditional 5 W target at 12.0 V measured board input into measured 27 ohm >=10 W load; differential RMS output must reach 11.619 V. Validate startup, current limiting, waveform and temperatures on a controlled bench before asserting a tested rating.

The regulator minimum-load gap is corrected by populated R4=820 ohms. Initial timing tolerance uses the actual 10% X7R C6. Refer to README and independent electrical review for limits. Do not substitute parts, exclude connectors or reinterpret numeric supplier metadata as availability approval.
