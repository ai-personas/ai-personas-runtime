# Assembly instructions — successor v5

Populate five boards using the exact JLCPCB BOM/CPL and supplied fabrication files. All 18 references are selected in supplier-selection-v5.json, including the two manually soldered connectors. No order or build has been authorized. This is an unbuilt design; see the release README and independent report for the supported submission scope and remaining qualifications.

## Intended board
12V DC bench input; approximately 49.41Hz complementary square-wave bridge output. Nominal design target 5W into a resistive load; output voltage follows input minus circuit losses, not regulated. No transformer, galvanic isolation, mains interface, grid connection, sine-wave filter, or input reverse-polarity protection. Use an isolated, correctly polarized current-limited bench supply. Do not infer a certified 5W thermal rating from these files.

## Assembly scope
Populate all 18 references: 16 SMT and two through-hole connectors. All bodies are on the front side. Use final CAD and assembly/JLCPCB-CPL.csv for coordinates and rotations, and assembly drawings for pin-1 orientation. Read assembly/placement-convention.json: coordinates are millimetres, X right/Y up (negative KiCad Y), with top-side counterclockwise rotations. verification/assembly-inventory.csv is a diagnostic board-origin inventory, NOT a machine placement file. Footprint zero rotation is not a supplier machine rotation guarantee.

J1 pin1 is VIN, pin2 GND. J2 pin1 OUT1, pin2 OUT2; both output terminals switch relative to input ground. Fit connectors with wire-entry orientation matching the final footprint/fabrication drawing. Selected KF301-5.0-2P connectors use 5.00mm pitch; the successor footprint has 1.60mm finished drills and 2.60mm pads. Solder through-hole pins after SMT using an appropriate mixed-process flow; thermal vias are not through-hole components.

C1 is polarized: pad1 VIN positive, pad2 GND negative. Verify body polarity against the actual manufacturer's marking. C2-C8 are nonpolar. U1 pins1/7 and exposed pad9 are ground; U2 tab/pad2 is ground. Check every IC pin1 against CAD and actual part marking. Do not derive orientation from text alone.

## Stencil and exposed-pad process
U1 uses the retained local HTSOP8_EP_NoInPadVias footprint. Its exposed copper pad is 2.95x4.9mm with a 2.4x3.1mm paste aperture (approximately 51.5% coverage). The scoped geometry audit found no vias intersecting this pad; filled/capped in-pad-via processing is therefore not required by this layout. Nearby ground vias remain ordinary plated vias. The assembler must validate exposed-pad solder coverage and voiding; do not silently change stencil apertures. U2 TO-263 tab has four paste windows. Stencil thickness/reflow profile must be selected against the resolved component specifications; not established here.

## Pre-power checks
Inspect solder joints, bridges, polarized parts and pin1 orientation. Verify continuity J1.2 to U1 ground pads1/7/9 and U2 tab; verify absence of a VIN-GND hard short. Inspect exposed-pad assembly by a method suitable for hidden solder joints. Check J2 terminals are not shorted to ground or each other.

## Bench validation plan — not executed
Start unloaded from a current-limited isolated 12V bench supply, observing input current and +5V rail. Check oscillator near 98.82Hz and divided outputs near 49.41Hz; selected 1% resistors and 10% X7R capacitor tolerances alone predict roughly 44.47-55.46Hz output (IC and temperature error additional). Check complementary bridge operation and startup before loading. Use a differential probe across J2; NEVER ground either output terminal with an oscilloscope ground clip. For the 5 W target use 12.0 V measured at the board input and a measured 27 ohm resistive load rated at least 10 W. Five watts requires 11.619 V RMS across that load; total effective series resistance must be at most 0.8855 ohm. Driver on-resistance, temperature, board and lead losses make this conditional, not a guaranteed rating. Demonstrating 5W requires measuring true RMS across an appropriate adjustable resistive load and P=Vrms^2/R, while staying within verified driver/current-limit/thermal specifications. Record input current, output waveform/DC offset and component temperatures to thermal equilibrium. Shut down on unexpected current, heating or waveform. This plan is not evidence of a successful test.

## Remaining validation
Physical prototype testing, solder-process acceptance and actual supplier order acceptance have not occurred. Review the independent component and release verification reports. Exact selected identifiers are supplied, not substitution permission. No certified power or thermal rating is claimed.
