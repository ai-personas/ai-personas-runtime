RELEASE STATUS: PARTIAL — MANUFACTURING HOLD
This is the best supported digital revision, NOT a demonstrated unchanged-order-ready package. The supplied evidence does not establish the supplier machine-zero rotation/origin convention for the corrected placement rows, especially U1/U3/U4 and U2. Published numbered-pad alignment supports the corrections but is not an independent machine-zero declaration. Do not commit manufacture on the assumption that this uncertainty is resolved. No buyer CAD repair or part selection is proposed; the unresolved placement-interface verification is a release blocker, not an instruction to guess at checkout. No upload or shop follow-up was performed.

LOW-VOLTAGE BENCH INVERTER — successor prototype release
Recipient: Prototype shop / JLCPCB. Requested quantity: FIVE fully assembled boards.
No order, payment, or physical build has been authorized or performed.

ORDER AND ASSEMBLY
Intended order, once the placement-interface blocker is resolved: FIVE complete assembled prototypes using Standard PCBA, top-side SMT plus supplier-installed through-hole J1/J2 (insertion and soldering included). Populate all 18 designators per board, 90 installed parts total. Use Assembly/BOM.csv without substitutions and Assembly/CPL.csv without buyer rotation or coordinate edits. These are the sole order BOM and placement files; other reports are evidence, not alternative order inputs.
PCB: two-layer FR-4, 1.6 mm, 1 oz outer copper, lead-free HASL, ordinary tented vias. No filled/capped vias or special via-in-pad process. Supplier-added rails, fiducials and tooling are permitted as standard order selections. Use the fabrication Gerbers and drill files supplied in this edition.
PROCESSING ENVELOPE AND FINISHED QUANTITY
The single-board outline is not itself the Standard PCBA processing envelope. Request supplier-added processing rails/panel, fiducials and tooling to provide an assembly processing envelope of at least 70 x 70 mm. Retain the supplied single-board circuit, BOM and CPL without buyer edits. Supplier preparation must preserve the placement coordinate registration. Request FIVE FINISHED, fully populated circuit boards after separation, not five multi-board panels. Have the supplier state the processing arrangement and resulting finished-board count during normal review before confirmation. Do not assume the default 5 mm panel edges alone meet the required envelope. If using a multi-up panel, panel quantity multiplied by circuits per panel determines finished quantity; do not accidentally order five such panels. No supplier panel arrangement or acceptance has yet been obtained.

The editable KiCad 9 project and local libraries are included. Do not use predecessor files or inherited native KiCad placement exports as order inputs. Assembly/CPL.csv includes part-specific orientation corrections (U1/U3/U4 at 270 degrees) and a U2 body/library-center correction to X=53.747500 mm that remains unverified against any distinct supplier machine datum. Published library alignment is not proof of supplier machine-zero convention; see Checks for the exact verification scope and any remaining blocker. Stock observations are historical, not reservations. Supplier availability remains subject to quotation; do not substitute parts.
No upload, order, payment or physical build was performed.

BENCH CONDITIONS
Low-voltage isolated bench supply only. No mains, grid connection, transformer output, or safety-rated isolation claim. Apply regulated 12.0 V measured at board VM using a current-limited supply capable of at least 1 A; verify connector polarity in the schematic/board before power. Load: 27 ohm resistor rated at least 10 W between the TWO floating bridge outputs. Neither output is ground. Do not connect an earth-referenced scope ground to either output; use an appropriate differential measurement. No reactive load qualification is claimed.
Nominal calculated output is approximately 5.1 W at approximately 49.4 Hz square wave with this source/load; switch loss and tolerances affect actual power. This is not measured 5 W delivery or a sine-wave inverter. Verify frequency, RMS load voltage, input current and thermal behavior on the first assembled prototype before extended operation. The resistor can become hot. Power off before wiring. Do not reverse the supply.

LIMITATIONS
No physical build, thermal test, EMC test, or supplier acceptance has occurred. The nominal 5 W condition is a calculation, not a measurement. CAD checks and exports establish only their stated digital scope, not electrical or manufacturing certification. Consult Checks and assembly evidence for remaining placement-datum uncertainty before committing manufacture.


EVIDENCE SUCCESSOR: PROVISIONAL PLACEMENT HOLD
See Checks/placement-geometry-comparison.txt. Supplier-library geometry supports the stated pin-one comparison but does not establish machine datum compatibility. NOT released as order-ready.
