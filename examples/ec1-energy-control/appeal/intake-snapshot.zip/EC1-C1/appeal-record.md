# EC1 C1 · Appeal desk · intake copy

**At the filing notice: no sleeve-specific objection or grounds received; no appeal ruling.** This is a snapshot, not a rejection or closure. The request for a filing address did not identify a sleeve or ask for a particular replacement classification.

## Where to file and who decides

In Studio, open this task (the Records counter challenge to the final EC1 stores handoff) and reply to **Lumen’s EC1 filing notice**. Identify S7 / Gold or K4 / Grey, the disputed paper classification, and your grounds. **Lumen has agreed to receive and decide** on the two simulated records and give reasons. No vote or endorsement is required to file. Agreement on the procedure does not imply agreement on the merits; the filer need not agree with the ruling.

Studio task: `work:work-573026914a7d5f9168a62457ceca5fe2@1`. Procedure: *EC1 paper objection desk — filing and decision*, `agreement:agreement-258595b00ebbfe98213f99022318f93c@1`.

## What the original clerk decided

| Sleeve | Original classification and desk action | Recorded basis |
|---|---|---|
| S7 / Gold | PAPER MATCH — refer only for a later unpowered inspection. | The card named Panasonic Industry EEUFR1C102: polarized radial, 1000 µF ±20%, 16 V, straight leads at 5.0 mm, Ø10 × 16 mm body. Nominal agreement on paper did not establish contents or clearance. |
| K4 / Grey | NOT A PAPER MATCH — do not forward. | The electrical description agreed, but the card gave 7.5 mm straight-lead pitch rather than 5.0 mm, and Ø12.5 × 20 mm rather than Ø10 × 16 mm. The ledger treated the explicit pitch mismatch as decisive despite the missing maker and exact order code; the decision was not HOLD. |

These final card-based decisions replaced earlier no-card holds. For the transcribed cards and original reasoning, open `current-offers.md`; the unchanged clerk master is `relief-clerk-screen.md`. Both accompany this supplement unchanged from `delivery:delivery-f4722eb071c9add7e00c3c0391cce510@1`.

## Status and limits

Noor’s review of the **original** edition supported both dispositions against the quoted cards and target; it did not authenticate the transcription or decide an appeal. There is no attributed position on a specific appeal to report at this stage. The grounds, any disagreement on them, and their disposition remain to be recorded if filed. Do not infer assent from silence or overwrite the source ledger.

Paper exercise only. Nothing here authorizes ordering, supplier contact, inspection, testing or installation.
