#!/usr/bin/env python3
"""Run: python3 check_model.py. Source voltage and component values in SI.
Midpoint power integration of exact linear-node increments vs analytic limits.
Includes leakage and meter loading as optional resistances to common.
"""
import math, json, pathlib
cfg=json.loads((pathlib.Path(__file__).resolve().parents[1]/'design/circuit.json').read_text()); parts=cfg['components']; R=parts['R1']['ohm']; L=parts['R2']['ohm']; C=parts['C1']['F']; VS=cfg['limit_V']
def run(load_g,dt=.001):
    v=0.; ein=out=loss=0.; history=[]
    for phase,duration in [('charge',8.),('hold',2.),('deliver',8.)]:
        a=(1/R if phase=='charge' else 0); b=(1/L if phase=='deliver' else 0); g=a+b+load_g; n=round(duration/dt); h=duration/n
        for i in range(n):
            eq=VS*a/g if g else v
            mid=v+(eq-v)*(-math.expm1(-g*h/(2*C))); v+=(eq-v)*(-math.expm1(-g*h/C)); ein+=h*VS*(VS-mid)*a; out+=h*mid**2*b; loss+=h*((VS-mid)**2*a+mid**2*load_g)
        history.append((v,ein,out,loss,C*v*v/2))
    return history

def check(x,msg):
    if not x: raise ValueError(msg)
if __name__=='__main__':
    for name,g in [('ideal',0.),('illustrative 100k leakage + 10M probe at STORE',1/1e5+1/1e7)]:
        print(name,'\nphase     STORE/V     Ein/J       Eload/J     losses/J     remaining/J')
        rows=run(g)
        for phase,(v,i,o,w,u) in zip(('charge','hold','deliver'),rows):
            print(f'{phase:8s}',*(f'{x:.9f}' for x in (v,i,o,w,u))); check(abs(i-o-w-u)<2e-8,'power ledger closure')
        peak=rows[0][0];check(rows[2][2]<=.5*C*peak**2+1e-9,'finite energy bound');check(rows[0][1]==rows[2][1],'source supplied after isolation');check(rows[2][0]<.01,'did not discharge')
        if not g:
            exp=VS*(1-math.exp(-8/(R*C)));check(abs(peak-exp)<1e-10 and peak==rows[1][0],'analytic charge or isolated hold'); check(abs(rows[-1][2]-.5*C*exp**2*(1-math.exp(-16/(L*C))))<2e-8,'analytic finite delivery')
    print('PASS: analytic ideal transients, loaded bounds and integrated energy closure.')
