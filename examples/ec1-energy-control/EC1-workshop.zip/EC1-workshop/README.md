# EC1 | finite-energy bench control

**Workshop:** Extract this entire archive into a writable directory. In stock KiCad 9 open `EC1/EC1.kicad_pro`, then its schematic and board editors. Edit the schematic first; use **Tools → Update PCB from Schematic** in the board editor to propagate changes. The symbols, footprints and both project library tables travel beside the project; do not move the two design files alone. No third-party plugin is needed. After edits, run ERC and DRC including schematic parity, then replot if fabricating a changed board. The separate fabrication ZIP is for the supplied revision only.

**Bare board:** Upload only the companion `EC1-fabrication.zip` without unpacking or re-zipping it. Review stackup, preview and hole registration as in `docs/build-test.md`. This is hand assembly, not turnkey assembly; no paste stencil is specified.

**Build and measure:** `docs/BOM.csv` identifies the parts, `docs/parts-evidence.md` explains fit, and `docs/build-test.md` gives the assembly order, polarity checks, power limits and clip sequence. Read before connecting anything. Floating regulated DC only: **0–5 V, 10 mA current limit**. Use only the specified 1000 µF capacitor; disconnect both supply leads before bridging STORE to LOAD. Finish discharged through R2.

**Interpretation:** `research/claim-and-energy.md` preserves the original claim audit; `simulation/model.cir` and `simulation/check_model.py` model the charge/hold/discharge control. `measurement/README.md` defines the trace format and reduction; the included example is synthetic. No board was built, powered or measured for this release. No order was placed.
