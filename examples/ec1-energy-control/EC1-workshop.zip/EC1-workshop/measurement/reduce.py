#!/usr/bin/env python3
"""Compute an EC1 energy ledger from SI-unit CSV (stdlib Python 3)."""
import argparse,csv,math,json
from pathlib import Path
COLS=('t_s','in_V','store_V','load_V')
def parse(path):
    with open(path,newline='',encoding='utf-8-sig') as f:
        r=csv.DictReader(f)
        if r.fieldnames!=list(COLS): raise ValueError('expected header: '+','.join(COLS))
        rows=[]
        for i,row in enumerate(r,2):
            if None in row: raise ValueError(f'line {i}: unexpected extra field')
            try: x=tuple(float(row[k]) for k in COLS)
            except (TypeError,ValueError) as e: raise ValueError(f'line {i}: missing/invalid number') from e
            if not all(map(math.isfinite,x)): raise ValueError(f'line {i}: nonfinite number')
            rows.append(x)
    return rows

def ledger(rows,r1,r2,c):
    if len(rows)<2 or not all(math.isfinite(n) and n>0 for n in (r1,r2,c)): raise ValueError('need >=2 samples and positive finite R1, R2, C1')
    def powers(row):
        t,v,s,l=row; i=(v-s)/r1; p=v*i
        return (p,max(0,p),max(0,-p),l*l/r2,r1*i*i)
    energies=[0.]*5; maxdt=0.
    for a,b in zip(rows,rows[1:]):
        dt=b[0]-a[0]; maxdt=max(dt,maxdt)
        if dt<0: raise ValueError('nonmonotonic time')
        for j,(pa,pb) in enumerate(zip(powers(a),powers(b))): energies[j]+=dt*(pa+pb)*.5
    if maxdt==0: raise ValueError('no elapsed time')
    pin,supplied,returned,load,rheat=energies
    u0=.5*c*rows[0][2]**2; u1=.5*c*rows[-1][2]**2
    return dict(samples=len(rows),duration_s=rows[-1][0]-rows[0][0],max_dt_s=maxdt,port_signed_J=pin,port_inward_only_J=supplied,port_outward_only_J=returned,R2_delivered_J=load,R1_heat_J=rheat,C1_initial_J=u0,C1_final_J=u1,load_minus_inward_J=load-supplied,residual_J=pin-load-rheat-(u1-u0))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('csv');p.add_argument('--r1',type=float,default=1000.,help='R1 in ohms');p.add_argument('--r2',type=float,default=1000.,help='R2 in ohms');p.add_argument('--c1',type=float,default=.001,help='C1 in farads (for endpoint energies only)');a=p.parse_args()
    try: print(json.dumps(ledger(parse(a.csv),a.r1,a.r2,a.c1),indent=2,allow_nan=False))
    except (ValueError,OSError) as e:p.exit(2,str(e)+'\n')
if __name__=='__main__': main()
