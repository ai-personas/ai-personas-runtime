#!/usr/bin/env python3
"""Generate an ideal example in a temporary file and test the measured-data CLI."""
import csv,json,math,sys,tempfile,subprocess
from pathlib import Path
from reduce import COLS

def check(ok,msg):
    if not ok: raise AssertionError(msg)
def main():
    rc=Path(__file__).with_name('reduce.py'); v0=4.; T=6.; r1=1200.;r2=900.;c=.001;vc=v0*(-math.expm1(-T/(r1*c))); n=3000
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'cycle.csv'
        with p.open('w',newline='') as f:
            w=csv.writer(f);w.writerow(COLS)
            for j in range(n+1):
                t=T*j/n;w.writerow([t,v0,v0*(-math.expm1(-t/(r1*c))),0.])
            w.writerow([T,vc,vc,0]);w.writerow([T+2,vc,vc,0])
            for j in range(n+1):
                t=T*j/n;s=vc*math.exp(-t/(r2*c));w.writerow([T+2+t,s,s,s])
        def cli():return subprocess.run([sys.executable,str(rc),str(p),'--r1',str(r1),'--r2',str(r2),'--c1',str(c)],text=True,capture_output=True)
        z=cli();check(z.returncode==0,z.stderr);x=json.loads(z.stdout);ei=c*v0*vc;el=.5*c*vc**2*(-math.expm1(-2*T/(r2*c)))
        check(abs(x['port_signed_J']-ei)<1e-8,'input');check(abs(x['R2_delivered_J']-el)<2e-8,'load');check(abs(x['residual_J'])<3e-8,'residual');check(x['load_minus_inward_J']<0,'cycle'); print(z.stdout)
        for bad in ('0,0,0,0\n1,nan,0,0\n','1,0,0,0\n0,0,0,0\n','0,0,0,0\n0,0,0,0\n'):
            p.write_text(','.join(COLS)+'\n'+bad);check(cli().returncode==2,'invalid trace accepted')
        print('PASS: user CLI on synthetic RC record vs closed form, energy closure and rejected invalid traces; NOT a physical result.')
if __name__=='__main__':main()
