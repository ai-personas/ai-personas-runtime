# EC1 · five-board surface-mount build

Open `EC1/EC1.kicad_pro` in KiCad 9 with the adjacent schematic, board and library tables in place. This is one 54 × 34 mm board design; build five identical boards. The line files below are per board. Do not place the TP references: those four contacts are etched copper, not purchased test points. There are no wire loops, bench-soldered parts, or off-board assemblies in the kit.

## Assembly desk

1. Kit `assembly/BOM.csv` exactly: one each of R1, R2 and C1 per board (lot: ten identical 1 kΩ chips and five 1000 µF cans; no attrition allowance). Do not substitute a different capacitor package under the same value.
2. Apply the **top** stencil data; all three components are top-reflow parts. Use `assembly/Positions.csv` as issued, not raw KiCad angles. Coordinates are body centers, millimetres from the finished board's lower-left corner viewed from above; +X right, +Y up, CCW positive. For C1 the line's 0° is positive-left, not stripe-left: the negative band goes to the right. R1 and R2 are nonpolar.
3. Use `assembly/Top-map.pdf` and `assembly/Probe-map.csv` to locate the parts and four contacts from the same datum. Probe discs get no paste and no fitted hardware. IN, STORE, LOAD and G are the only external electrical connections. The project does not include a fixture, source, logger or switch.

See the accompanying inspection and bench notes before any later physical use. Digital checks establish file contents, not live stock, feeder calibration, stencil/reflow settings, cost, board quality or powered performance. No supplier contact, upload, order, fabrication, powering or measurement was performed for this issue.
