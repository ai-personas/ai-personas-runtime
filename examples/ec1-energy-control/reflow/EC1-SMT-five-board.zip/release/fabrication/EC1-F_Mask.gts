%TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu22.04.1*%
%TF.CreationDate,2026-11-25T18:31:29+00:00*%
%TF.ProjectId,EC1,4543312e-6b69-4636-9164-5f7063625858,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu22.04.1) date 2026-11-25 18:31:29*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,3.100000*%
%ADD11RoundRect,0.050000X-0.750000X-0.950000X0.750000X-0.950000X0.750000X0.950000X-0.750000X0.950000X0*%
%ADD12RoundRect,0.050000X-2.050000X-1.000000X2.050000X-1.000000X2.050000X1.000000X-2.050000X1.000000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,TP1*%
X7000000Y24000000D03*
%TD*%
%TO.C,TP2*%
X27000000Y24000000D03*
%TD*%
%TO.C,TP3*%
X46000000Y24000000D03*
%TD*%
%TO.C,TP4*%
X46000000Y8000000D03*
%TD*%
D11*
%TO.C,R1*%
X14450000Y24000000D03*
X17550000Y24000000D03*
%TD*%
%TO.C,R2*%
X38450000Y12000000D03*
X41550000Y12000000D03*
%TD*%
D12*
%TO.C,C1*%
X21650000Y12000000D03*
X30350000Y12000000D03*
%TD*%
M02*
