# EC1 SMT • assembly inspection and bench boundary

**Lot: five identical boards.** Top-side reflow only. The four round contacts are etched features; do not place parts, add paste or solder wire to them. No source, logger, switch, cable or fixture is fitted. The location map is viewed from above, not through the board. Use the finished board edges as the datum before aligning probes. Spring contact force, access with the actual probe housing, travel and fixture repeatability have not been measured.

### Receiving and first article (future checks, not results)

1. Match labeled reels and package/size to the exact BOM and parts notes. No substitutions. Check the capacitor's polarity mark against its documentation, not a feeder angle inferred from the tape. Follow the actual component's allowable reflow profile; oven profile and process yield are not established by these files.
2. Inspect the bare board: outline and legend in the component-side view, no damage, all four labeled targets flat and exposed. Compare the stencil to top lands, with **no aperture over any probe**. Inspect paste deposition before placement. On bare copper, verify connectivity within each net and isolation among the four nets.
3. Confirm R1 and R2 at their own sites (nonpolar, 1.00 kΩ each). C1 is polarized, 1000 µF: **positive terminal to pad 1 / STORE**, negative terminal to pad 2 / G. Compare the marked negative side to the pin map. Check before reflow and again after. Inspect for missing/skewed parts, open joints, bridges, disturbed can/seal, or solder on targets; reject suspect assemblies. Use line inspection appropriate to partially hidden terminations. Recheck polarity and isolation before powering.
4. With source disconnected, discharge via R2 (external STORE–LOAD link); verify |STORE–G| below 10 mV, then open link. Check approximately 1 kΩ IN–STORE and LOAD–G. STORE–G can show a charging transient on an ohmmeter; a persistent low resistance is a fault. Never apply an ohmmeter/capacitance meter to an energized board. Remove meter before a run.

### External wiring and one low-voltage cycle

Use a floating regulated **0–5.00 V DC** source preset to **10 mA current limit**. Positive to IN only; negative to G. All recorder references to G only. Three simultaneous high-impedance voltage channels at IN, STORE and LOAD; no 50 Ω inputs, current-mode meter, hidden backfeed or extra grounds. The external switch only joins STORE to LOAD. Never short STORE to G or drive STORE directly. No batteries, mains, high voltage, inductive loads or larger storage. Stop for sustained current limit, reversed polarity, heating, damage or unexpected voltages.

|Phase|Source|STORE–LOAD switch|Observe|
|---|---|---|---|
|Reset|Both leads disconnected|Closed until discharged; then open|Record actual residual; start logger before charge.|
|Charge, ~8 s|Connected at IN/G|Open|Initial current up to nominal 5 mA at 5 V, falling with ~1 s time constant.|
|Hold, ~2 s|Physically disconnect both source leads|Open|Open IN follows STORE through R1; that is not continuing input power.|
|Deliver, ≥8 s and until near empty|Still disconnected|Closed|R2 dissipates the stored energy; finish discharged via R2. Check rebound after rest.|

Treat this as a finite capacitor store, **not a generator**. For 1000 µF at 5.00 V, ½CV² = 12.5 mJ nominal (15 mJ at +20% capacitance); ideal full charge from zero draws ~25 mJ including R1 heat. Record actual R/C values if known, phase edges, instrument impedances, offsets, sampling and start/end voltages. Compare the full-cycle signed integral of IN × (IN−STORE)/R1 with R1 heat, LOAD²/R2 integrated over time, and Δ(½C STORE²). Use matched states, simultaneous samples, blank and repeated runs; apparent excess calls for metrology checks, not an energy-source claim. No board has been built, inspected, powered or measured in this commission.
