# EC1 • Kit and placement key (five identical boards)

Load `BOM.csv` and `Positions.csv` as UTF-8 comma-separated files. One of each BOM row per board. **Net lot: 10 × C844942 (R1, R2), 5 × C178587 (C1); 15 placements.** These are fitted quantities, with no allowance for setup or loss. No loop, connector, probe, source, switch or logger is a kitted part. No substitutes specified.

## Exact part evidence

The kit identifiers were joined by integer C-number to `jlc_components.lcsc` in the desk’s frozen catalog, checking `manufacturer`, `mfr`, package and two joints. Snapshot SHA-256: `080b01786a73850ce546a049053dbcf2c15fc41b029bd69b6c942d1848b56632`.

| Catalog | Manufacturer / orderable MPN | Catalog package | Snapshot stock (row fetch date, not live) |
|---|---|---|---:|
| C844942 | Vishay Intertech / CRCW12061K00FKEA | 1206 | 106542 (2026-10-22 UTC) |
| C178587 | PANASONIC / EEEFT1C102AP | SMD,D10xL10.2mm | 702 (2026-10-16 UTC) |

- **R1, R2:** 1.00 kΩ, ±1%, 1206 chip resistor; nonpolar. Same part in both locations. Their long axes run horizontally. R1: left/pad 1 IN, right/pad 2 STORE. R2: left/pad 1 G, right/pad 2 LOAD. A 180° end-for-end exchange is electrically equivalent; the CSV specifies 0°.
- **C1:** 1000 µF, 16 V, polarized reflow aluminum electrolytic. Panasonic FT series sheet [ABA0000C1240, pp. 1–3](https://industrial.panasonic.com/cdbs/www-data/pdf/RDE0000/ABA0000C1240.pdf), dated 10-Feb-2026: ordering row EEEFT1C102AP (standard size G, not the AV vibration-proof variant); Ø10.0 × 10.2 mm can, nominal 10.3 mm square base. Standard G land drawing: two 4.1 × 2.0 mm lands, 4.6 mm inner gap. The manufacturer's black **negative** end marking goes to pad **2 / G** on the right, not to the board’s +; the positive end faces pad **1 / STORE** on the left. A 180° reversal is **not** equivalent. Inspect polarity before energizing.

## Coordinate convention

Component side viewed from above, finished outline lower-left is (0,0), +X right and +Y up; millimetres, body centres. All three rows are `Top`. Angles are counterclockwise from the desk’s 0° feeder definition (C1 positive left; resistors horizontal), not generic KiCad rotations. Do not mirror or add a library correction to the issued line file. Machine program origin, feeder setup, nozzle clearance and actual reel orientation still require line verification. Catalog identity and digital geometry are not stock reservations, machine signoff, solderability or physical inspection. No procurement, build or powered test performed.
