# EC1 Rev A · Current offers for C1

**Interim disposition: neither sleeve can yet be referred.** No stock-card transcription is recorded here. This says nothing about either actual part. A missing card is not a mismatch.

| Offered sleeve | Card evidence | Paper decision | What is unresolved |
|---|---|---|---|
| First offer (ID not yet supplied) | None | HOLD — no card | Identity, electrical, body and lead details |
| Second offer (ID not yet supplied) | None | HOLD — no card | Identity, electrical, body and lead details |

When a transcription arrives, replace the placeholders with its own sleeve IDs and apply the separate master to each independently. If none arrives, keep the HOLD records and use the blank master for the next offer. Do not chase another request. A paper match would warrant only later unpowered inspection, not an order, installation or permission to energize anything.
