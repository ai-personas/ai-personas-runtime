RIGHT RETURN ARROW — OPERATOR DIRECTIONS

Use RIGHT_RETURN.dst unchanged. This is a square-elbow, right-pointing return arrow, double running outline, not a filled design. Its upper-left straight horizontal tail is 6 mm high. View front_preview.png from the wearer's front: the pointed tip is on your RIGHT. The preview is a reference, not a printable placement template.

DESIGN: 32.0 mm wide x 16.0 mm high in encoded needle coordinates; bounding-box centre at hoop origin (0,0). Tail is 6.0 mm high. Fits 60 x 40 mm field with 14 mm horizontal and 12 mm vertical margins about its bounding box. One thread, WHITE; DST does not reliably carry thread colour, so select white manually. No colour changes. Two outline passes and short in-line start/end securing stitches are included.

SET UP
1. Use a machine that accepts Tajima DST and a hoop with at least 60 x 40 mm usable sewing field. Copy/extract the ZIP first, then load RIGHT_RETURN.dst. Do NOT load the PNG as a design.
2. Set scale 100%, rotation 0 degrees, mirror OFF. Do not auto-fit or apply pull compensation/resizing. Confirm displayed size approximately 32 x 16 mm. Do not rely on the displayed colour: thread the needle with white embroidery thread and use suitable bobbin thread.
3. Mark the desired design CENTRE on the apron. Hoop navy canvas with suitable cutaway stabilizer; keep the apron front/right side up and the top of the apron toward the top of the machine preview. Keep straps and all other layers clear. Use a needle suitable for the canvas and embroidery thread (e.g. a fresh 80/12 or 90/14, selected for the actual material).
4. Position the hoop origin/design bounding-box centre over the marked centre. The first stitch is NOT the centre: it is at the upper-left tail corner, 16 mm left and 8 mm above origin. Do not centre by first needle position. Use the machine's centre/trace function and check clearance without sewing.
5. Compare machine preview to front_preview.png: pointed tip RIGHT, tail upper LEFT. If the machine reverses the design, imports at another size, or cannot preserve origin, STOP and obtain machine-specific help/a corrected compatible file. Do not improvise a mirror or scale adjustment.

SAMPLE BEFORE APRON
The volunteer is not present and no physical sew-out has been performed. Stitch a sample on matching navy canvas and stabilizer using the unchanged file. Start conservatively (about 400 stitches/min if supported); adjust tension and speed for clean stitches, not design geometry. Inspect for loose loops, puckering, pulled corners and secure ends. Trim loose tails after sewing as needed.
Measure the stitched outer extents: width must be 31–33 mm and height 15–17 mm; tail height 5–7 mm. Mark origin on the sample before sewing and confirm the stitched bounding-box centre is within 0.5 mm in BOTH axes. Confirm tip points right when viewed from the wearer's front. Thread spread, fabric pull and machine positioning can affect these physical measurements; digital coordinates alone do not certify them.
If sample fails any check, do not stitch the apron: report actual measurements, machine model and a front-facing photo to the textile desk for correction. The operator is not expected to redraw, scale or mirror anything. If sample passes, repeat unchanged setup on the apron, and inspect the finished work.

FILES
RIGHT_RETURN.dst — actual machine file (0.1 mm DST units).
front_preview.png — orientation reference generated from decoded DST stitches.
verification.json — independent bit-level decode results and file SHA-256; digital checks only, not machine compatibility certification or physical sew-out approval.
README.txt — these directions.
