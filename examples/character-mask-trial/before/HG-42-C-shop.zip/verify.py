"""Run with Python 3, standard library only, beside HG-42-C-mask.svg.
Independent worst-case endpoint propagation from drawing HG-42 C.
SVG stroke width is display only: coordinates are cut centerlines.
"""
from pathlib import Path
from decimal import Decimal as D
import xml.etree.ElementTree as ET
import json,itertools
root=ET.parse(Path(__file__).with_name('HG-42-C-mask.svg')).getroot()
assert root.attrib['width']=='96mm' and root.attrib['height']=='54mm'
assert root.attrib['viewBox']=='0 0 96 54'
rects={r.attrib['id']:r for r in root.iter('{http://www.w3.org/2000/svg}rect')}
assert len(rects)==3

def bounds(r):
 x,y,w,h=[D(r.attrib[k]) for k in ('x','y','width','height')]
 assert w>0 and h>0
 return [x,x+w,y,y+h]
def span(n,t):
 n,t=D(str(n)),D(str(t));return (n-t,n+t)
def minus(a,b):return (a[0]-b[1],a[1]-b[0])
def plus(a,b):return (a[0]+b[0],a[1]+b[1])
Aleft=span(9,.25);Atop=span(8,.2)
Bright=minus(span(96,.4),span(8.4,.35))
Bbottom=minus(span(54,.3),span(9.2,.25))
prints={'A':[Aleft,plus(Aleft,span(22,.3)),Atop,plus(Atop,span(11,.2))],
'B':[minus(Bright,span(24.6,.3)),Bright,minus(Bbottom,span(13.8,.25)),Bbottom]}
zones={'A':[span(7.45,.1),span(33,.12),span(6.75,.1),span(20.6,.1)],
'B':[span(60.6,.12),span(89.75,.1),span(29,.1),span(46.65,.12)]}
report={}
for name in ('A','B'):
 edges=bounds(rects['window-'+name]); margins={}; allowed=[]
 for i,(e,pr,z) in enumerate(zip(edges,prints[name],zones[name])):
  r=D('.20') if i<2 else D('.15')
  err=D('.10');m=D('.15');low=i in (0,2)
  # Small-coordinate edge must fall above the zone minimum and below print minimum.
  lo=z[1]+m+r+err if low else pr[1]+m+r+err
  hi=pr[0]-m-r-err if low else z[0]-m-r-err
  assert lo<=e<=hi,(name,i,e,lo,hi)
  allowed.append([str(lo),str(hi)])
  visibility=[];containment=[]
  # Explicit extremes of registration, edge error, printed edge and zone edge.
  for reg,cut,printed,zone in itertools.product((-r,r),(-err,err),pr,z):
   actual=e+reg+cut
   visibility.append(printed-actual if low else actual-printed)
   containment.append(actual-zone if low else zone-actual)
  v,c=min(visibility),min(containment)
  assert v>=m and c>=m
  margins[['left','right','top','bottom'][i]]={'print_clearance_min':str(v),'zone_inset_min':str(c)}
 report[name]={'artwork_edges_LRTB':list(map(str,edges)),'allowed_edge_intervals_LRTB':allowed,'worst_case_mm':margins}
outer=bounds(rects['perimeter']);assert outer==[D(0),D(96),D(0),D(54)]
assert D('.12')<=D('.20')
a,b=[bounds(rects['window-'+n]) for n in ('A','B')]
webs=[]
for w in (a,b):
 # Relative to finished datum: opening edge error .10, overall shrink .12.
 webs += [w[0]-D('.10'),D(96)-D('.12')-w[1]-D('.10'),w[2]-D('.10'),D(54)-D('.12')-w[3]-D('.10')]
webs += [b[0]-a[1]-D('.20'),b[2]-a[3]-D('.20')]
assert min(webs)>=D(3)
report['material']={'minimum_axis_separation_or_outer_web_mm':str(min(webs)),'overall_width_mm':['95.88','96.12'],'overall_height_mm':['53.88','54.12']}
report['basis']='All independent endpoint extremes; includes registration and opening edge error once. No rotation per drawing.'
print(json.dumps(report,indent=2))
