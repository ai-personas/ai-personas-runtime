from pathlib import Path
import itertools, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
root=ET.parse(P/'HG-42-C-mask.svg').getroot()
assert root.attrib['width']=='96mm' and root.attrib['height']=='54mm'
assert root.attrib['viewBox']=='0 0 96 54'
rects=root.findall('.//{http://www.w3.org/2000/svg}rect')
assert len(rects)==3
edges={}
for r in rects:
 a=r.attrib; x,y,w,h=[float(a[k]) for k in ('x','y','width','height')]
 assert w>0 and h>0
 edges[a['id']]=(x,x+w,y,y+h)
assert edges['perimeter']==(0,96,0,54)
# Independent drawing intervals, ordered L,R,T,B. For B derive from
# independently toleranced stock width/height and right/bottom offsets.
def sub(a,b): return (a[0]-b[1],a[1]-b[0])
def add(a,b): return (a[0]+b[0],a[1]+b[1])
Ar=(8.75,9.25); At=(7.8,8.2)
Br=sub((95.6,96.4),(8.05,8.75))
Bb=sub((53.7,54.3),(8.95,9.45))
printed={'A':[Ar,add(Ar,(21.7,22.3)),At,add(At,(10.8,11.2))],
 'B':[sub(Br,(24.3,24.9)),Br,sub(Bb,(13.55,14.05)),Bb]}
zones={'A':[(7.35,7.55),(32.88,33.12),(6.65,6.85),(20.5,20.7)],
 'B':[(60.48,60.72),(89.65,89.85),(28.9,29.1),(46.53,46.77)]}
lines=['HG-42 REV C: DIGITAL WORST-CASE CHECK','All values mm. Edges ordered left, right, top, bottom.',
'Intervals are exact extrema of affine expressions with independent variables.',
'Each margin checks both signs of registration and cut error and both feature endpoints.']
mins=[]
for name in ('A','B'):
 art=edges['window-'+name]
 lines.append('Window '+name+' artwork edges: '+str(art))
 lines.append('Printed edge intervals: '+str(printed[name]))
 for i,label in enumerate(('left','right','top','bottom')):
  reg=.20 if i<2 else .15
  pm=[]; zm=[]
  for d,c,f in itertools.product((-reg,reg),(-.1,.1),printed[name][i]):
   opening=art[i]+d+c
   pm.append(f-opening if i in (0,2) else opening-f)
  for d,c,z in itertools.product((-reg,reg),(-.1,.1),zones[name][i]):
   opening=art[i]+d+c
   zm.append(opening-z if i in (0,2) else z-opening)
  a,b=min(pm),min(zm); mins += [a,b]
  assert min(a,b)>=.15-1e-9,(name,label,a,b)
  lines.append(f' {label}: minimum print clearance {a:.3f}; zone inset {b:.3f} — PASS')
# Overall dimensions use their own process tolerance, NOT the edge tolerance.
assert 96-.12>=95.8 and 96+.12<=96.2
assert 54-.12>=53.8 and 54+.12<=54.2
webs=[]
for name in ('A','B'):
 l,r,t,b=edges['window-'+name]
 webs.extend([(name+' left',l-.1),(name+' right',96-.12-r-.1),
              (name+' top',t-.1),(name+' bottom',54-.12-b-.1)])
# Horizontal separating opaque strip is a conservative lower bound on
# the actual distance between these diagonally separated rectangles.
webs.append(('inter-window horizontal strip',edges['window-B'][0]-.1-edges['window-A'][1]-.1))
for label,v in webs:
 assert v>=3
 lines.append(f'{label} actual opaque web >= {v:.3f} — PASS')
lines += ['Overall width 95.880..96.120 within 95.800..96.200 — PASS',
'Overall height 53.880..54.120 within 53.800..54.200 — PASS',
f'Minimum functional margin: {min(mins):.3f} (required 0.150).',
'PASS: specified independent tolerance bounds; no physical cutting or installation performed.']
report='\n'.join(lines)+'\n'
(P/'verification.txt').write_text(report)
print(report)
