#!/usr/bin/env python3
"""Total nonnegative integer returned-book counts from a UTF-8 CSV."""
import argparse
import csv
import re
import sys

def total_returns(path):
    total = 0
    rows = 0
    with open(path, encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source, strict=True)
        if not reader.fieldnames or reader.fieldnames.count("count") != 1:
            raise ValueError("CSV must have exactly one column named count")
        if len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise ValueError("Duplicate column headers are not allowed")
        for row in reader:
            if None in row or any(v is None for v in row.values()):
                raise ValueError(f"CSV record ending at line {reader.line_num}: wrong number of fields")
            value = row["count"].strip()
            if not re.fullmatch(r"[0-9]+", value):
                raise ValueError(f"CSV record ending at line {reader.line_num}: count must be a nonnegative whole number")
            total += int(value)
            rows += 1
    return total, rows

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_file", nargs="?", default="example.csv", help="CSV path (default: example.csv in current folder)")
    args = parser.parse_args()
    try:
        total, rows = total_returns(args.csv_file)
    except (OSError, UnicodeError, ValueError, csv.Error) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print(f"Total returned books: {total}")
    print(f"Records counted: {rows}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
